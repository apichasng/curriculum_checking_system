<?php 
session_start();
$_SESSION["sentFrom"]="US";
?>
<center><div>
<div class="w3-row w3-metro-dark-blue">
    <div class="w3-col s4 w3-padding-16">����Է�����ʧ��ҹ��Թ��� �Է��ࢵ����</div>
	<div class="w3-col s6 w3-display-right ">
    <form role="form" name="login_form" action="login/check_log.php" method="post">
		<table><tr height="50%">
		<td valign="middle"><i class="w3-large fa fa-user"></i></td><td>&nbsp;</td><td><input class="w3-input w3-round w3-border" style="height:15" name="user_id" type="text"></td>
		<td valign="middle"><i class="w3-large fa fa-key"></i></td><td>&nbsp;</td><td><input style="height:15" class="w3-input w3-round w3-border" name="user_pwd" type="password"></td>
		<td>&nbsp;</td><td valign="middle"><input class="w3-button w3-round-large" type="submit" value="Login"></td>
		</tr></table>
	</form>
    </div>
</div>
</div></center>
