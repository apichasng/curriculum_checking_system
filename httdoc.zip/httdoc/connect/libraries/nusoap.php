<?php
/*
Contact PSU IT Staff to ask for this file (API to login with PSU Passports)

ติดต่อเจ้้าหน้าที่ไอที ของมหาลัยฯ เพิ่อขอไฟล์นี้ (ไฟล์ API ในการ Login ด้วย PSU Passports)
*/
?>
