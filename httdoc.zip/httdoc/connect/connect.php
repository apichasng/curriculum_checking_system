<?php
$connect = mysqli_connect("host","username","password","database_name");
?>
