<?php 
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");

include("../connect/connect.php");
$connect->query("set names utf8");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php if($_GET['action']=="cg" or $_GET['action']=="csg" or $_GET['action']=="as" or $_GET['action']=="ac") include("inc.topbar_admin.php"); 
	  else include("inc.topbar_adminx.php"); ?>

<!-- Header  -->
<div class="w3-container w3-light-grey w3-border w3-left-align">
	<br><h3 style="text-shadow:1px 1px 0 #444">ระบบตรวจสอบหลักสูตร วิทยาลัยการคอมพิวเตอร์ มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต [สำหรับเจ้าหน้าที่]</h3>
	<h5 style="text-shadow:1px 1px 0 #444">Curriculum checking system [Admin page]</h5><br>
<div>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:80%">
	<br><center><h3 style="text-shadow:1px 1px 0 #444">Curriculum Management</h3>
 
  <?php if ($_GET['action']=="cg") { ?> 
   <h4>[Create Subject Group | สร้างกลุ่มวิชา]</h4></center>
   <br><br><b>Group name list..</b>
   <table class="w3-table w3-border w3-hoverable w3-margin-top" border="1" style="width:100%;">
   <tr><td style="width:5%;">order</td><td style="width:100%;">group</td></tr>
   <?php
	$result1 = $connect->query('select * FROM subject_group where group_id < "6" order by group_id asc');
	$order=1;
		while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
			echo '<tr><td>'.$order.'</td>';
			echo '<td>'.$row[1].'</td></tr>';
			$order++;
		}
    echo '</table><br>';
?>
   <b>Add new group..</b>
   <table class="w3-table w3-border w3-margin-top" border="1" style="width:100%;">
   <tr><td style="width:5%;">order</td><td style="width:100%;">group</td><td colspan="2" style="width:10%;"><center>action</center></td></tr>
   <?php
	$result1 = $connect->query('select * FROM subject_group where group_id > "5" order by group_id asc');
	$order=1;
		while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
			echo '<tr><td>'.$order.'</td>';
			echo '<td><form name="edt_'.$row[0].'" action="process_cat.php" target= "_blank" method="post"><input type="hidden" name="action" value="updateCG"><input class="w3-input" type="text" name="groupName" value="'.$row[1].'"></td>';
				echo '<td><center><input type="hidden" name="id" value="'.$row[0].'"><input class="w3-button w3-round-large w3-green" type="submit" value="บันทึก"></form></center></td></tr>';
			$order++;
		}
    echo '</table><br>';
	echo '<center><input type="button" class="w3-button w3-border" value="กลับ" onclick="javascript:history.back()" /></center>';
  }

  else if ($_GET['action']=="csg") {
   echo '<h4>[Create Subject Sub-Group | สร้างกลุ่มวิชาย่อย]</h4></center>';
   echo '<br><br><b>Sub-Group name list..</b> ';
   echo '<table class="w3-table w3-border w3-hoverable w3-margin-top" border="1" style="width:100%;"> ';
   echo '<tr><td style="width:5%;">order</td><td style="width:100%;">sub-group</td></tr> ';
	$result1 = $connect->query('select * FROM subject_subgroup where subgroup_id > 0 and subgroup_id < 8 order by subgroup_id asc');
	$order=1;
		while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
			echo '<tr><td>'.$order.'</td>';
			echo '<td>'.$row[1].'</td></tr>';
			$order++;
		}
    echo '</table><br>';

   echo '<b>Add new sub group..</b>';
   echo '<table class="w3-table w3-border w3-hoverable w3-margin-top" border="1" style="width:100%;"> ';
   echo '<tr><td style="width:5%;">order</td><td style="width:100%;">sub-group</td><td colspan="2" style="width:10%;"><center>action</center></td></tr> ';
	$result1 = $connect->query('select * FROM subject_subgroup where subgroup_id > 7 order by subgroup_id asc');
	$order=1;
		while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
			echo '<tr><td>'.$order.'</td>';
			echo '<td><form name="edt_'.$row[0].'" action="process_cat.php" target= "_blank" method="post"><input type="hidden" name="action" value="updateCSG"><input class="w3-input" type="text" name="subgroupName" value="'.$row[1].'"></td>';
			echo '<td><center><input type="hidden" name="id" value="'.$row[0].'"><input class="w3-button w3-round-large w3-green" type="submit" value="บันทึก"></form></center></td></tr>';
			$order++;
		}
    echo '</table><br>';
	echo '<center><input type="button" class="w3-button w3-border" value="กลับ" onclick="javascript:history.back()" /></center>';
  }
  
  else if ($_GET['action']=="as") {
   echo '<h4>[Add Subject | เพิ่มรายชื่อวิชา]</h4>';
   $result1 = $connect->query('select cur_name FROM curriculum where cur_id='.$_GET['id']);
   while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
		echo '<center><h4>เพิ่มรายชื่อวิชา  ลงใน '.$row[0].'</h4></center>';
   }

   echo '<div><form name="search" action="cur_searchSub.php" method="post"><table class="w3-table w3-hoverable w3-margin-top" border="0" style="width:70%;">';

   	echo '<tr><th>เลือกหมวดวิชา</th>';
	$result3 = $connect->query('select subject_category.* FROM subject_category JOIN match_credit ON match_credit.code = subject_category.category_code where match_credit.cur_id = '.$_GET['id'].' and category_name !="" order by category_id asc');
	echo '<th colspan="2"><select class="w3-select" name="category_id">';
	echo '<option value="0" selected disabled>เลือกหมวดวิชา</option>';
	while($row = mysqli_fetch_array($result3,MYSQLI_NUM)){
		echo '<option value="'.$row[0].'">'.$row[1].'</option>';
	}
   echo '</select></th></tr>';

   	echo '<tr><th>เลือกกลุ่มวิชา</th>';
	$result3 = $connect->query('select subject_group.* FROM subject_group JOIN match_credit ON match_credit.code = subject_group.group_code where match_credit.cur_id = '.$_GET['id'].' and group_name !="" order by group_id asc');
	echo '<th colspan="2"><select class="w3-select" name="group_id">';
	echo '<option value="0" selected disabled>เลือกกลุ่มวิชา</option>';
	while($row = mysqli_fetch_array($result3,MYSQLI_NUM)){
		echo '<option value="'.$row[0].'">'.$row[1].'</option>';
	}
	echo '</select></th></tr>';

    echo '<tr><th style="width:20%;">เลือกกลุ่มวิชาย่อย</th>';
	$result3 = $connect->query('select subject_subgroup.* FROM subject_subgroup JOIN match_credit ON match_credit.code = subject_subgroup.subgroup_code where match_credit.cur_id = '.$_GET['id'].' and subgroup_name !="" order by subgroup_id asc');
	echo '<th colspan="2"><select class="w3-select" name="subgroup_id">';
	echo '<option value="0" selected>ไม่มีกลุ่มวิชาย่อย</option>';
	while($row = mysqli_fetch_array($result3,MYSQLI_NUM)){
		echo '<option value="'.$row[0].'">'.$row[1].'</option>';
	}
	echo '</select></th></tr>';

   echo '</table><br><table><tr><td><input type="hidden" name="id" value="'.$_GET['id'].'"><input class="w3-button w3-block w3-border" type="submit" value="ยืนยัน"></form></td><td>&nbsp;</td><td><form method="GET" action="cur_edit.php"><input type="hidden" name="id" value="'.$_GET['id'].'"><input type="submit" class="w3-button w3-border" value="กลับ"></form><td></tr></table>';

  }

  else if ($_GET['action']=="ac") {
	echo '<h4>[Create Curriculum | เพิ่มหลักสูตร]</h4></center>';
	echo '<br><form name="ac" action="process_cat.php" method="post">';
	echo '<center><table class="w3-table w3-hoverable w3-margin-top" border="0" style="width:85%;" id="myTable1">';
	echo '<tr><th style="width:40%;"><h5><strong>ชื่อเรียกหลักสูตร :</h5></strong></th>';
    echo '<th style="width:80%;"><input class="w3-input w3-border-1" type="text" name="curName" style="width:100%" required></tr>';
	echo '<th colspan="2">&nbsp;</tr>';
	echo '<tr><th><h5><strong>ชื่อหลักสูตรภาษาไทย :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1" type="text" name="curNameTH" style="width:100%" required></tr>';
	echo '<tr><th><h5><strong>ชื่อหลักสูตรภาษาอังกฤษ :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1" type="text" name="curNameEN" style="width:100%" required></tr>';
	echo '<th colspan="2">&nbsp;</tr>';
	echo '<tr><th><h5><strong>ชื่อเต็มปริญญา ภาษาไทย :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1" type="text" name="degreeTH" style="width:100%" required></tr>';
	echo '<tr><th><h5><strong>ชื่อย่อปริญญา ภาษาไทย :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1" type="text" name="dgTH" style="width:100%" required></tr>';
	echo '<tr><th><h5><strong>ชื่อเต็มปริญญา ภาษาอังกฤษ :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1" type="text" name="degreeEN" style="width:100%" required></tr>';
	echo '<tr><th><h5><strong>ชื่อย่อปริญญา ภาษาอังกฤษ :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1" type="text" name="dgEN" style="width:100%" required></tr>';
	echo '<th colspan="2">&nbsp;</tr>';
	echo '<tr><th><h5><strong>วิชาเอก :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1" type="text" name="major" style="width:100%" required></tr>';
	echo '<tr><th><h5><strong>จำนวนหน่วยกิจตลอดหลักสูตร :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1" type="text" name="sumCredit" style="width:100%" required></tr>';
	echo '<tr><th><h5><strong>รูปแบบของหลักสูตร :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1" type="text" name="fomatYear" style="width:100%" required></tr>';
	echo '<tr><th><h5><strong>ภาษาที่ใช้ :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1" type="text" name="language" style="width:100%" required></tr>';
	echo '<tr><th><h5><strong>การรับเข้าศึกษา :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1" type="text" name="StdRecieve" style="width:100%" required></tr>';
	echo '<tr><th><h5><strong>ความร่วมมือกับสถาบันอื่น :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1" type="text" name="coopOT" style="width:100%" required></tr>';
	echo '<tr><th><h5><strong>การให้ใบปริญญาแก่ผู้สำเร็จการศึกษา :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1" type="text" name="degreeGive" style="width:100%" required></tr>';
	echo '<tr><th><h5><strong>อาชีพที่สามารถประกอบได้หลังสําเร็จการศึกษา :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1" type="text" name="careerSP" style="width:100%" required></tr>';
	echo '</table></center> ';

	echo '<br><center><table border="0" style="width:85%;" id="myTable1">';
	echo '<tr><th><center><input type="hidden" name="action" value="ac"><input class="w3-button w3-round-large w3-green" type="submit" value="บันทึก"></form>&nbsp;<input type="button" class="w3-button w3-round-large w3-text-white w3-gray" value="กลับ" onclick="javascript:history.back()" /></center></th></tr>';
    echo '</table></center> ';
  
  }
	
  else if ($_SESSION['err']=="1"){
	echo '<br><div class="w3-panel w3-pale-red w3-card-4">';
    echo '<p>failure | กรุณาตวจสอบว่ากรอกข้อมูลถูกต้อง และครบถ้วน</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Back | กลับ" onclick="javascript:history.back()" />';
  }

  else if ($_SESSION['err']=="7"){
	echo '<br><div class="w3-panel w3-pale-red w3-card-4">';
    echo '<p>failure | ไม่สามารถเพิ่มรายวิชาซ้ำกันลงในหลักสูตรได้</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Back | กลับ" onclick="window.close();" />';
  }

  else if ($_SESSION['err']=="0"){
	echo '<br><div class="w3-panel w3-metro-light-blue w3-card-4">';
    echo '<p>Success | เพิ่มข้อมูลสำเร็จ</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Back | กลับ" onclick="javascript:history.back()" />';
  }

  else if ($_SESSION['err']=="2"){
	echo '<br><div>';
	echo '<input type="button" class="w3-button w3-border" value="Close | กลับ" onclick="javascript:history.back()" />';
	echo '</div>';
  }

  else if ($_SESSION['err']=="3"){
	echo '<br><div class="w3-panel w3-metro-light-blue w3-card-4">';
    echo '<p>Success | ลบข้อมูลสำเร็จ</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Close | ปิดหน้าต่าง" onclick="window.close();" />';
  }

    else if ($_SESSION['err']=="4"){
	echo '<br><div class="w3-panel w3-metro-light-blue w3-card-4">';
    echo '<p>Success | เพิ่มข้อมูลสำเร็จ</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Back | กลับ" onclick="window.close();" />';
  }

  else if ($_SESSION['err']=="5"){
	echo '<br><div>';
	echo '<input type="button" class="w3-button w3-border" value="Close | ปิดหน้าต่าง" onclick="window.close();" />';
	echo '</div>';
  }

  else if ($_SESSION['err']=="6"){
	echo '<br><div class="w3-panel w3-metro-light-blue w3-card-4">';
	echo '<p>Success | ลบข้อมูลสำเร็จ</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Back | กลับ" onclick="javascript:history.back()" />';
	
  }

  $_SESSION['err']=2;
  ?> 

  </div>   
</div> 
<!-- End page content -->
<br><br><br></div>
</body>
</html>
