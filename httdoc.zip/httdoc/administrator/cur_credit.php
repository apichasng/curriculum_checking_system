<?php 
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
include("../connect/connect.php");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php if($_GET['action']=="acr") include("inc.topbar_admin.php"); 
	  else include("inc.topbar_adminx.php"); ?>

<!-- Header  -->
<div class="w3-container w3-light-grey w3-border w3-left-align">
	<br><h3 style="text-shadow:1px 1px 0 #444">ระบบตรวจสอบหลักสูตร วิทยาลัยการคอมพิวเตอร์ มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต [สำหรับเจ้าหน้าที่]</h3>
	<h5 style="text-shadow:1px 1px 0 #444">Curriculum checking system [Admin page]</h5><br>
<div>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:80%">
	<br><center><h3 style="text-shadow:1px 1px 0 #444">Credit Management</h3>

<?php

 if ($_GET['action']=="acr") {

	$credit_chk=0;
	$result0 = $connect->query('select cur_id FROM match_credit group by cur_id' );
	while($row0 = mysqli_fetch_array($result0,MYSQLI_NUM)){
		if($row0[0]==$_GET['id']) $credit_chk=1;
	}

	if($credit_chk==0){

		echo '<h4>[จำนวนหน่วยกิตรวม ตลอดหลักสูตร ]</h4></center>';
		echo '<br><form name="acr" action="process_cat.php" method="post">';
		for($i=1;$i<11;$i++){
			echo '<input type="hidden" name="c'.$i.'" value="0">';
		}
		for($i=1;$i<11;$i++){
			echo '<input type="hidden" name="g'.$i.'" value="0">';
		}
		for($i=0;$i<16;$i++){
			echo '<input type="hidden" name="sg'.$i.'" value="0">';
		}

		echo '<center><table class="w3-table w3-margin-top" border="0" style="width:75%;" id="myTable1">';
		echo '<tr><th colspan="2"><h5><center>หน่วยกิตรวมในแต่ละหมวดวิชา</center></h5></th>';
		$connect->query("set names utf8");
		$result1 = $connect->query('select * FROM subject_category where category_name !="" order by category_id asc');
		$order=1;
		while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
				echo '<tr><th><h5><strong>'.$row[1].' :</strong></h5></th>';
				echo '<th><input class="w3-input w3-border-1" type="number" name="c'.$order.'" value="0" style="width:100%"></tr>';
				$order++;
		}

		echo '<tr><th colspan="2"><h5><center>หน่วยกิตรวมในแต่ละกลุ่มวิชา</center></h5></th>';
		$connect->query("set names utf8");
		$result1 = $connect->query('select * FROM subject_group where group_name !="" order by group_id asc');
		$order=1;
		while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
				echo '<tr><th><h5><strong>'.$row[1].' :</strong></h5></th>';
				echo '<th><input class="w3-input w3-border-1" type="number" name="g'.$order.'" value="0" style="width:100%"></tr>';
				$order++;
		}

		echo '<tr><th colspan="2"><h5><center>หน่วยกิตรวมในแต่ละกลุ่มวิชาย่อย /รายวิชาย่อย</center></h5></th>';
		$connect->query("set names utf8");
		$result1 = $connect->query('select * FROM subject_subgroup where subgroup_id > 0 and subgroup_name !="" order by subgroup_id asc');
		$order=1;
		while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
				echo '<tr><th><h5><strong>'.$row[1].' :</strong></h5></th>';
				echo '<th><input class="w3-input w3-border-1" type="number" name="sg'.$order.'" value="0" style="width:100%"></tr>';
				$order++;
		}

		echo '<tr><th colspan="2"><center><input type="hidden" name="action" value="acr"><input type="hidden" name="id" value="'.$_GET['id'].'"><input class="w3-button w3-round-large w3-green" type="submit" value="บันทึก"></form></center></th></tr>';
		echo '</table></center> ';
	}

	else {

		echo '<h4>[จำนวนหน่วยกิตรวม ตลอดหลักสูตร ]</h4></center>';
		echo '<br><form name="ucr" action="process_cat.php" method="post">';
		echo '<center><table class="w3-table w3-margin-top" border="0" style="width:75%;" id="myTable1">';

		echo '<tr><th colspan="2"><h5><center>หน่วยกิตรวมในแต่ละหมวดวิชา</center></h5></th>';
		$connect->query("set names utf8");
		$result1 = $connect->query('select subject_category.*, match_credit.credit FROM subject_category join match_credit on match_credit.code = subject_category.category_code where match_credit.cur_id="'.$_GET[id].'" and subject_category.category_name !="" order by category_id asc');
		$order=1;
		while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
				echo '<tr><th><h5><strong>'.$row[1].' :</strong></h5></th>';
				echo '<th><input class="w3-input w3-border-1" type="number" name="c'.$order.'"  value="'.$row[3].'" style="width:100%"></tr>';
				$order++;
		}

		echo '<tr><th colspan="2"><h5><center>หน่วยกิตรวมในแต่ละกลุ่มวิชา</center></h5></th>';
		$connect->query("set names utf8");
		$result1 = $connect->query('select subject_group.*, match_credit.credit FROM subject_group join match_credit on match_credit.code = subject_group.group_code where match_credit.cur_id="'.$_GET[id].'" and group_name !="" order by group_id asc');
		$order=1;
		while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
				echo '<tr><th><h5><strong>'.$row[1].' :</strong></h5></th>';
				echo '<th><input class="w3-input w3-border-1" type="number" name="g'.$order.'" value="'.$row[3].'" style="width:100%"></tr>';
				$order++;
		}

		echo '<tr><th colspan="2"><h5><center>หน่วยกิตรวมในแต่ละกลุ่มวิชาย่อย /รายวิชาย่อย</center></h5></th>';
		$connect->query("set names utf8");
		$result1 = $connect->query('select subject_subgroup.*, match_credit.credit FROM subject_subgroup join match_credit on match_credit.code = subject_subgroup.subgroup_code where match_credit.cur_id="'.$_GET[id].'" and subgroup_id > 0 and subgroup_name !="" order by subgroup_id asc');
		$order=1;
		while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
				echo '<tr><th><h5><strong>'.$row[1].' :</strong></h5></th>';
				echo '<th><input class="w3-input w3-border-1" type="number" name="sg'.$order.'" value="'.$row[3].'" style="width:100%"></tr>';
				$order++;
		}

		echo '</table></center>';
		echo '<br><center><table><tr><td><input type="hidden" name="action" value="ucr"><input type="hidden" name="id" value="'.$_GET['id'].'"><input class="w3-button w3-round-large w3-green" type="submit" value="บันทึก"></form></td><td><form action="process_cat.php" method="POST" ><input type="hidden" name="action" value="dcr"><input type="hidden" name="id" value="'.$_GET['id'].'"><input class="w3-button w3-round-large w3-red" type="submit" value="ล้าง"></form></td><td><input type="button" class="w3-button w3-round-large w3-text-white w3-gray" value="กลับ" onclick="javascript:history.back()" /></center></td></tr></table>';
	}
  
  }
	
  else if ($_SESSION['err']=="1"){
	echo '<br><div class="w3-panel w3-pale-red w3-card-4">';
    echo '<p>failure | กรุณาตวจสอบว่ากรอกข้อมูลถูกต้อง และครบถ้วน</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Close | ปิดหน้าต่าง" onclick="window.close();" />';
  }

  else if ($_SESSION['err']=="0"){
	echo '<br><div class="w3-panel w3-metro-light-blue w3-card-4">';
    echo '<p>Success | เพิ่มข้อมูลสำเร็จ</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Back | กลับ" onclick="javascript:history.back()" />';
  }

  else if ($_SESSION['err']=="2"){
	echo '<br><div>';
	echo '<input type="button" class="w3-button w3-border" value="Close | กลับ" onclick="javascript:history.back()" />';
	echo '</div>';
  }

  else if ($_SESSION['err']=="3"){
	echo '<br><div class="w3-panel w3-metro-light-blue w3-card-4">';
    echo '<p>Success | ลบข้อมูลสำเร็จ</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Close | ปิดหน้าต่าง" onclick="window.close();" />';
  }

    else if ($_SESSION['err']=="4"){
	echo '<br><div class="w3-panel w3-metro-light-blue w3-card-4">';
    echo '<p>Success | เพิ่มข้อมูลสำเร็จ</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Back | กลับ" onclick="window.close();" />';
  }

  else if ($_SESSION['err']=="5"){
	echo '<br><div>';
	echo '<input type="button" class="w3-button w3-border" value="Close | กลับ" onclick="window.close();" />';
	echo '</div>';
  }

  $_SESSION['err']=2;
  ?> 

  </div>   
</div> 
<!-- End page content -->
<br><br><br></div>
</body>
</html>
