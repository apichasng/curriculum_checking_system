<meta charset="UTF-8">
  <meta name="Generator" content="EditPlus®">
  <meta name="Author" content="">
  <meta name="Keywords" content="">
  <meta name="Description" content="">
<center><div class="w3-top">
<div class="w3-black w3-right-align">
 <?php 
 session_start();
 echo '['.$_SESSION["permistion"].']&nbsp'.$_SESSION["ID2"].'&nbsp'.$_SESSION["title"].$_SESSION["name"].'&nbsp'.$_SESSION["surname"].'&nbsp;[access: '.$_SESSION["latest_time"].']&nbsp;&nbsp;&nbsp;';
 ?>
</div>
</div></center>