<?php 
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<script>
function click(id){
	document.location.href = 'cur_edit.php?&id='+id;
}
</script>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.topbar_admin.php"); ?>

<!-- Header  -->
<br/><div class="w3-container w3-light-grey w3-border w3-left-align">
	<br><h3 style="text-shadow:1px 1px 0 #444">ระบบตรวจสอบหลักสูตร วิทยาลัยการคอมพิวเตอร์ มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต [สำหรับเจ้าหน้าที่]</h3>
	<h5 style="text-shadow:1px 1px 0 #444">Curriculum checking system [Admin page]</h5><br>
<div>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:80%">
	<br><center><h3 style="text-shadow:1px 1px 0 #444">Curriculum Management</h3></center>
	<br><table class="w3-responsive"><tr> 

	<td><input type = "submit" value="เพิ่มหลักสูตรใหม่" name="เพิ่มหลักสูตรใหม่" class="w3-button w3-teal" onClick="javascript:location.href='cur_create.php?action=ac'"></td>
	<td><input type = "submit" value="เพิ่มกลุ่มวิชา" name="เพิ่มกลุ่มวิชา" class="w3-button w3-teal" onClick="javascript:location.href='cur_create.php?action=cg'"></td>
	<td><input type = "submit" value="เพิ่มกลุ่มวิชาย่อย" name="เพิ่มกลุ่มวิชาย่อย" class="w3-button w3-teal" onClick="javascript:location.href='cur_create.php?action=csg'"></td>
    </tr></table>

	<br><table><tr><td style="width:100%;"><form method="GET" action="cur_mgt.php"><input class="w3-input w3-border" type="text" name="search" value="<?php echo $_GET['search']; ?>"></td><td>&nbsp;</td><td style="width:5%;"><input class="w3-button w3-round-large w3-green" type="submit" value="ค้นหา"></form></td></tr></table>

    <table class="w3-table w3-border w3-hoverable w3-margin-top" border="1" style="width:100%;" id="myTable1">
    <tr class="w3-light-grey">
      <th style="width:5%;" align="center">order</th>
	  <th style="width:90%;" align="center">curriculum's name</th>
	  <th style="width:10%;" align="center">edit</th>
    </tr>
	
<?php 
	include("../connect/connect.php");
	$connect->query("set names utf8");
	$result = $connect->query('select * FROM curriculum where cur_name like "%'.$_GET['search'].'%" or cur_nameTH like "%'.$_GET['search'].'%" or cur_nameEN like "%'.$_GET['search'].'%" or degreeTH like "%'.$_GET['search'].'%" or degreeEN like "%'.$_GET['search'].'%" or dgTH like "%'.$_GET['search'].'%" or dgEN like "%'.$_GET['search'].'%" order by cur_name asc, cur_nameTH asc');
	
	if(!isset($_GET['page']))$_GET['page']=1;
	$page=$_GET['page'];
	$rows="20";
	$total_data = mysqli_num_rows($result);
	$total_page = ceil($total_data/$rows);
	$start=($page-1)*$rows;
	$Connum=(($page*20)-20)+1;
	$order=$Connum;

	$result1 = $connect->query('select * FROM curriculum where cur_name like "%'.$_GET['search'].'%" or cur_nameTH like "%'.$_GET['search'].'%" or cur_nameEN like "%'.$_GET['search'].'%" or degreeTH like "%'.$_GET['search'].'%" or degreeEN like "%'.$_GET['search'].'%" or dgTH like "%'.$_GET['search'].'%" or dgEN like "%'.$_GET['search'].'%" order by cur_name asc, cur_nameTH asc Limit '.$start.',20');
	while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
		echo '<tr><td>'.$order.'</td>';
		echo '<td>'.$row[1].'</td>';
		echo '<td><center><a href="javascript:click('.$row[0].')" class="w3-button w3-round-large tahoma11boldlink"><i class="fa fa-edit" style="color:blue;" aria-hidden="true"></i></a></td></center></td></tr>';
		$order++;
	}
	if($order==1) echo '<td colspan="4"><center>- ไม่มีข้อมูล -</center></td></tr>';
	echo '</table>';

	$Connum=-19;
	$Nextpage=$page+1;
	$Prepage=$page-1;
?> 
	<br><center><table style="width:40%;"><tr>
	<td style="width:5%;"><input type="submit" value="<<" class="w3-button w3-teal" onClick="javascript:location.href='cur_mgt.php?page=1&search=<?php echo $_GET['search']; ?>'" <?php if($page<=1) echo 'disabled'; ?>></td>
	<td style="width:5%;"><input type="submit" value="<" class="w3-button w3-teal" onClick="javascript:location.href='cur_mgt.php?page=<?php echo $Prepage; ?>&search=<?php echo $_GET['search']; ?>'" <?php if($page<=1) echo 'disabled'; ?>></td>

	<td style="width:10%;"><form method="GET" action="cur_mgt.php"><input class="w3-input w3-border w3-center" type="number" name="page" value="<?php echo $_GET['page']; ?>"></td><td style="width:10%;" align="center"><?php echo ' / '.$total_page; ?></td><td style="width:5%;"><input type="hidden" value="search"><input class="w3-button" type="submit" value="go page"></form></td>

	<td style="width:5%;"><input type="submit" value=">" class="w3-button w3-teal" onClick="javascript:location.href='cur_mgt.php?page=<?php echo $Nextpage; ?>&search=<?php echo $_GET['search']; ?>'" <?php if($page>=$total_page) echo 'disabled'; ?>></td>
	<td style="width:5%;"><input type="submit" value=">>" class="w3-button w3-teal" onClick="javascript:location.href='cur_mgt.php?page=<?php echo $total_page; ?>&search=<?php echo $_GET['search']; ?>'" <?php if($page>=$total_page) echo 'disabled'; ?>></td>
	</tr></table></center>
   
  </div>   
</div> 
<!-- End page content -->
<br><br><br></div>
</body>
</html>
