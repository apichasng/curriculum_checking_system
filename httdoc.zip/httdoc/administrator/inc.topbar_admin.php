<meta charset="UTF-8">
  <meta name="Generator" content="EditPlus®">
  <meta name="Author" content="">
  <meta name="Keywords" content="">
  <meta name="Description" content="">
<center><div class="w3-top">
<div class="w3-black w3-right-align">
 <?php 
 session_start();
 echo '['.$_SESSION["permistion"].']&nbsp'.$_SESSION["ID2"].'&nbsp'.$_SESSION["title"].$_SESSION["name"].'&nbsp'.$_SESSION["surname"].'&nbsp;[access: '.$_SESSION["latest_time"].']&nbsp;&nbsp;&nbsp;';
 ?>
</div>
<div class="w3-teal">
	<center><table align="center"  data-role="table"  id="movie-table" data-mode="reflow" class="w3-responsive">
			<thead>
				<tr><th></th></tr> 
			</thead>
			<tbody>
				<tr>
					<td><a href="admin.php" class="w3-button"><i class="fa fa-home" aria-hidden="true"></i>&nbsp;&nbsp;Home</a></td>
					<td><a href="sub_mgt.php" class="w3-button"><i class="fa fa-file-text" aria-hidden="true"></i>&nbsp;&nbsp;Subject Management</a></td>
					<td><a href="cur_mgt.php" class="w3-button"><i class="fa fa-database" aria-hidden="true"></i>&nbsp;&nbsp;Curriculum Management</a></td>
					<td><a href="cur_match.php" class="w3-button"><i class="fa fa-sitemap" aria-hidden="true"></i>&nbsp;&nbsp;Curriculum Matching</a></td>
					<td><a href="user_mgt.php" class="w3-button"><i class="fa fa-user-plus" aria-hidden="true"></i>&nbsp;&nbsp;User Management</a></td>
					<td><a href="logout.php" class="w3-button"><i class="fa fa-sign-out" aria-hidden="true"></i>&nbsp;&nbsp;Logout</a></td>
				</tr>
				</tbody>
</table></center>
</div>

</div></center>
<br/><br/>