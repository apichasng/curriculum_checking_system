<?php 
session_start();
$_SESSION["sentFrom"]="AD";
if ($_SESSION["permistion"]=="admin") header("location:../administrator/admin.php");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<style>
.bgimg {
    background-position: center;
    background-size: cover;
    background-image: url("../img/picHead1.jpg");
    min-height: 90%;
}
</style>
<?php include("../inc.includeCss.php"); ?>
<body bgcolor="#cccccc">
<!-- topbar -->

<!-- Header  -->
<header class="bgimg w3-display-container" id="admin">
  <center><div class="w3-padding-large w3-display-middle w3-light-grey w3-border w3-left-align ">
	<br><h3 style="text-shadow:1px 1px 0 #444">วิทยาลัยการคอมพิวเตอร์ มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต</h3>
	<center><h3 style="text-shadow:1px 1px 0 #444">ระบบตรวจสอบหลักสูตร</h3></center>
	<center><h5 style="text-shadow:1px 1px 0 #444">Curriculum checking system</h5></center>
	<br/><center>[สำหรับเจ้าหน้าที่]</center>
	<div>
		<form role="form" name="login_form_1" action="../login/check_log.php" method="post">
		<center><table width="80%">
		<tr><td valign="middle" ><i class="w3-large fa fa-user"></i>&nbsp;Username : </td></tr>
		<tr><td align="center"><input class="w3-input w3-animate-input" style="width:80%" name="user_id" type="text"></td></tr>
		<tr><td valign="middle" ><i class="w3-large fa fa-key"></i>&nbsp;Password : </td></tr>
		<tr><td align="center"><input class="w3-input w3-animate-input" style="width:80%" name="user_pwd" type="password"></td></tr>	
		<tr><td>&nbsp;</td></tr>
		<tr><td valign="middle" align="center"><input class="w3-button w3-round-large" style="width:60%" type="submit" value="Login"></td><tr><td>&nbsp;</td></tr></form></tr></table></center>
    </div>
  </div></center>
</header>

<!-- Footer -->
</body>
</html>
