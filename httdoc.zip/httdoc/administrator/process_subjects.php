<?php 
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
include("../connect/connect.php");
$connect->query("set names utf8");


if($_POST['action']=="sas") {
	if( ($_POST['subjects_code']=="") or ($_POST['subjects_name_TH']=="") or ($_POST['subjects_name_EN']=="") or ($_POST['subjects_credit']=="") ) {
		$_SESSION['err']=6;
	}
	else {	
		$sql=('INSERT INTO subjects (subjects_id, subjects_code, subjects_name_TH, subjects_name_EN, subjects_credit) VALUES ("","'.$_POST['subjects_code'].'","'.$_POST['subjects_name_TH'].'","'.$_POST['subjects_name_EN'].'","'.$_POST['subjects_credit'].'")');
		$result = mysqli_query($connect,$sql);
		$_SESSION['err']=4;
	}

	header("location:sub_create.php");
}



?>
