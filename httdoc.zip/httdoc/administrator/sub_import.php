<?php 
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
$complete=""; 
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.topbar_admin.php"); ?>

<!-- Header  -->
<br/><div class="w3-container w3-light-grey w3-border w3-left-align">
	<br><h3 style="text-shadow:1px 1px 0 #444">ระบบตรวจสอบหลักสูตร วิทยาลัยการคอมพิวเตอร์ มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต [สำหรับเจ้าหน้าที่]</h3>
	<h5 style="text-shadow:1px 1px 0 #444">Curriculum checking system [Admin page]</h5><br>
<div>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:75%">
	<?php 
	if(isset($_FILES['excell'])){ 

		echo '<br><br>'; 
		$errors= array();
		$file_name = $_FILES['excell']['name'];
		$file_size =$_FILES['excell']['size'];
		$file_tmp =$_FILES['excell']['tmp_name'];
		$file_type=$_FILES['excell']['type']; 

		if ($file_name==""){
			echo '<div class="w3-panel w3-pale-red w3-card-4"><center><p>!! กรุณาเลือกไฟล์ เพื่อ นำเข้าข้อมูล  !!</p></center></div>';
		} 
		else {  
			$complete="incomplete";
			if(empty($errors)==true){
				move_uploaded_file($file_tmp,"../upload/excell_upload/".$file_name);
				include("../connect/connect.php");
			$connect->query("set names utf8");
			$file=$file_name;
			$objCSV = fopen("../upload/excell_upload/".$file, "r");
 			$err=0;
			while (($objArr = fgetcsv($objCSV, 1000, ",")) !== FALSE) {
				$complete="incomplete";
				$space=""; 
				$strSQL = "INSERT INTO subjects";
				$strSQL .="(subjects_id, subjects_code, subjects_name_TH, subjects_name_EN, subjects_credit)";
				$strSQL .="VALUES ";
				$strSQL .="('".$space."','".$objArr[0]."','".$objArr[1]."','".$objArr[2]."','".$objArr[3]."') ";

				if ($objArr[0]!="" or $objArr[1]!="" or $objArr[2]!="" or $objArr[3]!="" ) {
					$result = $connect->query('select * FROM subjects');
					while($row = mysqli_fetch_array($result,MYSQLI_NUM)){
						if($row[1]==$objArr[0]) $err=1;
					}
					if($err==0){
						$objQuery = $connect->query($strSQL);
						$complete="complete";
					}
					$err=0;
				}  
			}

			if ($complete=="complete")echo '<div class="w3-panel w3-pale-green w3-card-4"><center><p> นำเข้าข้อมูลสำเร็จ</p></center></div>';
			else echo '<div class="w3-panel w3-pale-green w3-card-4"><center><p> นำเข้าข้อมูลสำเร็จ  </p></center></div>';
			fclose($objCSV); 
			} 

			else{
				echo '<div class="w3-panel w3-red w3-display-container"><p>นำเข้าข้อมูล ไม่สำเร็จ !!</p></div>';
			}
			
		}
	}
?>
	<br><center>	
	<form action="" method="POST" enctype="multipart/form-data">
    <table class="w3-table w3-border w3-margin-top" border="1" style="width:40%;" id="myTable1">
    <tr class="w3-light-grey">
      <th><center>นำเข้ารายวิชา</center></th>
    </tr>
	<tr>
      <td><input type="file" name="excell" class="w3-button w3-block w3-border" required>&nbsp;<br>&nbsp;** รองรับไฟล์ .csv เท่านั้น<br><br><center><input type="submit" class="w3-button w3-border" value="ยืนยัน">&nbsp;<input type="button" class="w3-button w3-border" value="กลับ" onclick="javascript:history.back()" /></center></td>
	</tr></table></form>
	<table class="w3-table w3-margin-top" style="width:40%;">
	<tr><td  class="w3-center"><small>
		<a href="doc/user_manual_import_subjects.pdf" target="_blank">* วิธีการจัดเตรียมข้อมูล และนำเข้าข้อมูลรายชื่อวิชา  *</a>
	</small></td></tr></table>

  </div>   
</div> 
<!-- End page content -->
<br><br><br></div>
</body>
</html>
