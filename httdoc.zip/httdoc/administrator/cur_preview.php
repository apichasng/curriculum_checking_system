<?php 
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.topbar_adminx.php"); ?>

<!-- Header  -->
<div class="w3-container w3-light-grey w3-border w3-left-align">
	<br><h3 style="text-shadow:1px 1px 0 #444">ระบบตรวจสอบหลักสูตร วิทยาลัยการคอมพิวเตอร์ มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต [สำหรับเจ้าหน้าที่]</h3>
	<h5 style="text-shadow:1px 1px 0 #444">Curriculum checking system [Admin page]</h5><br>
<div>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:80%">
  <?php 
   include("../connect/connect.php");
	$connect->query("set names utf8");
	$result1 = $connect->query('select * FROM curriculum where cur_id='.$_GET['id']);
	while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
		echo '<br><center><h3 style="text-shadow:1px 1px 0 #444">'.$row[1].'</h3>';
		echo '<br><table class="w3-table w3-margin-top border="0" style="width:100%;" id="myTable1">';
		echo '<tr><th style="width:40%;"><strong>ชื่อสถาบันอุดมศึกษา</strong></th>';
		echo '<th style="width:90%;">มหาวิทยาลัยสงขลานครินทร์</th></tr>';
		echo '<tr><th><strong>วิทยาเขต</strong></th>';
		echo '<th>วิทยาเขตภูเก็ต</th></tr>';
		echo '<tr><th colspan="2"><center><strong><br>ข้อมูลทั่วไป</strong></center></th></tr>';
		echo '<tr><th colspan="2"><strong>1. รหัสและชื่อหลักสูตร</strong></th></tr>';
		echo '<tr><th><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ชื่อหลักสูตรภาษาไทย</strong></th>';
		echo '<th>'.$row[2].'</tr>';
		echo '<tr><th><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ชื่อหลักสูตรภาษาอังกฤษ</strong></th>';
		echo '<th>'.$row[3].'</tr>';
		echo '<tr><th colspan="2"><strong>2. ชื่อปริญญาและสาขาวิชา</strong></th></tr>';
		echo '<tr><th><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ชื่อเต็มปริญญา ภาษาไทย</strong></th>';
		echo '<th>'.$row[4].'</tr>';
		echo '<tr><th><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ชื่อย่อปริญญา ภาษาไทย</strong></th>';
		echo '<th>'.$row[5].'</tr>';
		echo '<tr><th><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ชื่อเต็มปริญญา ภาษาอังกฤษ</strong></th>';
		echo '<th>'.$row[6].'</tr>';
		echo '<tr><th><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ชื่อย่อปริญญา ภาษาอังกฤษ</strong></th>';
		echo '<th>'.$row[7].'</tr>';
		echo '<tr><th><strong>3. วิชาเอก</strong></th>';
		echo '<th>'.$row[8].'</tr>';
		echo '<tr><th><strong>4. จำนวนหน่วยกิจตลอดหลักสูตร</strong></th>';
		echo '<th>'.$row[9].'</tr>';
		echo '<tr><th colspan="2"><strong>5. รูปแบบของหลักสูตร</strong></th></tr>';
		echo '<tr><th><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5.1 รูปแบบ</strong></th>';
		echo '<th>'.$row[10].'</tr>';
		echo '<tr><th><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5.2 ภาษาที่ใช้</strong></th>';
		echo '<th>'.$row[11].'</tr>';
		echo '<tr><th><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5.3 การรับเข้าศึกษา</strong></th>';
		echo '<th>'.$row[12].'</tr>';
		echo '<tr><th><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5.4 ความร่วมมือกับสถาบันอื่น</strong></th>';
		echo '<th>'.$row[13].'</tr>';
		echo '<tr><th><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5.5 การให้ใบปริญญาแก่ผู้สำเร็จการศึกษา</strong></th>';
		echo '<th>'.$row[14].'</tr>';
		echo '<tr><th><strong>6. อาชีพที่สามารถประกอบได้หลังสําเร็จการศึกษา</strong></th>';
		echo '<th>'.$row[15].'</tr>';
	}

    echo '</table> ';

  ?> 

  </div>   
</div> 
<!-- End page content -->
<br><br><br></div>
</body>
</html>
