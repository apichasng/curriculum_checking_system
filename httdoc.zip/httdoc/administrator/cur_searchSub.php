<?php 
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
$_SESSION['err']=3;
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.topbar_adminx.php"); ?>

<!-- Header  -->
<div class="w3-container w3-light-grey w3-border w3-left-align">
	<br><h3 style="text-shadow:1px 1px 0 #444">ระบบตรวจสอบหลักสูตร วิทยาลัยการคอมพิวเตอร์ มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต [สำหรับเจ้าหน้าที่]</h3>
	<h5 style="text-shadow:1px 1px 0 #444">Curriculum checking system [Admin page]</h5><br>
<div>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:80%">
	<br><center><h3 style="text-shadow:1px 1px 0 #444">Curriculum Management</h3>
  <?php 
   include("../connect/connect.php");
   $connect->query("set names utf8");

   if (($_POST['group_id']==0) or ($_POST['category_id']==0)){
	   $_SESSION['err']="1";
	   header("location:cur_create.php");
   }

   if ($_POST['search']=="") $_POST['search']="%%";
   echo '<h4>[Add Subject | เพิ่มรายชื่อวิชา]</h4></center>';

   if ($_POST['subgroup_id']!="0") {
	   $result11 = $connect->query('select * FROM subject_subgroup where subgroup_id='.$_POST['subgroup_id']);
	   while($row11 = mysqli_fetch_array($result11,MYSQLI_NUM)){
			$subgroup = $row11[1];
	   }
   }

   $result12 = $connect->query('select * FROM subject_group where group_id='.$_POST['group_id']);
   while($row12 = mysqli_fetch_array($result12,MYSQLI_NUM)){
		$group = $row12[1];
   }

   $result13 = $connect->query('select * FROM subject_category where category_id='.$_POST['category_id']);
   while($row13 = mysqli_fetch_array($result13,MYSQLI_NUM)){
		$category = $row13[1];
   }

   $result1 = $connect->query('select cur_name FROM curriculum where cur_id='.$_POST['id']);
   while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
		echo '<center><h3><br> '.$row[0].'</h3><h4>'.$category.' > '.$group;
		if ($_POST['subgroup_id']!="0") echo' > '.$subgroup.'</h4></center>';
   }

   echo '<br><center><table class="w3-table w3-margin-top" style="width:70%;"><tr><td><form name="search" action="cur_searchSub.php" method="post">';
   
   if($_POST['search']=="%%") echo '<tr><td><input type="text" class="w3-input w3-border-2" name="search" value=""></td>';
   else echo '<tr><td><input type="hidden" name="id" value="'.$_POST['id'].'"><input type="hidden" name="subgroup_id" value="'.$_POST['subgroup_id'].'"><input type="hidden" name="group_id" value="'.$_POST['group_id'].'"><input type="hidden" name="category_id" value="'.$_POST['category_id'].'"><input type="hidden" name="action" value="as"><input type="text" class="w3-input w3-border-1" name="search" value="'.$_POST['search'].'"></td>';
   
   echo '<td style="width:10%;"><input type="hidden" name="subgroup_id" value="'.$_POST['subgroup_id'].'">';
   echo '<input type="hidden" name="group_id" value="'.$_POST['group_id'].'">';
   echo '<input type="hidden" name="category_id" value="'.$_POST['category_id'].'">';
   echo '<input type="hidden" name="id" value="'.$_POST['id'].'">';
   echo '<input type="submit" class="w3-button w3-round-large w3-light-grey" value="ค้นหา"></form></td></tr>';
   
   echo '<tr><td colspan="2">';
   echo '<form name="save" action="process_cat.php" target= "_blank" method="post">';
	$result2 = $connect->query('select * FROM subjects where subjects_code like "%'.$_POST['search'].'%" or subjects_name_TH like "%'.$_POST['search'].'%" or subjects_name_EN like "%'.$_POST['search'].'%"');
	echo '<select class="w3-select" name="subject_code" >';
	echo '<option value="0" selected disabled>เลือกรายวิชา</option>';
	while($row = mysqli_fetch_array($result2,MYSQLI_NUM)){
		echo '<option value="'.$row[1].'">'.$row[1].'&nbsp;'.$row[2].'</option>';
	}
	echo '</select></td></tr>';

	echo '<tr><td colspan="2">';
	echo '<select class="w3-select" name="subject_type">';
	echo '<option value="0" selected disabled>เลือกประเภทวิชา</option>';
		echo '<option value="1">วิชาบังคับเรียน</option>';
		echo '<option value="2">วิชาเลือก</option>';
	echo '</select></td></tr></table>';

	echo '<input type="hidden" name="action" value="as">';
	echo '<br><center><table><tr><td><input type="hidden" name="id" value="'.$_POST['id'].'">';
	echo '<input type="hidden" name="subgroup_id" value="'.$_POST['subgroup_id'].'">';
    echo '<input type="hidden" name="group_id" value="'.$_POST['group_id'].'">';
    echo '<input type="hidden" name="category_id" value="'.$_POST['category_id'].'">';
    echo '<input type="submit" class="w3-button w3-block w3-border" value="ยืนยัน"></form></td>';

	echo '<td>&nbsp;</td><td><form method="GET" action="cur_create.php"><input type="hidden" name="id" value="'.$_POST['id'].'"><input type="hidden" name="action" value="as"><input type="submit" class="w3-button w3-border" value="กลับ"></form></td></tr></table></center>';

  ?> 

  </div>   
</div> 
<!-- End page content -->
<br><br><br></div>
</body>
</html>
