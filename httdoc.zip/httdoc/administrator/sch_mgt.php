<?php 
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.topbar_admin.php"); ?>

<!-- Header  -->
<br/><div class="w3-container w3-light-grey w3-border w3-left-align">
	<br><h3 style="text-shadow:1px 1px 0 #444">ระบบตรวจสอบหลักสูตร วิทยาลัยการคอมพิวเตอร์ มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต [สำหรับเจ้าหน้าที่]</h3>
	<h5 style="text-shadow:1px 1px 0 #444">Curriculum checking system [Admin page]</h5><br>
<div>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:80%">
	<br><center><h3 style="text-shadow:1px 1px 0 #444">Schedule Management</h3></center>
	<input class="w3-button w3-teal" type = "submit" value="Add" name="Add" onClick="javascript:location.href='#'">&nbsp;<input class="w3-button w3-teal" type = "submit" value="Import" name="Import" onClick="javascript:location.href='#'">
    <table class="w3-table w3-border w3-hoverable w3-responsive w3-margin-top" border="1" style="width:100%;" id="myTable1">
    <tr class="w3-light-grey">
      <th style="width:5%;" align="center">order</th>
	  <th style="width:10%;" align="center">username</th>
	  <th style="width:30%;" align="center">name</th>
	  <th style="width:20%;" align="center">email</th>
	  <th style="width:10%;" align="center">position</th>
	  <th style="width:5%;" align="center">times</th>
	  <th style="width:30%;" align="center">last_time</th>
    </tr>
	
<?php 
	include("../connect/connect.php");
	$connect->query("set names utf8");
	$result1 = $connect->query('select * FROM visitor where permistion = "user" order by latest_time desc');
	$order=1;
	while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
		echo '<tr><td>'.$order.'</td>';
		echo '<td>'.$row[1].'</td>';
		echo '<td>'.$row[2].$row[3].'&nbsp;'.$row[4].'</td>';
		echo '<td>'.$row[7].'</td>';
		echo '<td>'.$row[8].'</td>';
		echo '<td>'.$row[10].'</td>';
		echo '<td>'.$row[11].'</td></tr>';
		$order++;
	}
	
?> 
	   
  </table> 
  </div>   
</div> 
<!-- End page content -->
<br><br><br></div>
</body>
</html>
