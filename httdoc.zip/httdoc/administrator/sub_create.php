<?php 
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php if($_POST['action']=="sas") include("inc.topbar_admin.php"); 
	  else include("inc.topbar_adminx.php"); ?>

<!-- Header  -->
<div class="w3-container w3-light-grey w3-border w3-left-align">
	<br><h3 style="text-shadow:1px 1px 0 #444">ระบบตรวจสอบหลักสูตร วิทยาลัยการคอมพิวเตอร์ มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต [สำหรับเจ้าหน้าที่]</h3>
	<h5 style="text-shadow:1px 1px 0 #444">Curriculum checking system [Admin page]</h5><br>
<div>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:80%">
	<br><center><h3 style="text-shadow:1px 1px 0 #444">Subject Management</h3>

  <?php 

  if ($_POST['action']=="sas") {
	echo '<h4>[Add Subject | เพิ่มรายวิชา]</h4></center>';
	echo '<br><form action="process_subjects.php" target= "_blank" method="post">';
	echo '<center><table class="w3-table w3-hoverable w3-margin-top " border="0" style="width:75%;" id="myTable1">';
	echo '<tr><th style="width:25%;"><h5><strong>รหัสวิชา :</h5></strong></th>';
    echo '<th style="width:80%;"><input class="w3-input w3-border-1" type="text" name="subjects_code" style="width:100%" required></tr>';
	echo '<tr><th><h5><strong>ชื่อวิชาภาษาไทย :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1" type="text" name="subjects_name_TH" style="width:100%" required></tr>';
	echo '<tr><th><h5><strong>ชื่อวิชาภาษาอังกฤษ :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1 type="text" name="subjects_name_EN" style="width:100%" required></tr>';
	echo '<tr><th><h5><strong>หน่วยกิจ :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1" type="text" name="subjects_credit" style="width:100%" required></tr>';
    echo '</table></center>';

	echo '<br><center><table><tr><td><input type="hidden" name="action" value="sas">';
    echo '<input type="submit" class="w3-button w3-block w3-border" value="ยืนยัน"></form></td><td><input type="button" class="w3-button w3-border" value="กลับ" onclick="javascript:history.back()" /></td></tr></table>';

  }
	
  else if ($_SESSION['err']=="1"){
	echo '<br><div class="w3-panel w3-pale-red w3-card-4">';
    echo '<p>failure | กรุณาตวจสอบว่ากรอกข้อมูลถูกต้อง และครบถ้วน</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Back | กลับ" onclick="javascript:history.back()" />';
  }

  else if ($_SESSION['err']=="6"){
	echo '<br><div class="w3-panel w3-pale-red w3-card-4">';
    echo '<p>failure | กรุณาตวจสอบว่ากรอกข้อมูลถูกต้อง และครบถ้วน</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Back | กลับ" onclick="window.close();"  />';
  }

  else if ($_SESSION['err']=="0"){
	echo '<br><div class="w3-panel w3-metro-light-blue w3-card-4">';
    echo '<p>Success | เพิ่มข้อมูลสำเร็จ</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Back | กลับ" onclick="javascript:history.back()" />';
  }

  else if ($_SESSION['err']=="2"){
	echo '<br><div>';
	echo '<input type="button" class="w3-button w3-border" value="Close | กลับ" onclick="javascript:history.back()" />';
	echo '</div>';
  }

  else if ($_SESSION['err']=="3"){
	echo '<br><div class="w3-panel w3-metro-light-blue w3-card-4">';
    echo '<p>Success | ลบข้อมูลสำเร็จ</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Close | ปิดหน้าต่าง" onclick="window.close();" />';
  }

    else if ($_SESSION['err']=="4"){
	echo '<br><div class="w3-panel w3-metro-light-blue w3-card-4">';
    echo '<p>Success | เพิ่มข้อมูลสำเร็จ</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Back | กลับ" onclick="window.close();" />';
  }

  else if ($_SESSION['err']=="5"){
	echo '<br><div>';
	echo '<input type="button" class="w3-button w3-border" value="Close | กลับ" onclick="window.close();" />';
	echo '</div>';
  }

  $_SESSION['err']=2;
  ?> 

  </div>   
</div> 
<!-- End page content -->
<br><br><br></div>
</body>
</html>
