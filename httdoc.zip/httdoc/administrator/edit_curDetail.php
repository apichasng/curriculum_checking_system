<?php 
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.topbar_admin.php"); ?>

<!-- Header  -->
<div class="w3-container w3-light-grey w3-border w3-left-align">
	<br><h3 style="text-shadow:1px 1px 0 #444">ระบบตรวจสอบหลักสูตร วิทยาลัยการคอมพิวเตอร์ มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต [สำหรับเจ้าหน้าที่]</h3>
	<h5 style="text-shadow:1px 1px 0 #444">Curriculum checking system [Admin page]</h5><br>
<div>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:80%">
	<br><center><h3 style="text-shadow:1px 1px 0 #444">Curriculum Management</h3>
<?php
	include("../connect/connect.php");
	$connect->query("set names utf8");
	$result1 = $connect->query('select * FROM curriculum where cur_id='.$_GET['id']);
	while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
 		echo '<h4>[Create Curriculum | เพิ่มหลักสูตร]</h4></center>';
		echo '<br><form name="process_cat.php" action="process_cat.php" method="post">';
		echo '<center><table  class="w3-table w3-hoverable w3-margin-top" border="0" style="width:85%;" id="myTable1">';
		echo '<tr><th style="width:40%;"><h5><strong>ชื่อเรียกหลักสูตร :</h5></strong></th>';
		echo '<th style="width:80%;"><input class="w3-input w3-border-0" type="text" name="curName" value="'.$row[1].'" style="width:100%"></tr>';
		echo '<th colspan="2">&nbsp;</tr>';
		echo '<tr><th><h5><strong>ชื่อหลักสูตรภาษาไทย :</h5></strong></th>';
		echo '<th><input class="w3-input w3-border-1" type="text" name="curNameTH" value="'.$row[2].'" style="width:100%"></tr>';
		echo '<tr><th><h5><strong>ชื่อหลักสูตรภาษาอังกฤษ :</h5></strong></th>';
		echo '<th><input class="w3-input w3-border-1" type="text" name="curNameEN" value="'.$row[3].'" style="width:100%"></tr>';
		echo '<th colspan="2">&nbsp;</tr>';
		echo '<tr><th><h5><strong>ชื่อเต็มปริญญา ภาษาไทย :</h5></strong></th>';
		echo '<th><input class="w3-input w3-border-1" type="text" name="degreeTH" value="'.$row[4].'" style="width:100%"></tr>';
		echo '<tr><th><h5><strong>ชื่อย่อปริญญา ภาษาไทย :</h5></strong></th>';
		echo '<th><input class="w3-input w3-border-1" type="text" name="dgTH" value="'.$row[5].'" style="width:100%"></tr>';
		echo '<tr><th><h5><strong>ชื่อเต็มปริญญา ภาษาอังกฤษ :</h5></strong></th>';
		echo '<th><input class="w3-input w3-border-1" type="text" name="degreeEN" value="'.$row[6].'" style="width:100%"></tr>';
		echo '<tr><th><h5><strong>ชื่อย่อปริญญา ภาษาอังกฤษ :</h5></strong></th>';
		echo '<th><input class="w3-input w3-border-1" type="text" name="dgEN" value="'.$row[7].'" style="width:100%"></tr>';
		echo '<th colspan="2">&nbsp;</tr>';
		echo '<tr><th><h5><strong>วิชาเอก :</h5></strong></th>';
		echo '<th><input class="w3-input w3-border-1" type="text" name="major" value="'.$row[8].'" style="width:100%"></tr>';
		echo '<tr><th><h5><strong>จำนวนหน่วยกิตตลอดหลักสูตร :</h5></strong></th>';
		echo '<th><input class="w3-input w3-border-1" type="text" name="sumCredit" value="'.$row[9].'" style="width:100%"></tr>';
		echo '<tr><th><h5><strong>รูปแบบของหลักสูตร :</h5></strong></th>';
		echo '<th><input class="w3-input w3-border-1" type="text" name="fomatYear" value="'.$row[10].'" style="width:100%"></tr>';
		echo '<tr><th><h5><strong>ภาษาที่ใช้ :</h5></strong></th>';
		echo '<th><input class="w3-input w3-border-1" type="text" name="language" value="'.$row[11].'" style="width:100%"></tr>';
		echo '<tr><th><h5><strong>การรับเข้าศึกษา :</h5></strong></th>';
		echo '<th><input class="w3-input w3-border-1" type="text" name="StdRecieve" value="'.$row[12].'" style="width:100%"></tr>';
		echo '<tr><th><h5><strong>ความร่วมมือกับสถาบันอื่น :</h5></strong></th>';
		echo '<th><input class="w3-input w3-border-1" type="text" name="coopOT" value="'.$row[13].'" style="width:100%"></tr>';
		echo '<tr><th><h5><strong>การให้ใบปริญญาแก่ผู้สำเร็จการศึกษา :</h5></strong></th>';
		echo '<th><input class="w3-input w3-border-1" type="text" name="degreeGive" value="'.$row[14].'" style="width:100%"></tr>';
		echo '<tr><th><h5><strong>อาชีพที่สามารถประกอบได้หลังสําเร็จการศึกษา :</h5></strong></th>';
		echo '<th><input class="w3-input w3-border-1" type="text" name="careerSP" value="'.$row[15].'" style="width:100%"></tr>';
	}

	echo '</table></center> ';

	echo '<br><center><table border="0" style="width:85%;" id="myTable1">';
	echo '<tr><th colspan="2"><center><input type="hidden" name="action" value="updateAC"><input type="hidden" name="id" value="'.$_GET['id'].'"><input class="w3-button w3-round-large w3-green" type="submit" value="บันทึก"></form>&nbsp;<input type="button" class="w3-button w3-round-large w3-text-white w3-gray" value="กลับ" onclick="javascript:history.back()" /></center></th></tr>';
    echo '</table></center> ';
  

  $_SESSION['err']=0;
  ?> 

  </div>   
</div> 
<!-- End page content -->
<br><br><br></div>
</body>
</html>
