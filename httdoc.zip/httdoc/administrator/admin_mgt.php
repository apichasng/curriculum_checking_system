<?php 
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<script>
function del(id){
	if(confirm("Are you sure want to delete this ?")){
		document.location.href = 'process_admin.php?action=toUser&id='+id;
	}
}
</script>

<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.topbar_admin.php"); ?>

<!-- Header  -->
<br/><div class="w3-container w3-light-grey w3-border w3-left-align">
	<br><h3 style="text-shadow:1px 1px 0 #444">ระบบตรวจสอบหลักสูตร วิทยาลัยการคอมพิวเตอร์ มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต [สำหรับเจ้าหน้าที่]</h3>
	<h5 style="text-shadow:1px 1px 0 #444">Curriculum checking system [Admin page]</h5><br>
<div>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:85%">
	<?php
		if($_SESSION["err"]=="success"){
			echo '<div class="w3-panel w3-pale-green w3-card-4"><p><center> Success !!</center></p></div>';
			$_SESSION["err"]="fail";
		}
	?>

	<br><center><h3 style="text-shadow:1px 1px 0 #444">Admin list</h3></center>
	<input class="w3-button w3-teal" type = "submit" value="รายชื่อผู้เข้าใช้งาน" onClick="javascript:location.href='user_mgt.php'">&nbsp;<button onclick="document.getElementById('id01').style.display='block'" data-toggle="tooltip" title="ย้ายลงหลักสูตร" class="w3-button w3-teal">เพิ่มผู้ดูแล</button>
    <table class="w3-table w3-border w3-hoverable w3-responsive w3-margin-top" border="1" style="width:100%;" id="myTable1">
    <tr class="w3-light-grey">
      <th style="width:5%;" align="center">order</th>
	  <th style="width:10%;" align="center">username</th>
	  <th style="width:30%;" align="center">name</th>
	  <th style="width:25%;" align="center">email</th>
	  <th style="width:10%;" align="center">position</th>
	  <th style="width:5%;" align="center">times</th>
	  <th style="width:20%;" align="center">last_time</th>
	  <th style="width:10%;" align="center">remove</th>
    </tr>
	
<?php 
	include("../connect/connect.php");
	$connect->query("set names utf8");
	$result = $connect->query('select * FROM visitor where permistion = "admin" order by latest_time desc');

	if(!isset($_GET['page']))$_GET['page']=1;
	$page=$_GET['page'];
	$rows="20";
	$total_data = mysqli_num_rows($result);
	$total_page = ceil($total_data/$rows);
	$start=($page-1)*$rows;
	$Connum=(($page*20)-20)+1;
	$order=$Connum;

	$result1 = $connect->query('select * FROM visitor where permistion = "admin" order by latest_time desc Limit '.$start.',20');
	while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
		echo '<tr><td>'.$order.'</td>';
		echo '<td>'.$row[1].'</td>';
		echo '<td>'.$row[2].$row[3].'&nbsp;'.$row[4].'</td>';
		echo '<td>'.$row[7].'</td>';
		echo '<td>'.$row[8].'</td>';
		echo '<td>'.$row[10].'</td>';
		echo '<td>'.$row[11].'</td>';
		echo '<td><center><a href="javascript:del('.$row[1].')" class="w3-button w3-round-large tahoma11boldlink"><i class="fa fa-remove" style="color:red;" aria-hidden="true"></i></a></center></td></tr>';
		$order++;
	}
	echo '</table>';

	$Connum=-19;
	$Nextpage=$page+1;
	$Prepage=$page-1;
?>	
	<br><center><table style="width:40%;"><tr>
	<td style="width:5%;"><input type="submit" value="<<" class="w3-button w3-teal" onClick="javascript:location.href='admin_mgt.php?page=1'" <?php if($page<=1) echo 'disabled'; ?>></td>
	<td style="width:5%;"><input type="submit" value="<" class="w3-button w3-teal" onClick="javascript:location.href='admin_mgt.php?page=<?php echo $Prepage; ?>'" <?php if($page<=1) echo 'disabled'; ?>></td>

	<td style="width:10%;"><form method="GET" action="admin_mgt.php"><input class="w3-input w3-border w3-center" type="number" name="page" value="<?php echo $_GET['page']; ?>"></td><td style="width:10%;" align="center"><?php echo ' / '.$total_page; ?></td><td style="width:5%;"><input class="w3-button" type="submit" value="go page"></form></td>

	<td style="width:5%;"><input type="submit" value=">" class="w3-button w3-teal" onClick="javascript:location.href='admin_mgt.php?page=<?php echo $Nextpage; ?>'" <?php if($page>=$total_page) echo 'disabled'; ?>></td>
	<td style="width:5%;"><input type="submit" value=">>" class="w3-button w3-teal" onClick="javascript:location.href='admin_mgt.php?page=<?php echo $total_page; ?>'" <?php if($page>=$total_page) echo 'disabled'; ?>></td>
	</tr></table></center><br>

  </div> 
  </div>   

  <div id="id01" class="w3-modal"><center>
		<div class="w3-modal-content w3-animate-top">
			<header class="w3-container w3-teal">
				<span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-display-topright">&times;</span>
				 <h2>เพิ่มผู้ดูแลระบบ</h2>
			</header>

			<div class="w3-container w3-padding-24">
				<span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-display-topright">&times;</span>
				<form action="process_admin.php" method="POST"><table>
					<tr><th class="w3-left-align" style="width:10%;">เลือกรายชื่อ</th>
					<th>&nbsp;</th>
					<?php $result3 = $connect->query('select * FROM visitor where permistion = "user" order by id asc'); ?>
					<th colspan="2" style="width:90%;"><select class="w3-select" name="id">
					<option value="0" selected>เลือกรายชื่อ</option>
					<?php while($row = mysqli_fetch_array($result3,MYSQLI_NUM)){
						echo '<option value="'.$row[1].'">'.$row[1].' | '.$row[2].$row[3].'&nbsp;'.$row[4].'</option>';
					} ?>
					</select></th></tr>
				</table>

				<div class="w3-panel w3-padding-16"><input type="hidden" name="action" value="toAdmin"><input class="w3-button w3-border" type="submit" value="บันทึก"></form> <button onclick="document.getElementById('id01').style.display='none'" type="button" class="w3-button w3-border">ยกเลิก</button></div>
			</div>
		</div></center>
	</div>

</div> 
<!-- End page content -->
<br><br><br></div>
</body>
</html>
