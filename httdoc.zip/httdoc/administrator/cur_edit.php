<?php
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
include("../connect/connect.php");
$connect->query("set names utf8");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<script>
function del(id){
	if(confirm("Are you sure want to delete this ?")){
		document.location.href = 'delete.php?act=math_cur&id='+id;
	}
}
</script>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.topbar_admin.php"); ?>

<!-- Header  -->
<br/><div class="w3-container w3-light-grey w3-border w3-left-align">
	<br><h3 style="text-shadow:1px 1px 0 #444">ระบบตรวจสอบหลักสูตร วิทยาลัยการคอมพิวเตอร์ มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต [สำหรับเจ้าหน้าที่]</h3>
	<h5 style="text-shadow:1px 1px 0 #444">Curriculum checking system [Admin page]</h5><br>
<div>
<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->

<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:80%">
	<br><center><h3 style="text-shadow:1px 1px 0 #444">Curriculum Management</h3>
	<h4>[edit]</h4></center><br/>
	<?php
	if($_SESSION["delete"]=="success"){
		echo '<div class="w3-panel w3-pale-red w3-card-4"><p><center>Delete Success !!</center></p></div>';
		$_SESSION["delete"]="fail";
	}

	$result1 = $connect->query('select cur_name FROM curriculum where cur_id='.$_GET['id']);
	while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
		echo '<center><h4>'.$row[0].'</h4></center>';
	}
?>
   <br/><table class="w3-responsive" ><tr>
   <td><input type = "submit" value="เพิ่มวิชาลงหลักศูตร" name="เพิ่มวิชาลงหลักศูตร" class="w3-button w3-teal" onClick="javascript:location.href='cur_create.php?action=as&id= <?=$_GET['id'];?>'"></td>
   <td><input type = "submit" value="แก้ไขคำอธิบายหลักสูตร" name="แก้ไขคำอธิบายหลักสูตร" class="w3-button w3-teal" onClick="javascript:location.href='edit_curDetail.php?id= <?=$_GET['id'];?>'"></td>
   <td><input type = "submit" value="กำหนดค่าหน่วยกิตรวม" name="กำหนดค่าหน่วยกิตรวม" class="w3-button w3-teal" onClick="javascript:location.href='cur_credit.php?action=acr&id= <?=$_GET['id'];?>'"></td>
   <!-- <td><input type = "submit" value="preview" name="preview" class="w3-button w3-teal" onClick="javascript:location.href='cur_preview.php?action=vc&id= <?=$_GET['id'];?>'"></td> -->
	</table>

     <!-- เลือกหมวด  -->
  <div class="w3-container">
	<br>
	<div class="w3-bar w3-left-align ">
		<table class="w3-responsive"><tr><th>เลือกหมวดวิชา : </th>
		<td><button class="w3-bar-item w3-button tablink w3-light-grey" onclick="openCity(event,'A')">หมวด วิชาศึกษาทั่วไป </button></td>
		<td><button class="w3-bar-item w3-button tablink" onclick="openCity(event,'B')">หมวด วิชาเฉพาะ</button></td>
		<td><button class="w3-bar-item w3-button tablink" onclick="openCity(event,'C')">หมวด วิชาเลือกเสรี</button></td>
		</tr></table>
	</div>

  <!-- หมวด วิชาศึกษาทั่วไป  -->
  <div id="A" class="w3-container city">
  <table class="w3-table w3-border w3-hoverable w3-margin-top" border="1" style="width:100%;">
    <tr class="w3-light-grey">
      <th style="width:5%;" align="center">ลำดับ</th>
	  <th style="width:10%;" align="center">รหัสวิชา</th>
	  <th style="width:65%;" align="center">ชื่อวิชา</th>
	  <th style="width:10%;" align="center">ประเภท</th>
	  <th style="width:10%;" align="center">หน่วยกิต</th>
	  <th style="width:5%;" align="center">ลบ</th>
    </tr>
<?php
	 $resultCr = $connect->query('SELECT left(code,1), right(code,1), credit FROM  match_credit where cur_id='.$_GET['id']);
	  while($rowcr = mysqli_fetch_array($resultCr,MYSQLI_NUM)){

			for($i=1;$i<16;$i++){
				if($rowcr[0]=='g'){
					if($rowcr[1]==$i) {
						$Cg[$i]=$rowcr[2];
					}
				}
				if($rowcr[0]=='s'){
					if($rowcr[1]==$i){
						$Csg[$i]=$rowcr[2];
					}
				}
			 }
	  }

	$result2 = $connect->query('select subject_group.* FROM match_cur JOIN subject_group ON match_cur.group_id = subject_group.group_id where cur_id='.$_GET['id'].' and group_name !="" and category_id = 1 group by group_id order by group_id asc');
	$key=1;
	while($row2 = mysqli_fetch_array($result2,MYSQLI_NUM)){
		//กลุ่มวิชา
		echo '<tr>';
			echo '<td colspan="4"><strong>'.$row2[1].'</strong></td>';
			echo '<td>'.$Cg[$row2[0]].'</td>';
			echo '<td>&nbsp;</td>';
		echo '</tr>';

		//รายชื่อวิชา
				$sg="0";
				$result4 = $connect->query('select match_cur.*, subjects.* FROM match_cur JOIN subjects ON match_cur.subject_code = subjects.subjects_code where cur_id='.$_GET['id'].' and category_id = 1 and group_id = '.$row2[0].' order by  subgroup_id asc, subject_type asc, subject_code asc');
				while($row4 = mysqli_fetch_array($result4,MYSQLI_NUM)){
					if($row4[4]!="0"){

						//กลุ่มวิชาย่อย
						$result3 = $connect->query('select subject_subgroup.* FROM match_cur JOIN subject_subgroup ON match_cur.subgroup_id = subject_subgroup.subgroup_id where cur_id='.$_GET['id'].' and subgroup_name !="" and subject_subgroup.subgroup_id = '.$row4[4].' and group_id = '.$row2[0].' and category_id = 1 group by subgroup_id order by subgroup_name asc');
						if($sg!=$row4[4]){
							while($row3 = mysqli_fetch_array($result3,MYSQLI_NUM)){
								echo '<tr>';
									echo '<td colspan="4">&nbsp;&nbsp;-&nbsp;&nbsp;'.$row3[1].'</td>';
									echo '<td>'.$Csg[$row3[0]].'</td>';
									echo '<td>&nbsp;</td>';
								echo '</tr>';
							}
							$sg=$row4[4];
						}
					}
					echo '<tr>';
					  echo '<td align="center">'.$key.'</td>';
					  echo '<td>'.$row4[8].'</td>';
					  echo '<td>'.$row4[9].'&nbsp;|&nbsp;'.$row4[10].'</td>';
					  if($row4[3]==1)echo '<td align="center"><font color="#ff0000">บังคับ</font></td>';
					  else echo '<td align="center"><font color="#009900">เลือก</font></td>';
					  echo '<td align="center">'.$row4[11].'</td>';
					  echo '<td><center><a href="javascript:del('.$row4[0].')" class="w3-button w3-round-large tahoma11boldlink"><i class="fa fa-remove" style="color:red;" aria-hidden="true"></i></a></center></td>';
					echo '</tr>';
				$key++;
				}
	}
?>
  </table>
  </div>

 <!-- หมวด วิชาเฉพาะ  -->
 <div id="B" class="w3-container city" style="display:none">
   <table class="w3-table w3-border w3-hoverable w3-margin-top" border="1" style="width:100%;">
    <tr class="w3-light-grey">
      <th style="width:5%;" align="center">ลำดับ</th>
	  <th style="width:10%;" align="center">รหัสวิชา</th>
	  <th style="width:65%;" align="center">ชื่อวิชา</th>
	  <th style="width:10%;" align="center">ประเภท</th>
	  <th style="width:10%;" align="center">หน่วยกิต</th>
	  <th style="width:5%;" align="center">ลบ</th>
    </tr>
<?php
	$resultCr = $connect->query('SELECT left(code,1), right(code,1), credit FROM  match_credit where cur_id='.$_GET['id']);
	  while($rowcr = mysqli_fetch_array($resultCr,MYSQLI_NUM)){

			for($i=1;$i<16;$i++){
				if($rowcr[0]=='g'){
					if($rowcr[1]==$i) {
						$Cg[$i]=$rowcr[2];
					}
				}
				if($rowcr[0]=='s'){
					if($rowcr[1]==$i){
						$Csg[$i]=$rowcr[2];
					}
				}
			 }
	  }

	$result2 = $connect->query('select subject_group.* FROM match_cur JOIN subject_group ON match_cur.group_id = subject_group.group_id where cur_id='.$_GET['id'].' and group_name !="" and category_id = 2 group by group_id order by group_id asc');
	$key=1;
	while($row2 = mysqli_fetch_array($result2,MYSQLI_NUM)){
		//กลุ่มวิชา
		echo '<tr>';
			echo '<td colspan="4"><strong>'.$row2[1].'</strong></td>';
			echo '<td>'.$Cg[$row2[0]].'</td>';
			echo '<td>&nbsp;</td>';
		echo '</tr>';

		//รายชื่อวิชา
				$sg="0";
				$result4 = $connect->query('select match_cur.*, subjects.* FROM match_cur JOIN subjects ON match_cur.subject_code = subjects.subjects_code where cur_id='.$_GET['id'].' and category_id = 2 and group_id = '.$row2[0].' order by  subgroup_id asc,subject_type asc, subject_code asc');
				while($row4 = mysqli_fetch_array($result4,MYSQLI_NUM)){
					if($row4[4]!="0"){

						//กลุ่มวิชาย่อย
						$result3 = $connect->query('select subject_subgroup.* FROM match_cur JOIN subject_subgroup ON match_cur.subgroup_id = subject_subgroup.subgroup_id where cur_id='.$_GET['id'].' and subgroup_name !="" and subject_subgroup.subgroup_id = '.$row4[4].' and group_id = '.$row2[0].' and category_id = 2 group by subgroup_id order by subgroup_name asc');
						if($sg!=$row4[4]){
							while($row3 = mysqli_fetch_array($result3,MYSQLI_NUM)){
								echo '<tr>';
									echo '<td colspan="4">&nbsp;&nbsp;-&nbsp;&nbsp;'.$row3[1].'</td>';
									echo '<td>'.$Csg[$row3[0]].'</td>';
									echo '<td>&nbsp;</td>';
								echo '</tr>';
							}
							$sg=$row4[4];
						}
					}
					echo '<tr>';
					  echo '<td align="center">'.$key.'</td>';
					  echo '<td>'.$row4[8].'</td>';
					  echo '<td>'.$row4[9].'&nbsp;|&nbsp;'.$row4[10].'</td>';
					  if($row4[3]==1)echo '<td align="center"><font color="#ff0000">บังคับ</font></td>';
					  else echo '<td align="center"><font color="#009900">เลือก</font></td>';
					  echo '<td align="center">'.$row4[11].'</td>';
					  echo '<td><center><a href="javascript:del('.$row4[0].')" class="w3-button w3-round-large tahoma11boldlink"><i class="fa fa-remove" style="color:red;" aria-hidden="true"></i></a></center></td>';
					echo '</tr>';
				$key++;
				}
	}
?>
  </table>
  </div>

  <!-- หมวด วิชาเลือกเสรี  -->
 <div id="C" class="w3-container city" style="display:none">
<table class="w3-table w3-border w3-hoverable w3-margin-top" border="1" style="width:100%;">
    <tr class="w3-light-grey">
      <th style="width:5%;" align="center">ลำดับ</th>
	  <th style="width:10%;" align="center">รหัสวิชา</th>
	  <th style="width:65%;" align="center">ชื่อวิชา</th>
	  <th style="width:10%;" align="center">ประเภท</th>
	  <th style="width:10%;" align="center">หน่วยกิต</th>
    </tr>

	<?php
	$resultCr = $connect->query('SELECT credit FROM  match_credit where cur_id='.$_GET['id'].' and code = "c3"');
	  while($rowcr = mysqli_fetch_array($resultCr,MYSQLI_NUM)){
		 $C3 = $rowcr[0];
	  }
	?>

	<tr>
		<td colspan="4">นักศึกษาสามารถเลือกเรียนวิชาใด ๆ ที่เปิดสอนในมหาวิทยาลัยสงขลานครินทร์ หรือมหาวิทยาลัย อื่น ๆ ทั้งในและต่างประเทศ ซึ่งมีเนื้อหาไม่ซ้ําซ้อนกัน หรือใกล้เคียงกับเนื้อหาวิชา ในหมวดศึกษาทั่วไป วิชาเฉพาะ หรือรายวิชาที่เรียนมาแล้ว</td>
		<td><?php echo $C3; ?></td>
	</tr>

  </table>
  </div>

	<div><br><br><center><a href="javascript:history.back()" class="w3-button w3-block w3-border tahoma11boldlink">Back</a></center></div>

  </div>
</div>

<script>

function openCity(evt, cityName) {
  var i, x, tablinks;
  x = document.getElementsByClassName("city");
  for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < x.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" w3-light-grey", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " w3-light-grey";
}

$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
});

</script>

<!-- End page content -->
<br><br><br></div>
</body>
</html>
