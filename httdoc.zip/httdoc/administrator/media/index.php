<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<style>
.bgimg {
    background-position: center;
    background-size: cover;
    background-image: url("../../img/picHead1.jpg");
    min-height: 90%;
}
</style>
<?php include("../../inc.includeCss.php"); ?>
<body bgcolor="#cccccc">
<!-- topbar -->

<!-- Header  -->
<header class="bgimg w3-display-container" id="admin">
  <center><div class="w3-padding-large w3-display-middle w3-light-grey w3-border w3-left-align ">
	<div>
		<video width="800" controls>
		  <source src="import_subjects.mp4" type="video/mp4">
		  <source src="import_subjects..ogg" type="video/ogg">
		  Your browser does not support HTML5 video.
		</video>
    </div>
  </div></center>
</header>

<!-- Footer -->
</body>
</html>
