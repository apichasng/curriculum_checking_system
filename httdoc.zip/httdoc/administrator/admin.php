<?php 
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.topbar_adminx.php"); ?>

<!-- Header  -->
<br/><div class="w3-container w3-light-grey w3-border w3-left-align">
	<br><h3 style="text-shadow:1px 1px 0 #444">ระบบตรวจสอบหลักสูตร วิทยาลัยการคอมพิวเตอร์ มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต [สำหรับเจ้าหน้าที่]</h3>
	<h5 style="text-shadow:1px 1px 0 #444">Curriculum checking system [Admin page]</h5><br>
<div>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<!--
<div class="w3-container w3-teal">
  &nbsp;
</div>
-->
<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:95%">
    <br/><center>
	<div class="row w3-padding-24">
		<div class="w3-content">
			ยินดีต้อนรับ
		</div>
	</div>

	<div class="row w3-padding-16" >
		<div class="w3-content w3-quarter">
			<a href="sub_mgt.php" class="w3-button w3-block"><i class="fa fa-file-text fa-5x" style="color:#339966" aria-hidden="true"></i><br><br>&nbsp;&nbsp;Subject Management</a>
		</div>
		<div class="w3-content w3-quarter">
			<a href="cur_mgt.php" class="w3-button w3-block"><i class="fa fa-database fa-5x" style="color:#339966" aria-hidden="true"></i><br><br>&nbsp;&nbsp;Curriculum Management</a>
		</div>
		<div class="w3-content w3-quarter">
			<a href="cur_match.php" class="w3-button w3-block"><i class="fa fa-sitemap fa-5x" style="color:#339966" aria-hidden="true"></i><br><br>&nbsp;&nbsp;Curriculum Matching</a>
		</div>
		<div class="w3-content w3-quarter">
			<a href="user_mgt.php" class="w3-button w3-block"><i class="fa fa-user-plus fa-5x" style="color:#339966" aria-hidden="true"></i><br><br>&nbsp;&nbsp;User Management</a>
		</div>
	</div>
	
	<div class="row w3-padding-16">
		<div class="w3-content w3-quarter">
			<a href="doc/user_manual.pdf" target="_blank" class="w3-button w3-block"><i class="fa fa-exclamation-circle fa-5x" style="color:#339966" aria-hidden="true"></i><br><br>&nbsp;&nbsp;User Manual</a>
		</div>
		<div class="w3-content w3-quarter">
			<a href="logout.php" class="w3-button w3-block"><i class="fa fa-sign-out fa-5x" style="color:#339966" aria-hidden="true"></i><br><br>&nbsp;&nbsp;Logout</a>
		</div>
	</div>
	</center>
  </div>
</div>



<!-- End page content -->
<br><br><br></div>


</body>
</html>
