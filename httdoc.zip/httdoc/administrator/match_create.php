<?php 
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<?php include("../inc.includeCss.php"); ?>
<script type="text/javascript">
function closeWin() {
	window.close();
}

function del(id,key){
	if(confirm("Are you sure want to delete this ?")){
		document.location.href = 'delete.php?act=dstd&id='+id+'&key='+key;
	}
}
</script>
<body>
<!-- topbar -->
<?php if($_GET['action']=="astd") include("inc.topbar_admin.php"); 
	  else include("inc.topbar_adminx.php"); ?>

<!-- Header  -->
<div class="w3-container w3-light-grey w3-border w3-left-align">
	<br><h3 style="text-shadow:1px 1px 0 #444">ระบบตรวจสอบหลักสูตร วิทยาลัยการคอมพิวเตอร์ มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต [สำหรับเจ้าหน้าที่]</h3>
	<h5 style="text-shadow:1px 1px 0 #444">Curriculum checking system [Admin page]</h5><br>
<div>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:80%">
	<br><center><h3 style="text-shadow:1px 1px 0 #444">Curriculum Management</h3>
  <?php if ($_GET['action']=="astd") { ?>
   <h4>[Add Students Group | เพิ่มกลุ่มนักศึกษา]</h4></center>
   <br><form name="astd" action="process_match.php" method="post">
   <table class="w3-table w3-hoverable w3-margin-top" border="0" style="width:100%;" id="myTable1">	
	<tr><th style="width:25%;"><h5><strong>New Group name :</h5></strong></th>
    <th style="width:100%;"><input class="w3-input w3-border-1" type="text" name="stdGname" placeholder="EX. นศ.EB รหัส 61" style="width:100%" required></th></tr>
	<tr><th style="width:25%;"><h5><strong>New Student's id group :</h5></strong></th>
    <th style="width:100%;"><input class="w3-input w3-border-1" type="text" name="stdID" placeholder="EX. 6130111XXX" style="width:100%" required></th></tr>
	<tr><th style="width:15%;"><h5><strong>New Code :</h5></strong></th>
    <th style="width:100%;"><input class="w3-input w3-border-1 type="number" name="stdCODE" placeholder="EX. 6130111" style="width:100%" required></th>
	<th style="width:5%;"><center><input type="hidden" name="action" value="astd"><input class="w3-button w3-round-large w3-green" type="submit" value="บันทึก"></form></center></th></tr>
   </table> 
   <br><br><b>student's id groups list..</b>
   <table class="w3-table w3-border w3-hoverable w3-responsive w3-margin-top" border="1" style="width:100%;">
   <tr><td style="width:5%;">order</td><td style="width:50%;">groups name</td><td style="width:50%;">student's id groups</td><td style="width:10%;"><center>remove</center></td></tr>
   <?php
   include("../connect/connect.php");
	$connect->query("set names utf8");
	$result1 = $connect->query('select * FROM students order by students_group desc');
	$order=1;
		while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
			echo '<tr><td>'.$order.'</td>';
			echo '<td>'.$row[1].'</td>';
			echo '<td>'.$row[2].'</td>';
			echo '<td><center><a href="javascript:del('.$row[0].')" class="w3-button w3-round-large tahoma11boldlink"><i class="fa fa-remove" style="color:red;" aria-hidden="true"></i></a></center></td></tr>';
			$order++;
		}
		if($order==1) echo '<td colspan="3"><center>- ไม่มีข้อมูล -</center></td></tr>';
    echo '</table><br>';
  }

  else if ($_SESSION['err']=="1"){
	echo '<br><div class="w3-panel w3-pale-red w3-card-4">';
    echo '<p>failure | กรุณาตวจสอบว่ากรอกข้อมูลถูกต้อง และครบถ้วน</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Back | กลับ" onclick="javascript:history.back()" />';
  }

  else if ($_SESSION['err']=="6"){
	echo '<br><div class="w3-panel w3-pale-red w3-card-4">';
    echo '<p>failure | กรุณาตวจสอบว่ากรอกข้อมูลถูกต้อง และครบถ้วน</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Back | กลับ" onclick="window.close();"  />';
  }

  else if ($_SESSION['err']=="0"){
	echo '<br><div class="w3-panel w3-metro-light-blue w3-card-4">';
    echo '<p>Success | เพิ่มข้อมูลสำเร็จ</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Back | กลับ" onclick="javascript:history.back()" />';
  }

  else if ($_SESSION['err']=="2"){
	echo '<br><div>';
	echo '<input type="button" class="w3-button w3-border" value="Close | กลับ" onclick="javascript:history.back()" />';
	echo '</div>';
  }

  else if ($_SESSION['err']=="3"){
	echo '<br><div class="w3-panel w3-metro-light-blue w3-card-4">';
    echo '<p>Success | ลบข้อมูลสำเร็จ</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Close | ปิดหน้าต่าง" onclick="window.close();" />';
  }

    else if ($_SESSION['err']=="4"){
	echo '<br><div class="w3-panel w3-metro-light-blue w3-card-4">';
    echo '<p>Success | เพิ่มข้อมูลสำเร็จ</p>';
	echo '</div>';
	echo '<br/><input type="button" class="w3-button w3-border" value="Back | กลับ" onclick="window.close();" />';
  }

  else if ($_SESSION['err']=="5"){
	echo '<br><div>';
	echo '<input type="button" class="w3-button w3-border" value="Close | กลับ" onclick="window.close();" />';
	echo '</div>';
  }

  $_SESSION['err']=2;
  ?> 

  </div>   
</div> 
<!-- End page content -->
<br><br><br></div>
</body>
</html>
