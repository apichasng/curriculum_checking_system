<?php 
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
include("../connect/connect.php");
$connect->query("set names utf8");


if($_POST['action']=="updateCG") {
	$sql=('UPDATE subject_group SET group_name="'.$_POST['groupName'].'" WHERE group_id ="'.$_POST['id'].'"');
	$result = mysqli_query($connect,$sql);
	$_SESSION['err']=4;
	header("location:cur_create.php"); 
}

else if($_POST['action']=="updateCSG") {	
	$sql=('UPDATE subject_subgroup SET subgroup_name="'.$_POST['subgroupName'].'" WHERE subgroup_id ="'.$_POST['id'].'"');
	$result = mysqli_query($connect,$sql);
	$_SESSION['err']=4;
	header("location:cur_create.php"); 
}

else if($_POST['action']=="ac") {
	if(($_POST['curName']=="") or ($_POST['curNameTH']=="") or ($_POST['curNameEN']=="") or ($_POST['degreeTH']=="") or ($_POST['dgTH']=="") or ($_POST['degreeEN']=="") or ($_POST['dgEN']=="") or ($_POST['major']=="") or ($_POST['sumCredit']=="") or ($_POST['fomatYear']=="") or ($_POST['language']=="") or ($_POST['StdRecieve']=="") or ($_POST['coopOT']=="") or ($_POST['degreeGive']=="") or ($_POST['careerSP']=="")) {
		$_SESSION['err']=1;
	}
	else {	
		$sql=('INSERT INTO curriculum (cur_id, cur_name, cur_nameTH, cur_nameEN, degreeTH, dgTH, degreeEN, dgEN, major, sumCredit, fomatYear, language, StdRecieve, coopOT, degreeGive, careerSP) VALUES ("","'.$_POST['curName'].'","'.$_POST['curNameTH'].'","'.$_POST['curNameEN'].'","'.$_POST['degreeTH'].'","'.$_POST['dgTH'].'","'.$_POST['degreeEN'].'","'.$_POST['dgEN'].'","'.$_POST['major'].'","'.$_POST['sumCredit'].'","'.$_POST['fomatYear'].'","'.$_POST['language'].'","'.$_POST['StdRecieve'].'","'.$_POST['coopOT'].'","'.$_POST['degreeGive'].'","'.$_POST['careerSP'].'")');
		$result = mysqli_query($connect,$sql);
		$_SESSION['err']=0;
	}
	header("location:cur_create.php");
}

else if($_POST['action']=="updateAC") {
	if(($_POST['curName']=="") or ($_POST['curNameTH']=="") or ($_POST['curNameEN']=="") or ($_POST['degreeTH']=="") or ($_POST['dgTH']=="") or ($_POST['degreeEN']=="") or ($_POST['dgEN']=="") or ($_POST['major']=="") or ($_POST['sumCredit']=="") or ($_POST['fomatYear']=="") or ($_POST['language']=="") or ($_POST['StdRecieve']=="") or ($_POST['coopOT']=="") or ($_POST['degreeGive']=="") or ($_POST['careerSP']=="")) {
		$_SESSION['err']=1;
	}
	else {	
		$sql=('UPDATE curriculum SET cur_name="'.$_POST['curName'].'",cur_nameTH="'.$_POST['curNameTH'].'",cur_nameEN="'.$_POST['curNameEN'].'",degreeTH="'.$_POST['degreeTH'].'",dgTH="'.$_POST['dgTH'].'",degreeEN="'.$_POST['degreeEN'].'",dgEN="'.$_POST['dgEN'].'",major="'.$_POST['major'].'",sumCredit="'.$_POST['sumCredit'].'",fomatYear="'.$_POST['fomatYear'].'",language="'.$_POST['language'].'",StdRecieve="'.$_POST['StdRecieve'].'",coopOT="'.$_POST['coopOT'].'",degreeGive="'.$_POST['degreeGive'].'",careerSP="'.$_POST['careerSP'].'" WHERE cur_id ="'.$_POST['id'].'"');
		$result = mysqli_query($connect,$sql);
		$_SESSION['err']=0;
	}
	header("location:cur_create.php");
}


else if($_POST['action']=="as") {

	if(($_POST['id']=="") or ($_POST['subject_code']=="") or ($_POST['subject_type']=="") or ($_POST['subgroup_id']=="") or ($_POST['group_id']=="") or ($_POST['category_id']=="")) {
		$_SESSION['err']=7;

	}
	else {	
		$chk=0;
		$result = $connect->query('SELECT subject_code FROM match_cur where cur_id='.$_POST['id']);
		while($row = mysqli_fetch_array($result,MYSQLI_NUM)){
			echo $row[0].' = '.$_POST['subject_code'];
			if($row[0]==$_POST['subject_code']){
				$_SESSION['err']=7;
				$chk=1;
			}
	   }

	   if($chk==0){
		   $sql=('INSERT INTO match_cur (matchCur_id, cur_id, subject_code, subject_type, subgroup_id, group_id, category_id) VALUES ("","'.$_POST['id'].'","'.$_POST['subject_code'].'","'.$_POST['subject_type'].'","'.$_POST['subgroup_id'].'","'.$_POST['group_id'].'","'.$_POST['category_id'].'")');
		$result = mysqli_query($connect,$sql);
		$_SESSION['err']=4;
	   }
	
	}
	header("location:cur_create.php");
}

else if($_POST['action']=="acr") {
	
	for($i=1;$i<11;$i++){
		if($_POST['c'.$i]!="0") { 
			$sql=('INSERT INTO match_credit (credit_id, cur_id, code, credit) VALUES ("","'.$_POST['id'].'","c'.$i.'","'.$_POST['c'.$i].'")');
			$result = mysqli_query($connect,$sql);
		}
	}
	
	
	for($i=1;$i<11;$i++){
		if($_POST['g'.$i]!="0") {
			$sql=('INSERT INTO match_credit (credit_id, cur_id, code, credit) VALUES ("","'.$_POST['id'].'","g'.$i.'","'.$_POST['g'.$i].'")');
			$result = mysqli_query($connect,$sql);
		}
	}
	
	for($i=0;$i<16;$i++){
		if($_POST['sg'.$i]!="0") {
			$sql=('INSERT INTO match_credit (credit_id, cur_id, code, credit) VALUES ("","'.$_POST['id'].'","sg'.$i.'","'.$_POST['sg'.$i].'")');
			$result = mysqli_query($connect,$sql);
		}
	}
	
	$_SESSION['err']=0;
	header("location:cur_create.php");
}

else if($_POST['action']=="ucr") {

	$sql=('DELETE FROM match_credit WHERE cur_id = "'.$_POST['id'].'"');
	$result = mysqli_query($connect,$sql);
	
	for($i=1;$i<11;$i++){
		if($_POST['c'.$i]!="") { 
			$sql=('INSERT INTO match_credit (credit_id, cur_id, code, credit) VALUES ("","'.$_POST['id'].'","c'.$i.'","'.$_POST['c'.$i].'")');
			$result = mysqli_query($connect,$sql);
		}
	}
	
	for($i=1;$i<11;$i++){
		if($_POST['g'.$i]!="") {
			$sql=('INSERT INTO match_credit (credit_id, cur_id, code, credit) VALUES ("","'.$_POST['id'].'","g'.$i.'","'.$_POST['g'.$i].'")');
			$result = mysqli_query($connect,$sql);
		}
	}
	
	for($i=0;$i<16;$i++){
		if($_POST['sg'.$i]!=""){
			$sql=('INSERT INTO match_credit (credit_id, cur_id, code, credit) VALUES ("","'.$_POST['id'].'","sg'.$i.'","'.$_POST['sg'.$i].'")');
			$result = mysqli_query($connect,$sql);
		}
	}
	
	$_SESSION['err']=0;
	header("location:cur_create.php");
}

else if($_POST['action']=="dcr") {

	$sql=('DELETE FROM match_credit WHERE cur_id = "'.$_POST['id'].'"');
	$result = mysqli_query($connect,$sql);
	
	$_SESSION['err']=0;
	header('location:cur_create.php?');
}

?>
