<?php 
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<script>
function del(id){
	if(confirm("Are you sure want to delete this ?")){
		document.location.href = 'delete.php?act=math_student&id='+id;
	}
}
</script>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.topbar_admin.php"); ?>

<!-- Header  -->
<br/><div class="w3-container w3-light-grey w3-border w3-left-align">
	<br><h3 style="text-shadow:1px 1px 0 #444">ระบบตรวจสอบหลักสูตร วิทยาลัยการคอมพิวเตอร์ มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต [สำหรับเจ้าหน้าที่]</h3>
	<h5 style="text-shadow:1px 1px 0 #444">Curriculum checking system [Admin page]</h5><br>
<div>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:85%">
	<br><center><h3 style="text-shadow:1px 1px 0 #444">Curriculum Matching</h3></center>
	<?php
		if($_SESSION["delete"]=="success"){
			echo '<div class="w3-panel w3-pale-green w3-card-4"><p><center>Delete Success !!</center></p></div>';
			$_SESSION["delete"]="fail";
		}
	?>
	<br><table class="w3-responsive"><tr>
	<td><input type = "submit" value="เพิ่มกลุ่มนักศึกษา" name="เพิ่มกลุ่มนักศึกษา" class="w3-button w3-teal" onClick="javascript:location.href='match_create.php?action=astd'"></td></tr></table>

	<br><table><tr><td style="width:100%;"><form method="GET" action="cur_match.php"><input class="w3-input w3-border" type="text" name="search" value="<?php echo $_GET['search']; ?>"></td><td>&nbsp;</td><td style="width:5%;"><input class="w3-button w3-round-large w3-green" type="submit" value="ค้นหา"></form></td></tr></table>

    <table class="w3-table w3-border w3-hoverable w3-responsive w3-margin-top" border="1" style="width:100%;" id="myTable1">
    <tr class="w3-light-grey">
      <th style="width:5%;" align="center">order</th>
	  <th style="width:14%;" align="center">groups name</th>
	  <th style="width:16%;" align="center">id groups</th>
	  <th style="width:80%;" align="center">curriculum's name</th>
	  <th style="width:10%;" align="center"><center>action</center></th>
    </tr>
	
<?php 
	include("../connect/connect.php");
	$connect->query("set names utf8");
	$result = $connect->query('select * FROM students where students_gname like "%'.$_GET['search'].'%" or students_group like "%'.$_GET['search'].'%" or students_gcode like "%'.$_GET['search'].'%" order by students_group desc');
	
	if(!isset($_GET['page']))$_GET['page']=1;
	$page=$_GET['page'];
	$rows="20";
	$total_data = mysqli_num_rows($result);
	$total_page = ceil($total_data/$rows);
	$start=($page-1)*$rows;
	$Connum=(($page*20)-20)+1;
	$order=$Connum;

	$result1 = $connect->query('select * FROM students where students_gname like "%'.$_GET['search'].'%" or students_group like "%'.$_GET['search'].'%" or students_gcode like "%'.$_GET['search'].'%" order by students_group desc Limit '.$start.',20');
	while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
		echo '<form role="form" name="edt_'.$order.'" action="process_match.php" target= "_blank" method="post"><tr><td>'.$order.'</td>';
		echo '<td>'.$row[1].'</td>';
		echo '<td>'.$row[2].'</td>';
		$result2 = $connect->query('select * FROM match_students where students_gcode = "'.$row[3].'"');
		$std_id=$row[0];
		$std_code=$row[3];
		echo '<input type="hidden" name="students_gcode" value="'.$row[3].'">';

		$numrows = mysqli_num_rows($result2);
		if ($numrows==0) {
			$result3 = $connect->query('select cur_id,cur_name FROM curriculum order by cur_name asc');
			echo '<td class="w3-pale-red"><select class="w3-select w3-pale-red" name="select_curriculum">';
			echo '<option value="" selected dissabled>เลือกหลักสูตร</option>';
			while($row = mysqli_fetch_array($result3,MYSQLI_NUM)){
				echo '<option value="'.$row[0].'">'.$row[1].'</option>';
			}
			echo '</select></td>';
			echo '<td><center><input type="hidden" name="id" value="'.$row[0].'"><input type="hidden" name="action" value="msc"><input class="w3-button w3-round-large w3-green" type="submit" value="บันทึก"></form></center></td>';
		}
		else {
			while($row = mysqli_fetch_array($result2,MYSQLI_NUM)){
				$thisCur=$row[2];
			}
			$result3 = $connect->query('select cur_id,cur_name FROM curriculum order by cur_name asc');
			echo '<td><select class="w3-select" name="select_curriculum" disabled>';
			while($row = mysqli_fetch_array($result3,MYSQLI_NUM)){
				if ($row[0]==$thisCur) echo '<option value="'.$row[0].'" selected>'.$row[1].'</option>';
				else echo '<option value="'.$row[0].'">'.$row[1].'</option>';
			}
			echo '</select></td>';
			echo '<td><center><a href="javascript:del('.$std_code.')" class="w3-button w3-round-large w3-red tahoma11boldlink">&nbsp;ล้าง&nbsp; </a></center></td></tr>';
		}
		

		$order++;
	}

	echo '</table>';

	$Connum=-19;
	$Nextpage=$page+1;
	$Prepage=$page-1;
?> 
	   
	<br><center><table style="width:40%;"><tr>
	<td style="width:5%;"><input type="submit" value="<<" class="w3-button w3-teal" onClick="javascript:location.href='cur_match.php?page=1&search=<?php echo $_GET['search']; ?>'" <?php if($page<=1) echo 'disabled'; ?>></td>
	<td style="width:5%;"><input type="submit" value="<" class="w3-button w3-teal" onClick="javascript:location.href='cur_match.php?page=<?php echo $Prepage; ?>&search=<?php echo $_GET['search']; ?>'" <?php if($page<=1) echo 'disabled'; ?>></td>

	<td style="width:10%;"><form method="GET" action="cur_match.php"><input class="w3-input w3-border w3-center" type="number" name="page" value="<?php echo $_GET['page']; ?>"></td><td style="width:10%;" align="center"><?php echo ' / '.$total_page; ?></td><td style="width:5%;"><input type="hidden" value="search"><input class="w3-button" type="submit" value="go page"></form></td>

	<td style="width:5%;"><input type="submit" value=">" class="w3-button w3-teal" onClick="javascript:location.href='cur_match.php?page=<?php echo $Nextpage; ?>&search=<?php echo $_GET['search']; ?>'" <?php if($page>=$total_page) echo 'disabled'; ?>></td>
	<td style="width:5%;"><input type="submit" value=">>" class="w3-button w3-teal" onClick="javascript:location.href='cur_match.php?page=<?php echo $total_page; ?>&search=<?php echo $_GET['search']; ?>'" <?php if($page>=$total_page) echo 'disabled'; ?>></td>
	</tr></table></center>


  </div>   
</div> 
<!-- End page content -->
<br><br><br></div>
</body>
</html>
