<?php
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
include("../connect/connect.php");
$connect->query("set names utf8");

	if ($_GET["act"]=="subjects"){
		$sql=('DELETE FROM subjects WHERE subjects_id = '.$_GET["id"]);
		$result = mysqli_query($connect,$sql);
		$_SESSION["delete"]="success";
		header("location:sub_mgt.php");
	}

	else if ($_GET["act"]=="curriculum"){

		$sql=('DELETE FROM match_cur WHERE subject_code = '.$_GET["id"]);
		$result = mysqli_query($connect,$sql);
		$_SESSION["delete"]="success";
		header("location:cur_edit.php");
	}

	else if ($_GET["act"]=="math_student"){

		$sql=('DELETE FROM match_students WHERE students_gcode = '.$_GET["id"]);
		$result = mysqli_query($connect,$sql);

		$_SESSION["delete"]="success";
		header("location:cur_match.php");
	}

	else if ($_GET["act"]=="dstd"){

		$sql=('DELETE FROM students WHERE students_id = '.$_GET["id"]);
		$result = mysqli_query($connect,$sql);

		$_SESSION["delete"]="success";
		header("location:cur_match.php");
	}

	else if ($_GET["act"]=="math_cur"){

		$sql=('DELETE FROM match_cur WHERE matchCur_id = '.$_GET["id"]);
		$result = mysqli_query($connect,$sql);

		$_SESSION['err']="6";
		header("location:cur_create.php");
	}
?>