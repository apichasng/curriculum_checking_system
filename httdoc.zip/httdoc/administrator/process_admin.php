<?php 
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
include("../connect/connect.php");
$connect->query("set names utf8");

if($_POST['action']=="toAdmin") {

	$sql=('UPDATE visitor SET permistion="admin" WHERE id ="'.$_POST['id'].'"');
	$result = mysqli_query($connect,$sql);
	$_SESSION['err']="success";
	header("location:admin_mgt.php"); 
}

else if($_GET['action']=="toUser") {

	$sql=('UPDATE visitor SET permistion="User" WHERE id ="'.$_GET['id'].'"');
	$result = mysqli_query($connect,$sql);
	$_SESSION['err']="success";
	header("location:admin_mgt.php"); 
}



?>
