<?php 
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
include("../connect/connect.php");
$connect->query("set names utf8");

if($_POST['action']=="astd") {
	if(($_POST['stdID']=="") or ($_POST['stdCODE']=="") or ($_POST['stdGname']=="")) {
		$_SESSION['err']=1;
	}
	else {	
		$sql=('INSERT INTO students (students_id, students_gname, students_group, students_gcode) VALUES ("","'.$_POST['stdGname'].'","'.$_POST['stdID'].'","'.$_POST['stdCODE'].'")');
		$result = mysqli_query($connect,$sql);
		$_SESSION['err']=0;
	}
	header("location:match_create.php");
}

else if($_POST['action']=="msc") {
	if($_POST['select_curriculum']=="") $_SESSION['err']=6; 
	else {	
		$sql=('INSERT INTO match_students (matchStd_id, students_gcode, cur_id) VALUES ("","'.$_POST['students_gcode'].'","'.$_POST['select_curriculum'].'")');
		$result = mysqli_query($connect,$sql);
		$_SESSION['err']=4;
	}
	header("location:match_create.php");
}

else if($_POST['action']=="mSubCur") {
	if(($_POST['subjects_id']=="") or ($_POST['subject_type']=="")) $_SESSION['err']=1; 
	else {	
		echo '111';
		$_SESSION['err']=0;
	}
	header("location:match_create.php");
}

?>
