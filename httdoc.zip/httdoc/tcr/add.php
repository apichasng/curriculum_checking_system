<?php 
session_start();
if ($_SESSION["position"]!="Staff") header("location:../administrator");
include("../connect/connect.php");
$connect->query("set names utf8");

if($_GET['action']=="addDashboard") {

	$err=0;
	if($_GET['code']=="" || $_GET['code']=="0") $err=3;

	$result = $connect->query('select subjects_code from dashboard_subjects where staff_id = "'.$_SESSION["ID2"].'"');
	while($row = mysqli_fetch_array($result,MYSQLI_NUM)){ 
		if($row[0]==$_GET['code']) $err=2;
	}

	if($err==0){
		$sql=('INSERT INTO dashboard_subjects (dbs_id, staff_id, subjects_code) VALUES ("","'.$_SESSION["ID2"].'","'.$_GET['code'].'")');
		$result = mysqli_query($connect,$sql);
		$_SESSION['status']=1;
	}
	else if ($err==2) $_SESSION['status']=2;
	else if ($err==3) $_SESSION['status']=1;
	header("location:dashboard.php");
}

else if($_GET['action']=="delDashboard") {

echo $_GET['code'];
	
	$sql=('DELETE FROM dashboard_subjects WHERE subjects_code = "'.$_GET['code'].'" and staff_id = "'.$_SESSION["ID2"].'"');
	$result = mysqli_query($connect,$sql);
	$_SESSION['status']=1;

	header("location:dashboard.php");
}


?>
