<?php
session_start();
if ($_SESSION["position"]!="Staff") header("location:../index.php");
include("../connect/connect.php");
$connect->query("set names utf8");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<meta charset="UTF-8">
  <meta name="Generator" content="EditPlus®">
  <meta name="Author" content="">
  <meta name="Keywords" content="">
  <meta name="Description" content="">
<?php include("../inc.includeCss.php"); ?>
</script>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<body>
<!-- topbar -->
<?php include("inc.sidebar-tcr.php"); ?>

<!-- Header  -->
<?php include("../inc.header_main.php"); ?>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<?php include("inc.middle-menu-tcr.php"); ?>

<center><div class="w3-container" style="max-width:90%"><br><br>

<?php
	include("../connect/connect.php");
	$connect->query("set names utf8");
	if(!isset($_GET['curriculum'])) $_GET['curriculum'] = "%%" ;

?>
	<?php
		// status
		if($_SESSION['status']==1){
			echo '<div class="w3-panel w3-pale-green w3-card-4"><p><center> Success !!</center></p></div>';
		}
		else if($_SESSION['status']==2){
			echo '<div class="w3-panel w3-pale-red w3-card-4"><p><center> Fail !!  This Subject has alraedy added</center></p></div>';
		}
		$_SESSION["status"]=0;
	?>
	<div class="w3-row w3-card-4 w3-round-large">
		<div class="w3-container w3-quarter">
			<br>
			<div class="w3-center w3-padding-16">
				<div class="w3-center w3-border w3-light-grey w3-padding-36">
					<?php if($_SESSION["gender"]=='M') { ?>
					<br><img src="../img/user_profile_m.png" class="w3-hover-opacity" width="165" height="165" border="0" alt="Student">
					<?php } else { ?>
					<br><img src="../img/user_profile_w.png" class="w3-hover-opacity" width="165" height="165" border="0" alt="Student">
					<?php }  ?>

					<br><br><span class="w3-center" style="font-size: 25px; font-weight: bold;"><?php echo $_SESSION["title"].$_SESSION["name"].'&nbsp;&nbsp;'.$_SESSION["surname"]; ?></span>
					<br><small class="w3-center">@<?php echo $_SESSION["ID2"];  ?></small>
					<hr align="center" size="25" noshade="noshade">
					<br><br><br> <!-- <span class="w3-center"><button onclick="location.href='curriculum.php'" class="w3-button w3-border w3-white"><i class="fa fa-database" aria-hidden="true"></i>&nbsp;&nbsp;My Curriculum</button></span> --> <br><br>
				</div>
			</div>
		</div>
		<div class="w3-container w3-threequarter w3-round-large w3-right w3-padding-16 w3-responsive">
			<div class="w3-center">
				<div class="w3-container" >
					<h2 class="w3-center"><span class="w3-wide"><b>Dashboard</b></span></h2><br>
				</div>

					<!-- <table width="100%"><tr>
						<form method="GET" action="dashboard.php"><td>
						<?php $result1 = $connect->query('select cur_id,cur_name FROM curriculum '); ?>
							<label class="w3-left" ><strong>เลือกหลักสูตร</strong></label>
							<select class="w3-select w3-border-0" name="curriculum">
							<option value="%%" selected>ทั้งหมด</option>
							<?php while($row1 = mysqli_fetch_array($result1,MYSQLI_NUM)){
								if ($_GET['curriculum']==$row1[0]) echo '<option value="'.$row1[0].'" selected>'.$row1[1].'</option>';
								else echo '<option value="'.$row1[0].'">'.$row1[1].'</option>';
							} ?>
						</select></td>
						<td>&nbsp;</td>
						<td style="width:5%;">
							<label class="w3-left" ><strong>&nbsp;&nbsp;</strong></label>
							<input class="w3-button w3-round-large w3-green" type="submit" value="search">
						</form></td>

					</tr></table> -->

			<!-- รายวิชาที่นักศึกษามีสถานะวิชา "ไม่ผ่าน" -->
			<div class="w3-center w3-half w3-border-top w3-border-bottom">
				<div class="w3-center">
					<br>รายวิชาที่นักศึกษามีสถานะวิชา "ไม่ผ่าน"
				</div>
				<div class="w3-center">
				<?php
				for($i=1;$i<6;$i++){
					$sub_code[$i]="";
				    $sub_count[$i]=0;
				}
				$result3 = $connect->query('select count(match_subjects.match_sub_id) as count_sub,match_subjects.subjects_code,subjects.subjects_name_TH ,subjects.subjects_name_EN  FROM match_subjects join subjects on subjects.subjects_code = match_subjects.subjects_code  where subjects_status = "3" and cur_id like "'.$_GET['curriculum'].'" group by subjects_code order by count_sub desc,subjects_code asc limit 5');
				$i=1;
					while($row3 = mysqli_fetch_array($result3,MYSQLI_NUM)){
						$sub_code[$i] = $row3[1].' '.$row3[2].' | '.$row3[3];
						$sub_count[$i] = $row3[0];
						$i++;
					}
				?>
					<script type="text/javascript">
						google.charts.load('current', {packages: ['corechart', 'bar']});
						google.charts.setOnLoadCallback(drawBasic);

						function drawBasic() {
							  var data = google.visualization.arrayToDataTable([
								['', '',],
								['<?php print $sub_code[1] ?>', <?php print $sub_count[1] ?>],
								['<?php print $sub_code[2] ?>', <?php print $sub_count[2] ?>],
								['<?php print $sub_code[3] ?>', <?php print $sub_count[3] ?>],
								['<?php print $sub_code[4] ?>', <?php print $sub_count[4] ?>],
								['<?php print $sub_code[5] ?>', <?php print $sub_count[5] ?>]
							  ]);

							  var options = {
								chartArea: {width: '60%'},
								  width:400,
								  height:280,
							  };
							  var chart = new google.visualization.BarChart(document.getElementById('columnchart_values'));
							  chart.draw(data, options);
							}
					</script>
					<div class="w3-right" id="columnchart_values" style="width:100%"></div>
					<div class="w3-center"><span class="w3-center"><small><input type="button" class="w3-button w3-border w3-white w3-small" value="View More" onclick="javascript:location.href='dashboard_subjects.php'"/></small></span></div><br>
				</div>
			</div>

			<!-- สัดส่วนนศที่ ไม่ผ่าน -->
			<div class="w3-center w3-half w3-border-top w3-border-bottom">
				<div class="w3-center">
					<br>สัดส่วนนักศึกษาที่มีสถานะวิชา "ไม่ผ่าน"
				</div>
				<div class="w3-center">
				<?php
				for($i=1;$i<6;$i++){
					$sub_code[$i]="";
				    $sub_count[$i]=0;
				}
				$result4 = $connect->query('select count(DISTINCT  std_id) as count_std, left(std_id, 7) as std_g, students.students_gname FROM match_subjects join students on students.students_gcode = left(match_subjects.std_id, 7) where subjects_status = "3" and cur_id like "'.$_GET['curriculum'].'" group by std_g order by count_std desc,std_id asc limit 5');
				$numrows4 = mysqli_num_rows($result4);
				$i=1;
					while($row4 = mysqli_fetch_array($result4,MYSQLI_NUM)){
						$std_code[$i] = $row4[2];
						$std_count[$i] = $row4[0];
						$i++;
					}

				if($numrows4==1){
				?>
					<script type="text/javascript">
					  google.charts.load("current", {packages:["corechart"]});
					  google.charts.setOnLoadCallback(drawChart);

					  function drawChart() {
							var data = google.visualization.arrayToDataTable([
								['', ''],
								['<?php print $std_code[1] ?>',<?php print $std_count[1] ?>],
								]);

							var options = {
								pieHole: 0.25,
								width:450,
								height:280
							};
							var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
							chart.draw(data, options);
						}
					</script>
					<? }

					else if($numrows4==2){
					?>
					<script type="text/javascript">
					  google.charts.load("current", {packages:["corechart"]});
					  google.charts.setOnLoadCallback(drawChart);

					  function drawChart() {
							var data = google.visualization.arrayToDataTable([
								['', ''],
								['<?php print $std_code[1] ?>',<?php print $std_count[1] ?>],
								['<?php print $std_code[2] ?>',<?php print $std_count[2] ?>],
								]);

							var options = {
								pieHole: 0.25,
								width:450,
								height:280
							};
							var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
							chart.draw(data, options);
						}
					</script>
					<? }

					else if($numrows4==3){
					?>
					<script type="text/javascript">
					  google.charts.load("current", {packages:["corechart"]});
					  google.charts.setOnLoadCallback(drawChart);

					  function drawChart() {
							var data = google.visualization.arrayToDataTable([
								['', ''],
								['<?php print $std_code[1] ?>',<?php print $std_count[1] ?>],
								['<?php print $std_code[2] ?>',<?php print $std_count[2] ?>],
								['<?php print $std_code[3] ?>',<?php print $std_count[3] ?>],
								]);

							var options = {
								pieHole: 0.25,
								width:450,
								height:280
							};
							var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
							chart.draw(data, options);
						}
					</script>
					<? }

					else if($numrows4==4){
					?>
					<script type="text/javascript">
					  google.charts.load("current", {packages:["corechart"]});
					  google.charts.setOnLoadCallback(drawChart);

					  function drawChart() {
							var data = google.visualization.arrayToDataTable([
								['', ''],
								['<?php print $std_code[1] ?>',<?php print $std_count[1] ?>],
								['<?php print $std_code[2] ?>',<?php print $std_count[2] ?>],
								['<?php print $std_code[3] ?>',<?php print $std_count[3] ?>],
								['<?php print $std_code[4] ?>',<?php print $std_count[4] ?>],
								]);

							var options = {
								pieHole: 0.25,
								width:450,
								height:280
							};
							var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
							chart.draw(data, options);
						}
					</script>
					<? }

					else if($numrows4>=5){
					?>
					<script type="text/javascript">
					  google.charts.load("current", {packages:["corechart"]});
					  google.charts.setOnLoadCallback(drawChart);

					  function drawChart() {
							var data = google.visualization.arrayToDataTable([
								['', ''],
								['<?php print $std_code[1] ?>',<?php print $std_count[1] ?>],
								['<?php print $std_code[2] ?>',<?php print $std_count[2] ?>],
								['<?php print $std_code[3] ?>',<?php print $std_count[3] ?>],
								['<?php print $std_code[4] ?>',<?php print $std_count[4] ?>],
								['<?php print $std_code[5] ?>',<?php print $std_count[5] ?>],
								]);

							var options = {
								pieHole: 0.25,
								width:450,
								height:280
							};
							var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
							chart.draw(data, options);
						}
					</script>
					<? }

					else {
					?>
					<script type="text/javascript">
					  google.charts.load("current", {packages:["corechart"]});
					  google.charts.setOnLoadCallback(drawChart);

					  function drawChart() {
							var data = google.visualization.arrayToDataTable([
								['', ''],
								[' ไม่พบข้อมูล ',1],
								]);

							var options = {
								pieHole: 0.25,
								width:450,
								height:280
							};
							var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
							chart.draw(data, options);
						}
					</script>
					<? } ?>

					<div id="chart_div" style="width:100%"></div>
					<div class="w3-center"><span class="w3-center"><small><input type="button" class="w3-button w3-border w3-white w3-small" value="View More" onclick="javascript:location.href='dashboard_students.php'"/></small></span></div><br>
				</div>
			</div>
		</div>
	</div>

	<!--  ส่วนล่าง  -->
	<br><br><br>

	<!--  Modal  -->
	<div id="id01" class="w3-modal"><center>
		<div class="w3-modal-content w3-animate-top">
			<header class="w3-container w3-teal">
				<span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-display-topright">&times;</span>
				 <h2>เพิ่มหน้าวิชาลง Dashboard</h2>
			</header>

			<div class="w3-container w3-padding-24">
				<span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-display-topright">&times;</span>
				<form action="add.php" method="GET"><table>

					<tr><th class="w3-left-align" style="width:10%">เลือกวิชา</th>
					<?php $result3 = $connect->query('select * from subjects order by subjects_code asc '); ?>
					<th colspan="2"><select class="w3-select" name="code">
					<option value="0" selected>เลือกวิชา</option>
					<?php while($row = mysqli_fetch_array($result3,MYSQLI_NUM)){
						echo '<option value="'.$row[1].'">'.$row[1].' &nbsp; '.$row[2].' | '.$row[3].'</option>';
					} ?>
					</select></th></tr>

				</table>

				<div class="w3-panel w3-padding-16"><input type="hidden" name="action" value="addDashboard"><input class="w3-button w3-border" type="submit" value="Confirm"></form> <button onclick="document.getElementById('id01').style.display='none'" type="button" class="w3-button w3-border">Cancel</button></div>
			</div>
		</div></center>
	</div>


	<div class="w3-row w3-round-large">
	<?php
	$result8 = $connect->query('select dashboard_subjects.*, subjects.subjects_name_TH, subjects.subjects_name_EN from dashboard_subjects join subjects on subjects.subjects_code = dashboard_subjects.subjects_code where staff_id = "'.$_SESSION["ID2"].'" order by dashboard_subjects.subjects_code asc');
	$numrows8 = mysqli_num_rows($result8);
	if($numrows8==0){
	?>
		<div>
			<br><button onclick="document.getElementById('id01').style.display='block'" data-toggle="tooltip" title="เพิ่มแผงควบคุม" class="w3-button w3-border"><i class="fa fa-plus"></i> <br> add dashboard</button><br>&nbsp;
		</div>

	<?php }
	else {

		echo '<div><br>';
			$item=1;

			while($row8 = mysqli_fetch_array($result8,MYSQLI_NUM)){
				if($item==1 || $item%5 == 0) {
					echo '<div class="w3-row-padding w3-margin-bottom">';
					$item=1;
				}
					echo '<div class="w3-quarter">';
					$result9 = $connect->query('select count(match_sub_id) as count_sub,subjects_code FROM match_subjects where subjects_status = "3" and subjects_code = "'.$row8[2].'"');
					$numrows9 = mysqli_num_rows($result9);
					while($row9 = mysqli_fetch_array($result9,MYSQLI_NUM)){
					  echo '<div class="w3-container w3-metro-dark-blue w3-hover-light-gray w3-text-white w3-padding-16 w3-card-4">';
						echo '<div class="w3-left"><i class="fa fa-users w3-xxxlarge"></i></div>';
						echo '<div class="w3-right">';
							if ($numrows9==0) echo '<h3>0</h3>';
							else echo '<h3>'.$row9[0].'</h3>';
						echo '</div>';
						echo '<div class="w3-clear"></div>';
						echo '<h4>'.$row8[2].'</h4>';
						echo '<small>'.$row8[3].'<br>'.$row8[4].'</small>';
					  ?>
						<br><small><a href="javascript:location.href='dashboard_subject_view.php?code=<?=$row8[2];?>'" class="w3-button" data-toggle="tooltip" title="ดู"><i class="fa fa-eye"></i></a> | <a href="javascript:location.href='add.php?action=delDashboard&code=<?=$row8[2];?>'" class="w3-button" data-toggle="tooltip" title="ลบ"><i class="fa fa-trash"></i></a> </small>
					  <?php
					  echo '</div>';
					}
					echo '</div>';
				if($item%4 == 0) echo '</div>';
				$item++;
			}
	?>

				<?php if($numrows8%4 != 0) { ?>
				<div class="w3-quarter">
					<br>&nbsp;<br>&nbsp;<br><button onclick="document.getElementById('id01').style.display='block'" data-toggle="tooltip" title="เพิ่มแผงควบคุม" class="w3-button w3-border"><i class="fa fa-plus"></i> <br> add dashboard</button><br>&nbsp;
				</div>
				<?php }
				else { ?>
				<div class="w3-row ">
					<br><button onclick="document.getElementById('id01').style.display='block'" data-toggle="tooltip" title="เพิ่มแผงควบคุม" class="w3-button w3-border"><i class="fa fa-plus"></i> <br>add dashboard</button><br>&nbsp;
				</div>
				<?php } ?>


		</div>
	<?php
	}
	?>

	</div>

</div></center>


<!-- End page content -->
<br><br><br></div>
<!-- Footer -->
<?php include("../inc.footer.php"); ?>

</body>
</html>
