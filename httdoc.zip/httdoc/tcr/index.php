<?php 
session_start();
if ($_SESSION["position"]!="Staff") header("location:../index.php");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.sidebar-tcr.php"); ?>

<!-- Header  -->
<?php include("../inc.header_mainx.php"); ?>


<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">
<?php include("inc.middle-menu-tcr.php"); ?>

<!-- content -->

	<br/>
	<div class="w3-container" id="program">
		<div class="w3-content" style="max-width:90%">
			<div class="w3-row-padding w3-content" style="max-width:1400px">
				<!-- left content -->
				<div class="w3-twothird">
					<?php include("inc.main_content_slide.php"); ?> 
					<?php include("../inc.main_content_program.php"); ?>
				</div> 
				
				<!-- right content -->
				<div class="w3-third">
					<!-- STD & TCR picture --> 
					<?php include("inc.direct_user.php"); ?>
					<!-- right bae --> 
					<?php include("../inc.main_content_right.php"); ?>
				</div>
			</div>
		</div>
	</div>
<!-- End page content -->
<br><br><br></div>

<!-- Footer -->
<?php include("../inc.footer.php"); ?>
</body>
</html>
