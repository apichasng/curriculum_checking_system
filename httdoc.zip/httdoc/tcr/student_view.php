<?php
session_start();
if ($_SESSION["position"]!="Staff") header("location:../index.php");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.sidebar-tcr.php"); ?>

<!-- Header  -->
<?php include("../inc.header_main.php"); ?>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<?php include("inc.middle-menu-tcr.php"); ?>

<center><div class="w3-container" style="max-width:75%"><br><br>

<?php
	include("../connect/connect.php");
	$connect->query("set names utf8");

	$students_gcode = substr($_GET['id'],0,7);
	$result = $connect->query('select* from match_students where students_gcode='.$students_gcode);
	$numrows = mysqli_num_rows($result);
	while($row = mysqli_fetch_array($result,MYSQLI_NUM)){
		$cur_id=$row[2];
	}

	$result0 = $connect->query('select * FROM visitor where id='.$_GET['id']);
	$numrows0 = mysqli_num_rows($result0);
	while($row0 = mysqli_fetch_array($result0,MYSQLI_NUM)){
		$std_name='"'.$row0[2].$row0[3].'&nbsp;'.$row0[4].'"';
		$std_gender=$row0[5];
		$std_email=$row0[7];
	}

	//อัพเดทล่าสุด
	$result2 = $connect->query('select update_date FROM match_subjects where std_id='.$_GET['id'].' order by update_date desc LIMIT 1');
	while($row = mysqli_fetch_array($result2,MYSQLI_NUM)){
		$lastupdate = $row[0];
	}

	//ข้อมูลหลักสูตร
	$result1 = $connect->query('select cur_name, sumCredit FROM curriculum where cur_id='.$cur_id);
	while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
		$curriculum = $row[0];
		$sumCredit  = $row[1];
	}

	//ข้อมูลสาขา
	$major=substr($_GET['id'],5,3);
	if($major=="110") $major="Information Technology";
	else if($major=="120") $major="Electronic Business";
	else if($major=="130") $major="Software Engineering";
	else $major="not found";

?>
	<div class="w3-row w3-card-4 w3-round-large">
		<div class="w3-container w3-third">
			<div class="w3-cente w3-padding-16">
				<div class="w3-center w3-border w3-light-grey w3-padding-48">
					<?php if($std_gender='M') { ?>
					<br><img src="../img/user_profile_m.png" class="w3-hover-opacity" width="165" height="165" border="0" alt="Student">
					<?php } else { ?>
					<br><img src="../img/user_profile_w.png" class="w3-hover-opacity" width="165" height="165" border="0" alt="Student">
					<?php }  ?>

					<br><span class="w3-center" style="font-size: 25px; font-weight: bold;"><?php echo $std_name; ?></span>
					<br><small class="w3-center">@<?php echo $_GET['id'];  ?></small>
					<hr align="center" size="25" noshade="noshade"><span class="w3-left"><b>&nbsp;&nbsp;&nbsp;Major: </b> <?php echo $major;  ?></span>
					<br><span class="w3-left"><b>&nbsp;&nbsp;&nbsp;Faculty: </b> College of Computing</span>
					<br><span class="w3-left"><b>&nbsp;&nbsp;&nbsp;EMAIl: </b> <?php echo $std_email;  ?></span>
					<br><span class="w3-left"><b>&nbsp;&nbsp;&nbsp;Updated: </b> <?php echo $lastupdate;  ?></span>
					<br><br><br><span class="w3-center"><input type="button" class="w3-button w3-border w3-white" value="View Curriculum" onclick="javascript:location.href='curriculum.php?&id=<?=$_GET['id'];?>'"/></span>


					<br><br>
				</div>
			</div>
		</div>
		<div class="w3-container w3-twothird w3-round-large w3-right">
<?php
		if($numrows0>0){
?>
			<div class="w3-center">
				<hr><span class="w3-center"><b><?php echo $curriculum; ?></b></span>
				<br><hr>
				<span class="w3-center">หน่วยกิตรวมตลอดหลักสูตร: <?php echo $sumCredit; ?> หน่วยกิต</span><br><br>
<?php
				//ข้อมูลจำนวนหน่วยกิตที่เรียน
				$resultCredit = $connect->query('SELECT match_subjects.*, match_cur.subgroup_id, match_cur.group_id, match_cur.category_id, left(subjects.subjects_credit,1) from match_subjects JOIN subjects ON subjects.subjects_code = match_subjects.subjects_code JOIN match_cur ON match_cur.subject_code = match_subjects.subjects_code where match_subjects.std_id ='.$_GET['id'].' and match_subjects.subjects_status = 1 group by match_subjects.match_sub_id union all SELECT match_subjects.*, match_other_sub.subgroup_id, match_other_sub.group_id, match_other_sub.category_id, left(subjects.subjects_credit,1) from match_subjects JOIN subjects ON subjects.subjects_code = match_subjects.subjects_code JOIN match_other_sub ON match_other_sub.subjects_code = match_subjects.subjects_code where match_subjects.std_id ='.$_GET['id'].' and match_subjects.subjects_status = 1 group by match_subjects.match_sub_id');
				while($rowCredit = mysqli_fetch_array($resultCredit,MYSQLI_NUM)){
					$CreditC[$rowCredit[8]] = $CreditC[$rowCredit[8]]+$rowCredit[9];
					$CreditG[$rowCredit[7]] = $CreditG[$rowCredit[7]]+$rowCredit[9];
					$CreditS[$rowCredit[6]] = $CreditS[$rowCredit[6]]+$rowCredit[9];
				}

				//ข้อมูลจำนวนหน่วยกิตรวม
				$resultCredit = $connect->query('SELECT subject_category.category_name, match_credit.credit, left(match_credit.code,1), right(match_credit.code,1) FROM  subject_category JOIN match_credit ON match_credit.code = subject_category.category_code where cur_id='.$cur_id.' UNION ALL SELECT subject_group.group_name, match_credit.credit, left(match_credit.code,1), right(match_credit.code,1) FROM  subject_group JOIN match_credit ON match_credit.code = subject_group.group_code where cur_id='.$cur_id.' UNION ALL SELECT subject_subgroup.subgroup_name, match_credit.credit, left(match_credit.code,1), right(match_credit.code,1) FROM  subject_subgroup JOIN match_credit ON match_credit.code = subject_subgroup.subgroup_code where cur_id='.$cur_id );
				echo'<center><table class="w3-responsive">';
				$chk="c";
				while($rowCredit = mysqli_fetch_array($resultCredit,MYSQLI_NUM)){
					if($rowCredit[2]=="c"){
						echo '<tr><td><span class="w3-left"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-dot-circle-o" style="font-size:10px;color:#605e4f"></i>&nbsp;'.$rowCredit[0].': </span></td>';
						if($CreditC[$rowCredit[3]]!="") {
							echo '<td>&nbsp; '.$CreditC[$rowCredit[3]].' / '.$rowCredit[1].' &nbsp;&nbsp;หน่วยกิต</td></tr>';
						}
						else echo '<td>&nbsp; 0 / '.$rowCredit[1].' &nbsp;&nbsp;หน่วยกิต</td></tr>';
					}

					if($chk!=$rowCredit[2]) echo '<tr><td colspan="2">&nbsp;</td></tr>';
					$chk=$rowCredit[2];

					if($rowCredit[2]=="g"){
						echo '<tr><td><span class="w3-left"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-dot-circle-o" style="font-size:10px;color:#605e4f"></i>&nbsp;'.$rowCredit[0].': </span></td>';
						if($CreditG[$rowCredit[3]]!=""){
							echo '<td>&nbsp; '.$CreditG[$rowCredit[3]].' / '.$rowCredit[1].' &nbsp;&nbsp;หน่วยกิต</td></tr>';
						}
						else echo '<td>&nbsp; 0 / '.$rowCredit[1].' &nbsp;&nbsp;หน่วยกิต</td></tr>';

					}

					if($chk!=$rowCredit[2]) echo '<tr><td colspan="2">&nbsp;</td></tr>';
					$chk=$rowCredit[2];

					if($rowCredit[2]=="s"){
						echo '<tr><td><span class="w3-left"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-dot-circle-o" style="font-size:10px;color:#605e4f"></i>&nbsp;'.$rowCredit[0].': </span></td>';
						if($CreditS[$rowCredit[3]]!=""){
							echo '<td>&nbsp; '.$CreditS[$rowCredit[3]].' / '.$rowCredit[1].' &nbsp;&nbsp;หน่วยกิต</td></tr>';
						}
						else echo '<td>&nbsp; 0 / '.$rowCredit[1].' &nbsp;&nbsp;หน่วยกิต</td></tr>';
					}
				}

			echo '<tr><td>&nbsp;</td></tr></table></center></div>';

		}
		else {
?>
			<div class="w3-center">
				<br><span><b> - ไม่พบข้อมูลหลักสูตร  - </b></span>
			</div>
<?php
		}
?>
		</div>
	</div>
</div></center>


<!-- End page content -->
<br><br><br></div>
<!-- Footer -->
<?php include("../inc.footer.php"); ?>


</body>
</html>
