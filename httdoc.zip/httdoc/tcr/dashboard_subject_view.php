<?php 
session_start();
if ($_SESSION["position"]!="Staff") header("location:../index.php");
include("../connect/connect.php");
	$connect->query("set names utf8");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.sidebar-tcr.php"); ?>

<!-- Header  -->
<?php include("../inc.header_main.php"); ?>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<?php include("inc.middle-menu-tcr.php"); ?>

<center><div class="w3-container" style="max-width:85%">
<?php
	$result = $connect->query('select subjects_name_TH, subjects_name_EN from subjects where subjects_code like "%'.$_GET['code'].'%"');
	while($row = mysqli_fetch_array($result,MYSQLI_NUM)){ 
		$subject = $row[0].'&nbsp; | &nbsp;'.$row[1];
	}
?>
	<div class="w3-container w3-padding-16" >
		<br/><h3 class="w3-center"><span class="w3-wide"><b>รายชื่อนักศึกษาที่มีสถานะ  "ไม่ผ่าน" ในรายวิชา</b></span></h3>
		<h3 class="w3-center"><span class="w3-wide"><?php echo $_GET['code'].'&nbsp;'.$subject; ?></span></h3>
	</div>

	<div class="w3-container w3-left-align" id="about">
  <div class="w3-content" style="max-width:90%">
	<div class="w3-center"><span class="w3-center"><small><input type="button" class="w3-button w3-border w3-white w3-block" value="ดูรายชื่อนักศึกษาทั้งหมด" onclick="javascript:location.href='dashboard_subject_view_all.php?code=<?=$_GET['code'];?>'"/></small></span></div>
	<table class="w3-table w3-border w3-hoverable w3-responsive w3-margin-top" border="1" style="width:100%;" id="myTable1">
    <tr class="w3-light-grey">
      <th style="width:5%;" align="center">#</th>
	  <th style="width:95%;" align="center">student groups</th>
	  <th style="width:10%;" align="center">amount</th>
	  <th style="width:5;" align="center">view</th>
    </tr>
	
<?php 

	$result = $connect->query('select count(DISTINCT match_subjects.std_id) as count_std, left(match_subjects.std_id, 7) as std_g, students.students_gname FROM match_subjects join students on students.students_gcode = left(match_subjects.std_id, 7) where match_subjects.subjects_code like "%'.$_GET['code'].'%" and subjects_status = "3" group by std_g order by count_std desc,std_id asc');
	$numrows = mysqli_num_rows($result); 
	
	if($numrows>0){
		
		if(!isset($_GET['page']))$_GET['page']=1;
		$page=$_GET['page'];
		$rows="20";
		$total_data = mysqli_num_rows($result);
		$total_page = ceil($total_data/$rows);
		$start=($page-1)*$rows;
		$Connum=(($page*20)-20)+1;
		$order=$Connum;

		$result1 = $connect->query('select count(DISTINCT match_subjects.std_id) as count_std, left(match_subjects.std_id, 7) as std_g, students.students_gname FROM match_subjects join students on students.students_gcode = left(match_subjects.std_id, 7) where match_subjects.subjects_code like "%'.$_GET['code'].'%" and subjects_status = "3" group by std_g order by count_std desc,std_id asc Limit '.$start.',20');
		
		while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){ 

			echo '<tr><td>'.$order.'</td>';
			echo '<td>'.$row[2].'</td>';
			echo '<td class="w3-center">'.$row[0].'</td>';
?>
			<td><center><a href="javascript:location.href='dashboard_subject_view_students.php?id=<?=$row[1];?>&code=<?=$_GET['code'];?>'" class="w3-button" data-toggle="tooltip" title="ดู"><font color="green"><i class="fa fa-eye"></i></font></a></center></td></tr>
<?php
			$order++;
		}

	}
	else echo '<tr><td colspan="6" class="w3-center"> - ไม่พบข้อมูล - </td></tr>';

	echo '</table>';

	$Connum=-19;
	$Nextpage=$page+1;
	$Prepage=$page-1;
?>	
	<br><center><table style="width:45%;"><tr>
	<td style="width:5%;"><input type="submit" value="<<" class="w3-button w3-teal" onClick="javascript:location.href='dashboard_subject_view.php?page=1&code=<?php echo $_GET['code']; ?>'" <?php if($page<=1) echo 'disabled'; ?>></td>
	<td style="width:5%;"><input type="submit" value="<" class="w3-button w3-teal" onClick="javascript:location.href='dashboard_subject_view.php?page=<?php echo $Prepage; ?>&code=<?php echo $_GET['code']; ?>'" <?php if($page<=1) echo 'disabled'; ?>></td>

	<td style="width:10%;"><form method="GET" action="dashboard_subject_view.php"><input class="w3-input w3-border w3-center" type="number" name="page" value="<?php echo $_GET['page']; ?>"></td><td style="width:10%;" align="center"><?php echo ' / '.$total_page; ?></td><td style="width:5%;"><input type="hidden" name="code" value="<?php echo $_GET['code']; ?>"><input class="w3-button" type="submit" value="go page"></form></td>

	<td style="width:5%;"><input type="submit" value=">" class="w3-button w3-teal" onClick="javascript:location.href='dashboard_subject_view.php?page=<?php echo $Nextpage; ?>&code=<?php echo $_GET['code']; ?>'" <?php if($page>=$total_page) echo 'disabled'; ?>></td>
	<td style="width:5%;"><input type="submit" value=">>" class="w3-button w3-teal" onClick="javascript:location.href='dashboard_subject_view.php?page=<?php echo $total_page; ?>&code=<?php echo $_GET['code']; ?>'" <?php if($page>=$total_page) echo 'disabled'; ?>></td>
	</tr></table>
	
	</div>
  </div>   
</div>
</div></center>


<!-- End page content -->
<br><br><br></div>
<!-- Footer -->
<?php include("../inc.footer.php"); ?>

</body>
</html>
