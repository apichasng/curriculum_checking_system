<script>
// Script to open and close sidebar
function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
}

function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
}

// Modal Image Gallery
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("modal01").style.display = "block";
  var captionText = document.getElementById("caption");
  captionText.innerHTML = element.alt;
}
</script>
<!-- Sidebar -->
<body>
<!-- Page Content -->
<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-bar-block w3-white w3-animate-left w3-top" style="z-index:3;width:230px;font-weight:bold;display:none;left:0;" id="mySidebar">
  <a href="javascript:void()" onclick="w3_close()" class="w3-bar-item w3-button w3-center w3-padding-32">- ปิด -</a> 
  <a href="../tcr" onclick="w3_close()" class="w3-bar-item w3-button w3-padding-16"><i class="fa fa-home" aria-hidden="true"></i>&nbsp;&nbsp;หน้าหลัก</a> 
  <a href="dashboard.php" onclick="w3_close()" class="w3-bar-item w3-button w3-padding-16"><i class="fa fa-pie-chart" aria-hidden="true"></i>&nbsp;&nbsp;หน้าควบคุม</a> 
  <a href="students_group.php" onclick="w3_close()" class="w3-bar-item w3-button w3-padding-16"><i class="fa fa-id-card-o" aria-hidden="true"></i>&nbsp;&nbsp;ดูข้อมูลนักศึกษา</a>
  <br/><a href="../login/logout.php" onclick="w3_close()" class="w3-bar-item w3-button w3-red w3-center w3-padding-16"><i class="fa fa-sign-out" aria-hidden="true"></i>&nbsp;&nbsp;ออกจากระบบ</a>
</nav>

<!-- Top menu on small screens -->
<header class="w3-top w3-light-grey w3-opacity-min">
  <a href="javascript:void(0)" class="w3-left w3-button w3-light-grey w3-opacity-min" onclick="w3_open()">&nbsp;&nbsp;<i class="fa fa-bars" aria-hidden="true"></i></a></a>
  <span class="w3-right"><form role="form" name="login_form" action="../login/logout.php" method="post">
		<table ><tr height="50%">
		<td valign="middle"><i class="w3-large fa fa-user"></i></td>
		<td><a href="dashboard.php" class="w3-button w3-light-grey w3-opacity-min w3-round-large"><?php echo $_SESSION["title"].$_SESSION["name"]."&nbsp;".$_SESSION["surname"]; ?></a></td>
		<td valign="middle"><input class="w3-button w3-round-large" type="submit" value="Logout"></td>
		</tr></table>
		</form></span>
  
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<body>
