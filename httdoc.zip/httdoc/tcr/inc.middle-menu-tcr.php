<div class="w3-container w3-metro-dark-blue">
<center><table align="center"  data-role="table"  id="movie-table" data-mode="reflow" class="w3-responsive">
			<thead>
				<tr><th></th></tr>
			</thead>
			<tbody>
				<tr>
					<td><a href="../tcr" class="w3-button"><i class="fa fa-home" aria-hidden="true"></i>&nbsp;&nbsp;Home</a></td>
					<td><a href="dashboard.php" class="w3-button"><i class="fa fa-pie-chart" aria-hidden="true"></i>&nbsp;&nbsp;Dashboard</a></td>
					<td><a href="students_group.php" class="w3-button"><i class="fa fa-id-card-o" aria-hidden="true"></i>&nbsp;&nbsp;Students Information</a></td>
				</tr>
				</tbody>
</table></center></div>

					
					