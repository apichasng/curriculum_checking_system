<?php
	session_start();
	$_SESSION["log_fail"] = 'pass';
	require_once("libraries/nusoap.php");
	$proxyhost = '';$proxyport ='';

    $client = new nusoapclient("http://passport.psu.ac.th/authentication/authentication.asmx",false,$proxyhost, $proxyport);
	$client->soap_defencoding = 'UFT-8';
	$params = array(
            'username' =>  $_POST['user_id'],
            'password' =>  $_POST['user_pwd']
        );
	$result = $client->call('GetUserDetails', $params, 'http://tempuri.org/', 'http://tempuri.org/GetUserDetails', false, false, 'rpc', 'literal');
	$err = $client->getError();

	if ($err) {
		$_SESSION["log_fail"]='fail';
	    header("location:check_fail.php");
	}

	else {

	$ID1=$result[0];
	$name=$result[1];
	$surname=$result[2];
	$ID2=$result[3];
	$gender=$result[4];
	$ID_card_number=$result[5];
	$faculty=$result[8];
	$campus=$result[10];
	$title=$result[12];
	$email=$result[13];
	$ou=$result[14];
	$thistime = date("y/m/d-H:i:s");

	include("../connect/connect.php");
	$connect->query("SET NAMES TIS620");
	$result1 = $connect->query('select id FROM visitor');
	$visit=0;
	while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
		if($row[0]==$_POST['user_id']) $visit=1;
	}

		if($visit==0){
			$sql2=('INSERT INTO visitor(visitor_id,id,title,name,surname,gender,id_card,email,position,permistion,times,latest_time) VALUES ("","'.$ID1.'","'.$title.'","'.$name.'","'.$surname.'","'.$gender.'","'.$ID_card_number.'","'.$email.'","'.$ou.'","user","1","'.$thistime.'")');
			$result2 = mysqli_query($connect,$sql2);

			$sql31=('UPDATE visitor SET position="Student" where position like"%Students%"');
			$result31 = mysqli_query($connect,$sql31);

			$sql32=('UPDATE visitor SET position="Staff" where position like"%Staffs%"');
			$result32 = mysqli_query($connect,$sql32);

			$sql33=('UPDATE visitor SET position="Student" where LENGTH(position)>20');
			$result33 = mysqli_query($connect,$sql33);
		}

		else if($visit==1){
			$result4 = $connect->query('select times FROM visitor where id ="'.$_POST['user_id'].'" ');
			while($row = mysqli_fetch_array($result4,MYSQLI_NUM)){
				$times=$row[0];
			}
			$times++;
			$sql5=('UPDATE visitor SET times="'.$times.'",latest_time ="'.$thistime.'" where id ="'.$_POST['user_id'].'"');
			$result5 = mysqli_query($connect,$sql5);
		}

		$connect->query("set names utf8");
		$result6 = $connect->query('select * FROM visitor where id ="'.$_POST['user_id'].'"');
		while($row = mysqli_fetch_array($result6,MYSQLI_NUM)){
			$_SESSION["ID2"]=$row[1];
			$_SESSION["title"]=$row[2];
			$_SESSION["name"]=$row[3];
			$_SESSION["surname"]=$row[4];
			$_SESSION["gender"]=$row[5];
			$_SESSION["email"]=$row[7];
			$_SESSION["position"]=$row[8];
			$_SESSION["permistion"]=$row[9];
			$_SESSION["latest_time"]=$row[11];

		}

		session_write_close();

		if ($_SESSION["sentFrom"]=="AD"){
			if ($_SESSION["permistion"]=="admin") header("location:../administrator/admin.php");
			else header("location:../administrator");
		}

		else {
			if ($_SESSION["position"]=="Student") header("location:../std");
			else if ($_SESSION["position"]=="Staff") header("location:../tcr");
			else {
				$_SESSION["log_fail"]='fail';
				header("location:check_fail.php");
			}
		}

}

?>
