<?php
	session_start();
	include("../connect/connect.php");
	// $connect->query("SET NAMES TIS620");
	$result1 = $connect->query('select * FROM visitor');
	while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
		if($row[1]==$_POST['user_id']){
			$_SESSION["ID2"]=$row[1];
			$_SESSION["title"]=$row[2];
			$_SESSION["name"]=$row[3];
			$_SESSION["surname"]=$row[4];
			$_SESSION["gender"]=$row[5];
			$_SESSION["email"]=$row[7];
			$_SESSION["position"]=$row[8];
			$_SESSION["permistion"]=$row[9];
			$_SESSION["latest_time"]=date("y/m/d-H:i:s");
		}
	}
	session_write_close();

				if ($_SESSION["sentFrom"]=="AD"){
					if ($_SESSION["permistion"]=="admin") header("location:../administrator/admin.php");
					else header("location:../administrator");
				}

				else {
					if ($_SESSION["position"]=="Student") header("location:../std");
					else if ($_SESSION["position"]=="Staff") header("location:../tcr");
					else header("location:check_fail.php");
				}

?>
