<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<style>
.bgimg {
    background-position: center;
    background-size: cover;
    background-image: url("../img/picHead1.jpg");
    min-height: 90%;
}
</style>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<center><div class="w3-top">
<div class="w3-row w3-padding w3-metro-dark-blue">
    <div class="w3-col s5">
    <img src="../img/write-psu.png" width="5%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต
    </div>
	<div class="w3-col s3 w3-display-right">
	&nbsp;
    </div>
</div>
</div></center>
<br/>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large bgimg">

<!-- content -->
<br><br><br>
<div class="w3-container " id="login">
  <div class="w3-content" style="max-width:80%">
	<center>
	<div class="w3-padding-large w3-display-middle w3-light-grey w3-border w3-left-align ">
			<br/><h3 class="w3-center"><span class="w3-wide"><b>ลงชื่อเข้าใช้งาน</b></span></h3>
			<h5 class="w3-center"><span class="w3-tag w3-wide">Login with PSU passport</span></h5>
				<?php if($_SESSION["log_fail"] == 'fail') {
				echo '<br/><div class="w3-panel w3-pale-red w3-display-container">';
				echo '<center><h4><p>Sorry, Your Username or Password is incorrect. <br> Please Login with your PSU passport</p><h4></center>';
				echo '</div>';
				$_SESSION["log_fail"] = 'pass';
			} ?>
			<br/><div>
				<form role="form" name="login_form_1" action="check_log.php" method="post">
				<center><table width="80%">
				<tr><td valign="middle" colspan="3"><i class="w3-large fa fa-user"></i>&nbsp;Username : </td></tr>
				<tr><td colspan="3" align="center"><input class="w3-input w3-animate-input" style="width:80%" name="user_id" type="text" required></td></tr>
				<tr><td valign="middle" colspan="3"><i class="w3-large fa fa-key"></i>&nbsp;Password : </td></tr>
				<tr><td colspan="3" align="center"><input class="w3-input w3-animate-input" style="width:80%" name="user_pwd" type="password" required></td></tr>	
				<tr><td colspan="3">&nbsp;</td></tr>	
				<tr><td valign="middle" align="center"><input class="w3-button w3-round-large" type="submit" value="Login"></td></form><td>&nbsp;</td><form role="form" name="login_form_2" action="../" method="post"><td valign="middle" align="center"><input class="w3-button w3-round-large" type="submit" value="Back"></td></tr></table></center>
			</div></center>
    </div>
  </div>
</div>

<!-- End page content -->
</div>
<!-- Footer -->
<?php include("footer.php"); ?>


</body>
</html>
