<footer>
  <center><div class="w3-container w3-metro-dark-blue w3-animate-bottom w3-card-2 w3-center" align="center" style="max-width:100%">
	<div class="w3-container w3-metro-dark-blue w3-center" align="center" style="max-width:100%">
		<div class="w3-quarter w3-metro-dark-blue w3-padding-48 w3-text-left"> 
			<img src="../img/qr-code-1-300x300.png" alt="qr-code-coc" height="180" width="180">
		</div>

		<div class="w3-quarter w3-metro-dark-blue w3-padding-48 w3-text-left"> 
			<table><tr><td align="left"><b>วิทยาลัยการคอมพิวเตอร์ </b>
			<br>
			<br><i class="fa fa-map-marker"></i> มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต 
			<br>&nbsp;&nbsp;&nbsp;80 หมู่ 1 ถ.วิชิตสงคราม ต.กะทู้ อ.กะทู้ จ.ภูเก็ต 83120 	
			<br><i class="fa fa-phone"></i> Tel. 076-276-471
			<br><i class="fa fa-fax"></i> Fax. 076-276-453
			<br></td></tr></table>
		</div>

		<div class="w3-quarter w3-metro-dark-blue w3-padding-48 w3-text-left"> 
			<table><tr><td align="left"><b>หลักสูตร</b>
			<br>
			<br><small><i class="fa fa-circle-o"></i></small> ระดับปริญญาตรี
			<br>&nbsp;&nbsp;&nbsp;<a href="https://www.computing.psu.ac.th/th/b-sc-information-technology/" target="_blank" style="text-decoration:none" class="w3-hover-opacity"><small><i class="fa fa-dot-circle-o"></i></small> สาขาวิชาเทคโนโลยีสารสนเทศ </a>
			<br>&nbsp;&nbsp;&nbsp;<a href="https://www.computing.psu.ac.th/th/b-sc-electronic-business/" target="_blank" style="text-decoration:none" class="w3-hover-opacity"><small><i class="fa fa-dot-circle-o"></i></small> สาขาวิชาธุรกิจอิเล็กทรอนิกส์ </a>
			<br>&nbsp;&nbsp;&nbsp;<a href="https://www.computing.psu.ac.th/th/b-sc-software-engineering/" target="_blank" style="text-decoration:none" class="w3-hover-opacity"><small><i class="fa fa-dot-circle-o"></i></small> สาขาวิชาวิศวกรรมซอฟต์แวร์ </a>
			<br>&nbsp;&nbsp;&nbsp;<a href="https://www.computing.psu.ac.th/th/b-eng%C2%A0computer-engineering/" target="_blank" style="text-decoration:none" class="w3-hover-opacity"><small><i class="fa fa-dot-circle-o"></i></small> สาขาวิชาวิศวกรรมคอมพิวเตอร์ 
			<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(จบภายใต้คณะวิศวกรรมศาสตร์) </a>
			<br></td></tr></table>
		</div>

		<div class="w3-quarter w3-metro-dark-blue w3-padding-48 w3-text-left"> 
			<table><tr><td align="left"><b>Links ที่เกี่ยวข้อง</b> 
			<br>
			<br><a href="https://www.computing.psu.ac.th/th/" target="_blank" style="text-decoration:none"  class="w3-hover-opacity"><small><i class="fa fa-circle-o"></i></small> วิทยาลัยการคอมพิวเตอร์  </a>
			<br><a href="http://sis-phuket1.psu.ac.th/" target="_blank" style="text-decoration:none"  class="w3-hover-opacity"><small><i class="fa fa-circle-o"></i></small> ระบบสารสนเทศนักศึกษา (sis)  </a>
			<br><a href="https://lms2.psu.ac.th/" target="_blank" style="text-decoration:none" class="w3-hover-opacity"><small><i class="fa fa-circle-o"></i></small> ระบบ LMS2@PSU </a>
			<br><a href="#" target="_blank" style="text-decoration:none" class="w3-hover-opacity"><small><i class="fa fa-circle-o"></i></small> งานทะเบียนกลาง </a></td></tr></table>
		</div>

		<div class="w3-row w3-center"><small> [  <i class="fa fa-creative-commons"></i> 1.0.0 beta version ]<br>ผู้พัฒนา นายธรรชนินทร์ ช่วยชาติ และ นายอภิชา แซ่อึ้ง <br>สาขาธุรกิจอิเล็กทรอนิกส์ วิทยาลัยการคอมพิวเตอร์  มหาวิทยาลัยสงขลานครินทร์ วิทยาSเขตภูเก็ต </small></div>
		<br>
	<div>
  </div></center>
</footer>