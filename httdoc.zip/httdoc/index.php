<?php 
session_start();
if ($_SESSION["position"]=="Student") header("location:std/index.php");
else if ($_SESSION["position"]=="Staff") header("location:tcr/index.php");
$_SESSION["sentFrom"]="US";
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="Generator" content="EditPlus®">
  <meta name="Author" content="">
  <meta name="Keywords" content="">
  <meta name="Description" content="">
  <title>Curriculum checking system</title>
 </head>
<?php include("inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<center><div>
<div class="w3-row w3-metro-dark-blue">
    <table width="95%"><tr><td><div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต</div></td>
	<td><div class="w3-right ">
    <form role="form" name="login_form" action="login/check_log.php" method="post">
		<table><tr height="50%">
		<td valign="middle"><i class="w3-large fa fa-user"></i></td><td>&nbsp;</td><td><input class="w3-input w3-round w3-border" style="height:15" name="user_id" type="text" required></td>
		<td valign="middle"><i class="w3-large fa fa-key"></i></td><td>&nbsp;</td><td><input style="height:15" class="w3-input w3-round w3-border" name="user_pwd" type="password" required></td>
		<td>&nbsp;</td><td valign="middle"><input class="w3-button w3-round-large" type="submit" value="Login"></td>
		</tr></table>
	</form>
    </div></td></tr></table>
</div>
</div></center>
<!-- Header  -->
<?php include("inc.header_index.php"); ?>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
	<br/>
	<div class="w3-container" id="program">
		<div class="w3-content" style="max-width:90%">
			<div class="w3-row-padding w3-content" style="max-width:1400px">
				<!-- left content -->
				<div class="w3-twothird">
					<?php include("inc.main_content_slide.php"); ?> 
					<?php include("inc.main_content_program.php"); ?>
				</div> 
				
				<!-- right content -->
				<div class="w3-third">
					<!-- STD & TCR picture --> 
					<?php include("inc.direct_login.php"); ?>
					<!-- right bae --> 
					<?php include("inc.main_content_right.php"); ?>
				</div>
			</div>
		</div>

<!-- End page content -->
<br><br><br></div>
</div>
<!-- Footer -->
<?php include("inc.footer.php"); ?>
</body>
</html>
