<?php 
session_start();
if ($_SESSION["position"]!="Student") header("location:../administrator");
include("../connect/connect.php");
$connect->query("set names utf8");

if($_GET['action']=="os") {

	$err=0;
	$result = $connect->query('select subjects_code from match_other_sub where std_id = "'.$_SESSION["ID2"].'"');
	while($row = mysqli_fetch_array($result,MYSQLI_NUM)){ 
		if($row[0]==$_GET['code']) $err=2;
	}

	$result1 = $connect->query('select subject_code from match_cur where cur_id = "'.$_GET['id'].'"');
	while($row1 = mysqli_fetch_array($result1,MYSQLI_NUM)){ 
		if($row1[0]==$_GET['code']) $err=3;
	}

	if($err==0){
		$sql=('INSERT INTO match_other_sub (match_os_id, cur_id, std_id, subjects_code, subject_type, subgroup_id, group_id, category_id) VALUES ("","'.$_GET['id'].'","'.$_SESSION["ID2"].'","'.$_GET['code'].'","3","0","0","0")');
		$result = mysqli_query($connect,$sql);
		$_SESSION['status']=1;
	}
	else if ($err==2) $_SESSION['status']=2;
	else if ($err==3) $_SESSION['status']=3;
	header("location:subjects.php");
}

else if($_GET['action']=="movetocur") {

	if(($_GET['code']=="0") or ($_GET['category_id']=="0")) $_SESSION['status']=2;
	else {
		$sql=('UPDATE match_other_sub SET subgroup_id="'.$_GET['subgroup_id'].'",group_id="'.$_GET['group_id'].'",category_id="'.$_GET['category_id'].'" where cur_id = "'.$_GET['id'].'" and std_id =  "'.$_SESSION["ID2"].'" and subjects_code = "'.$_GET['code'].'"');
		$result = mysqli_query($connect,$sql);
		$_SESSION['status']=1;
	}
	header("location:curriculum.php");
}

else if($_GET['action']=="movetocur_x") {

	if(($_GET['code']=="0") or ($_GET['category_id']=="0")) $_SESSION['status']=2;
	else {
		$sql=('UPDATE match_other_sub SET subgroup_id="'.$_GET['subgroup_id'].'",group_id="'.$_GET['group_id'].'",category_id="'.$_GET['category_id'].'" where cur_id = "'.$_GET['id'].'" and std_id =  "'.$_SESSION["ID2"].'" and subjects_code = "'.$_GET['code'].'"');
		$result = mysqli_query($connect,$sql);
		$_SESSION['status']=1;
	}
	header("location:print_tran.php");
}

else if($_GET['action']=="add_subjects") {
	$err=0;
	if( ($_GET['subjects_code']=="") or ($_GET['subjects_name_TH']=="") or ($_GET['subjects_name_EN']=="") or ($_GET['subjects_credit']=="") ) {
		$_SESSION['status']=4;
	}

	$result1 = $connect->query('select subjects_code from subjects');
	while($row1 = mysqli_fetch_array($result1,MYSQLI_NUM)){ 
		if($row1[0]==$_GET['subjects_code']) { 
			$err=1;
			$_SESSION['status']=5;
		}
	}

	if($err==0) {	
		$sql=('INSERT INTO subjects (subjects_id, subjects_code, subjects_name_TH, subjects_name_EN, subjects_credit) VALUES ("","'.$_GET['subjects_code'].'","'.$_GET['subjects_name_TH'].'","'.$_GET['subjects_name_EN'].'","'.$_GET['subjects_credit'].'")');
		$result = mysqli_query($connect,$sql);
		$_SESSION['status']=1;
	}

	header("location:subjects.php");
}

?>
