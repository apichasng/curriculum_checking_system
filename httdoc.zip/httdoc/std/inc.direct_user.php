<?php 
session_start();
?>
	<div class="w3-container w3-light-grey">
      <center><h3><b>..welcome..</b></h3>
      <table border="0" class="w3-responsive">
		<tr><td><div class="w3-card"><a href="personal-info.php"><img src="../img/stdIcon.jpg" class="w3-hover-opacity" width="120" height="120" border="0" alt="Student"></a></div></td>
		<td valign="top"><b>&nbsp;<?php echo $_SESSION["title"].$_SESSION["name"]."&nbsp;".$_SESSION["surname"]; ?></b><br>&nbsp;&nbsp;- ตรวจสอบหลักสูตร<br>&nbsp;&nbsp;- วิชาเทียบโอน</td></tr>
	  </table></center>
	<br/>
	</div>