<?php
session_start();
if ($_SESSION["position"]!="Student") header("location:../index.php");
include("../connect/connect.php");
$connect->query("set names utf8");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.6/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.sidebar-std.php"); ?>

<!-- Header  -->
<?php include("../inc.header_main.php"); ?>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<?php include("inc.middle-menu-std.php"); ?>

<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:80%">

	<?php
	$result0 = $connect->query('select cur_id FROM match_students where students_gcode='.$_SESSION["students_gcode"]);
	$numrows0 = mysqli_num_rows($result0);
	while($row0 = mysqli_fetch_array($result0,MYSQLI_NUM)){
		$_GET['id']=$row0[0];
	}

if($numrows0==0) echo '<br><br><center><h4> - ขออภัย ไม่พบข้อมูลหลักสูตรของท่าน - <h4></center>';

else{

	$result1 = $connect->query('select cur_name FROM curriculum where cur_id='.$_GET['id']);
	while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){
		echo '<br><center><h4 style="text-shadow:1px 1px 0 #444">'.$row[0].'</h4></center><br/>';
	}

	// status
	if($_SESSION['status']==1){
		echo '<div class="w3-panel w3-pale-green w3-card-4"><p><center> Success !!</center></p></div>';
	}
	else if($_SESSION['status']==2){
		echo '<div class="w3-panel w3-pale-red w3-card-4"><p><center> Fail !!</center></p></div>';
	}
	$_SESSION["status"]=0;
?>

  <div class="w3-container">
	<br>
	<!-- เลือกสถานะ  -->
	<div class="w3-bar w3-left-align ">
		<table><tr><th>คำอธิบายสถานะ : </th>
		<td>&nbsp;</td><td><font color="#00cc00"><i class="fa fa-circle"></i></font> : ผ่าน</td>
		<td>&nbsp;</td><td><font color="#ff9933"><i class="fa fa-circle"></i></font> : กำลังเรียน</td>
		<td>&nbsp;</td><td><font color="#ff3333"><i class="fa fa-circle"></i></font> : ไม่ผ่าน</td>
		<td>&nbsp;</td><td><font color="#c0c0c0"><i class="fa fa-circle"></i></font> : ยังไม่ลงทะเบียนเรียน</td>
		</tr></form></table>

	</div>
	<!-- เลือกหมวด  -->
	<div class="w3-bar w3-left-align ">
		<table class="w3-responsive"><tr><th>เลือกหมวดวิชา : </th>
		<td><button class="w3-bar-item w3-button tablink w3-light-grey" onclick="openCity(event,'A')">หมวด วิชาศึกษาทั่วไป </button></td>
		<td><button class="w3-bar-item w3-button tablink" onclick="openCity(event,'B')">หมวด วิชาเฉพาะ</button></td>
		<td><button class="w3-bar-item w3-button tablink" onclick="openCity(event,'C')">หมวด วิชาเลือกเสรี</button></td>
		<td><button class="w3-bar-item w3-button tablink" onclick="openCity(event,'D')">วิชาที่รหัสวิชาไม่ตรงกับหลักสูตร</button></td>
		</tr></table>
	</div>

  <!-- หมวด วิชาศึกษาทั่วไป  -->
  <div id="A" class="w3-container city">
  <table class="w3-table w3-border w3-margin-top" border="1" style="width:100%;">
    <tr class="w3-light-grey">
      <th style="width:5%;" class="w3-center">#</th>
	  <th style="width:10%;" class="w3-center">code</th>
	  <th style="width:65%;" class="w3-center">name</th>
	  <th style="width:10%;" class="w3-center">type</th>
	  <th style="width:10%;" class="w3-center">credit</th>
	  <th style="width:5%;"class="w3-center">status</th>
    </tr>
<?php

  $resultCr = $connect->query('SELECT left(code,1), right(code,1), credit FROM  match_credit where cur_id='.$_GET['id']);
  while($rowcr = mysqli_fetch_array($resultCr,MYSQLI_NUM)){

		for($i=1;$i<16;$i++){
			if($rowcr[0]=='g'){
				if($rowcr[1]==$i) {
					$Cg[$i]=$rowcr[2];
				}
			}
			if($rowcr[0]=='s'){
				if($rowcr[1]==$i){
					$Csg[$i]=$rowcr[2];
				}
			}
		 }
  }

  $resultc1 = $connect->query('select match_subjects.subjects_status,match_cur.*, left(subjects.subjects_credit,1) FROM match_subjects JOIN match_cur ON match_cur.subject_code = match_subjects.subjects_code JOIN subjects ON subjects.subjects_code = match_subjects.subjects_code where subjects_status = 1 and match_cur.cur_id='.$_GET['id'].' and match_subjects.std_id = '.$_SESSION["ID2"].' UNION ALL select match_subjects.subjects_status,match_other_sub.match_os_id,match_other_sub.cur_id,match_other_sub.subjects_code,match_other_sub.subject_type,match_other_sub.subgroup_id,match_other_sub.group_id,match_other_sub.category_id, left(subjects.subjects_credit,1) FROM match_other_sub join match_subjects on match_subjects.subjects_code = match_other_sub.subjects_code join subjects ON subjects.subjects_code = match_other_sub.subjects_code where subjects_status = 1 and match_other_sub.cur_id='.$_GET['id'].' and match_subjects.std_id = '.$_SESSION["ID2"] );

  while($rowc1 = mysqli_fetch_array($resultc1,MYSQLI_NUM)){
	  if($rowc1[7]==1){
		for($i=1;$i<16;$i++){
			if($rowc1[6]==$i) {
				$g1[$i]=$g1[$i]+$rowc1[8];
			}
			if($rowc1[5]==$i){
				$sg1[$i]=$sg1[$i]+$rowc1[8];
			}
		 }
	  }
  }

	$result2 = $connect->query('select subject_group.* FROM match_cur JOIN subject_group ON match_cur.group_id = subject_group.group_id where cur_id='.$_GET['id'].' and group_name !="" and category_id = 1 group by group_id order by group_id asc');

	$key=1;
	while($row2 = mysqli_fetch_array($result2,MYSQLI_NUM)){

		//กลุ่มวิชา
		if($g1[$row2[0]]>=$Cg[$row2[0]]) echo '<tr class="w3-pale-green">';
		else echo '<tr>';
			echo '<td colspan="4"><strong>'.$row2[1].'</strong></td>';
			if($g1[$row2[0]]!="") echo '<td  class="w3-center">'.$g1[$row2[0]].' / '.$Cg[$row2[0]].'</td>';
			else echo '<td  class="w3-center">0 / '.$Cg[$row2[0]].'</td>';
			echo '<td>&nbsp;</td>';
		echo '</tr>';


		//รายชื่อวิชา
				$sg="0";
				$result4 = $connect->query('select match_other_sub.subjects_code, match_other_sub.subject_type, match_other_sub.subgroup_id, match_other_sub.group_id, match_other_sub.category_id, subjects.subjects_name_TH, subjects.subjects_name_EN,subjects.subjects_credit  FROM match_other_sub JOIN subjects ON match_other_sub.subjects_code = subjects.subjects_code where std_id = "'.$_SESSION["ID2"].'" and cur_id='.$_GET['id'].' and category_id = 1 and group_id = '.$row2[0].' UNION ALL select match_cur.subject_code, match_cur.subject_type, match_cur.subgroup_id, match_cur.group_id, match_cur.category_id, subjects.subjects_name_TH, subjects.subjects_name_EN,subjects.subjects_credit FROM match_cur JOIN subjects ON match_cur.subject_code = subjects.subjects_code where cur_id='.$_GET['id'].' and category_id = 1 and group_id = '.$row2[0].' order by subgroup_id asc, subject_type asc, subjects_code');

				while($row4 = mysqli_fetch_array($result4,MYSQLI_NUM)){
					if($row4[2]!="0"){

						//กลุ่มวิชาย่อย
						$result3 = $connect->query('select subject_subgroup.* FROM match_cur JOIN subject_subgroup ON match_cur.subgroup_id = subject_subgroup.subgroup_id where cur_id='.$_GET['id'].' and subgroup_name !="" and subject_subgroup.subgroup_id = '.$row4[2].' and group_id = '.$row2[0].' and category_id = 1 group by subgroup_id order by subgroup_name asc');
						if($sg!=$row4[2]){
							while($row3 = mysqli_fetch_array($result3,MYSQLI_NUM)){
								if($sg1[$row3[0]]>=$Csg[$row3[0]]) echo '<tr class="w3-pale-green">';
								else echo '<tr>';
									echo '<td colspan="4">&nbsp;&nbsp;-&nbsp;&nbsp;'.$row3[1].'</td>';
									if($sg1[$row3[0]]!="") echo '<td  class="w3-center">'.$sg1[$row3[0]].' / '.$Csg[$row3[0]].'</td>';
									else echo '<td  class="w3-center">0 / '.$Csg[$row3[0]].'</td>';
									echo '<td>&nbsp;</td>';
								echo '</tr>';
							}
							$sg=$row4[2];
						}
					}

					$status=0;
					$result5 = $connect->query('select * FROM match_subjects where std_id = '.$_SESSION["ID2"]);
					while($row5 = mysqli_fetch_array($result5,MYSQLI_NUM)){
						if($row4[0]==$row5[2]) $status=$row5[3];
					}

					if($row4[1]==3) echo '<tr bgcolor="#fff7d5">';
					else echo '<tr>';
					  echo '<td bgcolor="#ffffff" class="w3-center">'.$key.'</td>';
					  echo '<td class="w3-center">'.$row4[0].'</td>';
					  echo '<td>'.$row4[5].'&nbsp;|&nbsp;'.$row4[6].'</td>';
					  if($row4[1]==1) echo '<td class="w3-center"><font color="#ff0000">บังคับ</font></td>';
					  else  if($row4[1]==2) echo '<td class="w3-center"><font color="#009900">เลือก</font></td>';
					  else  if($row4[1]==3) echo '<td class="w3-center">เทียบโอน</td>';
					  echo '<td class="w3-center">'.$row4[7].'</td>';
					  ?>
					  <td bgcolor="#ffffff" class="w3-center">
						  <div class="w3-dropdown-hover w3-white">

							<?php if($status==0 ) echo '<span><font color="#c0c0c0"><i class="fa fa-circle"></i></font></span>';
							if($status==1 ) echo '<span><font color="#00cc00"><i class="fa fa-circle"></i></font></span>';
							if($status==2 ) echo '<span><font color="#ff9933"><i class="fa fa-circle"></i></font></span>';
							if($status==3) echo '<span><font color="#ff3333"><i class="fa fa-circle"></i></font></span>';?>

							<div class="w3-dropdown-content w3-bar-block w3-border ">
							   <?php if($status!=0 && $status!=1 ) {?>
							   <a href="javascript:location.href='change_status.php?action=complete&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="ผ่าน"><font color="#00cc00"><i class="fa fa-circle"></i></font></a><?php }?>
							    <?php if($status!=0 && $status!=2 ) {?>
							   <a href="javascript:location.href='change_status.php?action=waitting&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="กำลังศึกษา"><font color="#ff9933"><i class="fa fa-circle"></i></font></a><?php }?>
							   <?php if($status!=0 && $status!=3 ) {?>
							   <a href="javascript:location.href='change_status.php?action=incomplete&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="ไม่ผ่าน"><font color="#ff3333"><i class="fa fa-circle"></i></font></a><?php }?>
							   <?php if($status!=0) {?>
							   <a href="javascript:location.href='change_status.php?action=null&id=<?=$row4[0];?>'" class="w3-button" data-toggle="tooltip" title="ยังไม่ลงทะเบียน"><font color="#c0c0c0"><i class="fa fa-circle"></i></font></a><?php }?>
							   <?php if($status==0) {?>
							   <a href="javascript:location.href='change_status.php?action=tocomplete&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="ผ่าน"><font color="#00cc00"><i class="fa fa-circle"></i></font></a>
							   <a href="javascript:location.href='change_status.php?action=towaitting&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="กำลังศึกษา"><font color="#ff9933"><i class="fa fa-circle"></i></font></a>
							   <a href="javascript:location.href='change_status.php?action=toincomplete&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="ไม่ผ่าน"><font color="#ff3333"><i class="fa fa-circle"></i></font></a><?php }?>
							</div>
						  </div>

					  </td>
					  <?php

					echo '</tr>';
				$key++;
				}
	}
?>
  </table>
  </div>

 <!-- หมวด วิชาเฉพาะ  -->
 <div id="B" class="w3-container city" style="display:none">
  <table class="w3-table w3-border w3-margin-top" border="1" style="width:100%;">
    <tr class="w3-light-grey">
      <th style="width:5%;" class="w3-center">#</th>
	  <th style="width:10%;" class="w3-center">code</th>
	  <th style="width:65%;" class="w3-center">name</th>
	  <th style="width:10%;" class="w3-center">type</th>
	  <th style="width:10%;" class="w3-center">credit</th>
	  <th style="width:5%;"class="w3-center">status</th>
    </tr>
<?php

  $resultCr = $connect->query('SELECT left(code,1), right(code,1), credit FROM  match_credit where cur_id='.$_GET['id']);
  while($rowcr = mysqli_fetch_array($resultCr,MYSQLI_NUM)){

		for($i=1;$i<16;$i++){
			if($rowcr[0]=='g'){
				if($rowcr[1]==$i) {
					$Cg[$i]=$rowcr[2];
				}
			}
			if($rowcr[0]=='s'){
				if($rowcr[1]==$i){
					$Csg[$i]=$rowcr[2];
				}
			}
		 }
  }

  $resultc2 = $connect->query('select match_subjects.subjects_status,match_cur.*, left(subjects.subjects_credit,1) FROM match_subjects JOIN match_cur ON match_cur.subject_code = match_subjects.subjects_code JOIN subjects ON subjects.subjects_code = match_subjects.subjects_code where subjects_status = 1 and match_cur.cur_id='.$_GET['id'].' and match_subjects.std_id = '.$_SESSION["ID2"].'  UNION ALL select match_subjects.subjects_status,match_other_sub.match_os_id,match_other_sub.cur_id,match_other_sub.subjects_code,match_other_sub.subject_type,match_other_sub.subgroup_id,match_other_sub.group_id,match_other_sub.category_id, left(subjects.subjects_credit,1) FROM match_other_sub join match_subjects on match_subjects.subjects_code = match_other_sub.subjects_code join subjects ON subjects.subjects_code = match_other_sub.subjects_code where subjects_status = 1 and match_other_sub.cur_id='.$_GET['id'].' and match_subjects.std_id = '.$_SESSION["ID2"] );

  while($rowc2 = mysqli_fetch_array($resultc2,MYSQLI_NUM)){
	  if($rowc2[7]==2){
		for($i=1;$i<16;$i++){
			if($rowc2[6]==$i) {
				$g2[$i]=$g2[$i]+$rowc2[8];
			}
			if($rowc2[5]==$i){
				$sg2[$i]=$sg2[$i]+$rowc2[8];
			}
		 }
	  }
  }

	$result2 = $connect->query('select subject_group.* FROM match_cur JOIN subject_group ON match_cur.group_id = subject_group.group_id where cur_id='.$_GET['id'].' and group_name !="" and category_id = 2 group by group_id order by group_id asc');

	$key=1;
	while($row2 = mysqli_fetch_array($result2,MYSQLI_NUM)){

		//กลุ่มวิชา
		if($g2[$row2[0]]>=$Cg[$row2[0]]) echo '<tr class="w3-pale-green">';
		else echo '<tr>';
			echo '<td colspan="4"><strong>'.$row2[1].'</strong></td>';
			if($g2[$row2[0]]!="") echo '<td class="w3-center">'.$g2[$row2[0]].' / '.$Cg[$row2[0]].'</td>';
			else echo '<td class="w3-center">0 / '.$Cg[$row2[0]].'</td>';
			echo '<td>&nbsp;</td>';
		echo '</tr>';


		//รายชื่อวิชา
				$sg="0";
				$result4 = $connect->query('select match_other_sub.subjects_code, match_other_sub.subject_type, match_other_sub.subgroup_id, match_other_sub.group_id, match_other_sub.category_id, subjects.subjects_name_TH, subjects.subjects_name_EN,subjects.subjects_credit  FROM match_other_sub JOIN subjects ON match_other_sub.subjects_code = subjects.subjects_code where std_id = "'.$_SESSION["ID2"].'" and cur_id='.$_GET['id'].' and category_id = 2 and group_id = '.$row2[0].' UNION ALL select match_cur.subject_code, match_cur.subject_type, match_cur.subgroup_id, match_cur.group_id, match_cur.category_id, subjects.subjects_name_TH, subjects.subjects_name_EN,subjects.subjects_credit FROM match_cur JOIN subjects ON match_cur.subject_code = subjects.subjects_code where cur_id='.$_GET['id'].' and category_id = 2 and group_id = '.$row2[0].' order by subgroup_id asc, subject_type asc, subjects_code');

				while($row4 = mysqli_fetch_array($result4,MYSQLI_NUM)){
					if($row4[2]!="0"){

						//กลุ่มวิชาย่อย
						$result3 = $connect->query('select subject_subgroup.* FROM match_cur JOIN subject_subgroup ON match_cur.subgroup_id = subject_subgroup.subgroup_id where cur_id='.$_GET['id'].' and subgroup_name !="" and subject_subgroup.subgroup_id = '.$row4[2].' and group_id = '.$row2[0].' and category_id = 2 group by subgroup_id order by subgroup_name asc');
						if($sg!=$row4[2]){
							while($row3 = mysqli_fetch_array($result3,MYSQLI_NUM)){
								if($sg2[$row3[0]]>=$Csg[$row3[0]]) echo '<tr class="w3-pale-green">';
								else echo '<tr>';
									echo '<td colspan="4">&nbsp;&nbsp;-&nbsp;&nbsp;'.$row3[1].'</td>';
									if($sg2[$row3[0]]!="") echo '<td class="w3-center">'.$sg2[$row3[0]].' / '.$Csg[$row3[0]].'</td>';
									else echo '<td class="w3-center">0 / '.$Csg[$row3[0]].'</td>';
									echo '<td>&nbsp;</td>';
								echo '</tr>';
							}
							$sg=$row4[2];
						}
					}

					$status=0;
					$result5 = $connect->query('select * FROM match_subjects where std_id = '.$_SESSION["ID2"]);
					while($row5 = mysqli_fetch_array($result5,MYSQLI_NUM)){
						if($row4[0]==$row5[2]) $status=$row5[3];
					}

					if($row4[1]==3) echo '<tr bgcolor="#fff7d5">';
					else echo '<tr>';
					  echo '<td bgcolor="#ffffff" class="w3-center">'.$key.'</td>';
					  echo '<td class="w3-center">'.$row4[0].'</td>';
					  echo '<td>'.$row4[5].'&nbsp;|&nbsp;'.$row4[6].'</td>';
					  if($row4[1]==1) echo '<td class="w3-center"><font color="#ff0000">บังคับ</font></td>';
					  else  if($row4[1]==2) echo '<td class="w3-center"><font color="#009900">เลือก</font></td>';
					  else  if($row4[1]==3) echo '<td class="w3-center">เทียบโอน</td>';
					  echo '<td class="w3-center">'.$row4[7].'</td>';
					  ?>
					  <td bgcolor="#ffffff" class="w3-center">
						  <div class="w3-dropdown-hover w3-white">

							<?php if($status==0 ) echo '<span><font color="#c0c0c0"><i class="fa fa-circle"></i></font></span>';
							if($status==1 ) echo '<span><font color="#00cc00"><i class="fa fa-circle"></i></font></span>';
							if($status==2 ) echo '<span><font color="#ff9933"><i class="fa fa-circle"></i></font></span>';
							if($status==3) echo '<span><font color="#ff3333"><i class="fa fa-circle"></i></font></span>';?>

							<div class="w3-dropdown-content w3-bar-block w3-border ">
							   <?php if($status!=0 && $status!=1 ) {?>
							   <a href="javascript:location.href='change_status.php?action=complete&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="ผ่าน"><font color="#00cc00"><i class="fa fa-circle"></i></font></a><?php }?>
							    <?php if($status!=0 && $status!=2 ) {?>
							   <a href="javascript:location.href='change_status.php?action=waitting&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="กำลังศึกษา"><font color="#ff9933"><i class="fa fa-circle"></i></font></a><?php }?>
							   <?php if($status!=0 && $status!=3 ) {?>
							   <a href="javascript:location.href='change_status.php?action=incomplete&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="ไม่ผ่าน"><font color="#ff3333"><i class="fa fa-circle"></i></font></a><?php }?>
							   <?php if($status!=0) {?>
							   <a href="javascript:location.href='change_status.php?action=null&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="ยังไม่ลงทะเบียน"><font color="#c0c0c0"><i class="fa fa-circle"></i></font></a><?php }?>
							   <?php if($status==0) {?>
							   <a href="javascript:location.href='change_status.php?action=tocomplete&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="ผ่าน"><font color="#00cc00"><i class="fa fa-circle"></i></font></a>
							   <a href="javascript:location.href='change_status.php?action=towaitting&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="กำลังศึกษา"><font color="#ff9933"><i class="fa fa-circle"></i></font></a>
							   <a href="javascript:location.href='change_status.php?action=toincomplete&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="ไม่ผ่าน"><font color="#ff3333"><i class="fa fa-circle"></i></font></a><?php }?>
							</div>
						  </div>

					  </td>
					  <?php

					echo '</tr>';
				$key++;
				}
	}
?>
  </table>
  </div>


<!-- หมวด วิชาเลือกเสรี  -->
 <div id="C" class="w3-container city" style="display:none">
  <table class="w3-table w3-border w3-margin-top" border="1" style="width:100%;">
    <tr class="w3-light-grey">
      <th style="width:5%;" class="w3-center">#</th>
	  <th style="width:10%;" class="w3-center">code</th>
	  <th style="width:65%;" class="w3-center">name</th>
	  <th style="width:10%;" class="w3-center">type</th>
	  <th style="width:10%;" class="w3-center">credit</th>
	  <th style="width:5%;"class="w3-center">status</th>
    </tr>

<?php
  $resultCr = $connect->query('SELECT credit FROM  match_credit where cur_id='.$_GET['id'].' and code = "c3"');
  while($rowcr = mysqli_fetch_array($resultCr,MYSQLI_NUM)){
	 $C3 = $rowcr[0];
  }

  $resultc2 = $connect->query('select match_subjects.subjects_status,match_other_sub.match_os_id,match_other_sub.cur_id,match_other_sub.subjects_code,match_other_sub.subject_type,match_other_sub.subgroup_id,match_other_sub.group_id,match_other_sub.category_id, left(subjects.subjects_credit,1) FROM match_other_sub join match_subjects on match_subjects.subjects_code = match_other_sub.subjects_code join subjects ON subjects.subjects_code = match_other_sub.subjects_code where subjects_status = 1 and match_other_sub.cur_id='.$_GET['id'].' and match_subjects.std_id = '.$_SESSION["ID2"] );

  $credit=0;
  while($rowc2 = mysqli_fetch_array($resultc2,MYSQLI_NUM)){
	  if($rowc2[7]==3){
		$credit=$credit+$rowc2[8];
	  }
  }

	if($credit>=$C3) echo '<tr class="w3-pale-green">';
	else echo '<tr>';
	echo '<td colspan="4"><b>วิชาเลือกเสรี :</b> นักศึกษาสามารถเลือกเรียนวิชาใด ๆ ที่เปิดสอนในมหาวิทยาลัยสงขลานครินทร์ หรือมหาวิทยาลัย อื่น ๆ ทั้งในและต่างประเทศ ซึ่งมีเนื้อหาไม่ซ้ําซ้อนกัน หรือใกล้เคียงกับเนื้อหาวิชา ในหมวดศึกษาทั่วไป วิชาเฉพาะ หรือรายวิชาที่เรียนมาแล้ว</td>
		<td class="w3-center">'.$credit.' / '.$C3.'</td>
		<td>&nbsp;</td>
	</tr>';

	$key=1;

		//รายชื่อวิชา
				$sg="0";
				$result4 = $connect->query('select match_other_sub.subjects_code, match_other_sub.subject_type, match_other_sub.subgroup_id, match_other_sub.group_id, match_other_sub.category_id, subjects.subjects_name_TH, subjects.subjects_name_EN,subjects.subjects_credit  FROM match_other_sub JOIN subjects ON match_other_sub.subjects_code = subjects.subjects_code where std_id = "'.$_SESSION["ID2"].'" and cur_id='.$_GET['id'].' and category_id = 3 UNION ALL select match_cur.subject_code, match_cur.subject_type, match_cur.subgroup_id, match_cur.group_id, match_cur.category_id, subjects.subjects_name_TH, subjects.subjects_name_EN,subjects.subjects_credit FROM match_cur JOIN subjects ON match_cur.subject_code = subjects.subjects_code where cur_id='.$_GET['id'].' and category_id = 3 order by subgroup_id asc, subject_type asc, subjects_code');

				while($row4 = mysqli_fetch_array($result4,MYSQLI_NUM)){
					$status=0;
					$result5 = $connect->query('select * FROM match_subjects where std_id = '.$_SESSION["ID2"]);
					while($row5 = mysqli_fetch_array($result5,MYSQLI_NUM)){
						if($row4[0]==$row5[2]) $status=$row5[3];
					}

					if($row4[1]==3) echo '<tr bgcolor="#fff7d5">';
					else echo '<tr>';
					  echo '<td bgcolor="#ffffff" class="w3-center">'.$key.'</td>';
					  echo '<td class="w3-center">'.$row4[0].'</td>';
					  echo '<td>'.$row4[5].'&nbsp;|&nbsp;'.$row4[6].'</td>';
					  if($row4[1]==1) echo '<td class="w3-center"><font color="#ff0000">บังคับ</font></td>';
					  else  if($row4[1]==2) echo '<td class="w3-center"><font color="#009900">เลือก</font></td>';
					  else  if($row4[1]==3) echo '<td class="w3-center">เทียบโอน</td>';
					  echo '<td class="w3-center">'.$row4[7].'</td>';
					  ?>
					  <td bgcolor="#ffffff" class="w3-center">
						  <div class="w3-dropdown-hover w3-white">

							<?php if($status==0 ) echo '<span><font color="#c0c0c0"><i class="fa fa-circle"></i></font></span>';
							if($status==1 ) echo '<span><font color="#00cc00"><i class="fa fa-circle"></i></font></span>';
							if($status==2 ) echo '<span><font color="#ff9933"><i class="fa fa-circle"></i></font></span>';
							if($status==3) echo '<span><font color="#ff3333"><i class="fa fa-circle"></i></font></span>';?>

							<div class="w3-dropdown-content w3-bar-block w3-border ">
							   <?php if($status!=0 && $status!=1 ) {?>
							   <a href="javascript:location.href='change_status.php?action=complete&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="ผ่าน"><font color="#00cc00"><i class="fa fa-circle"></i></font></a><?php }?>
							    <?php if($status!=0 && $status!=2 ) {?>
							   <a href="javascript:location.href='change_status.php?action=waitting&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="กำลังศึกษา"><font color="#ff9933"><i class="fa fa-circle"></i></font></a><?php }?>
							   <?php if($status!=0 && $status!=3 ) {?>
							   <a href="javascript:location.href='change_status.php?action=incomplete&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="ไม่ผ่าน"><font color="#ff3333"><i class="fa fa-circle"></i></font></a><?php }?>
							   <?php if($status!=0) {?>
							   <a href="javascript:location.href='change_status.php?action=null&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="ยังไม่ลงทะเบียน"><font color="#c0c0c0"><i class="fa fa-circle"></i></font></a><?php }?>
							   <?php if($status==0) {?>
							   <a href="javascript:location.href='change_status.php?action=tocomplete&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="ผ่าน"><font color="#00cc00"><i class="fa fa-circle"></i></font></a>
							   <a href="javascript:location.href='change_status.php?action=towaitting&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="กำลังศึกษา"><font color="#ff9933"><i class="fa fa-circle"></i></font></a>
							   <a href="javascript:location.href='change_status.php?action=toincomplete&id=<?=$row4[0];?>&cur_id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="ไม่ผ่าน"><font color="#ff3333"><i class="fa fa-circle"></i></font></a><?php }?>
							</div>
						  </div>

					  </td>
					  <?php

					echo '</tr>';
				$key++;
				}
?>
  </table>
  </div>

  <!-- หมวด วิชาที่ต้องเทียบโอน  -->
 <div id="D" class="w3-container city" style="display:none">
	<div id="id01" class="w3-modal"><center>
		<div class="w3-modal-content w3-animate-top">
			<header class="w3-container w3-teal">
				<span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-display-topright">&times;</span>
				 <h2>เลือกหมวดหมู่ เพื่อเพิ่มวิชา</h2>
			</header>

			<div class="w3-container w3-padding-24">
				<span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-display-topright">&times;</span>
				<form action="add.php" method="GET"><table>

					<tr><th class="w3-left-align" style="width:30%;">เลือกหมวดวิชา</th>
					<?php $result3 = $connect->query('select subject_category.* FROM subject_category JOIN match_credit ON match_credit.code = subject_category.category_code where match_credit.cur_id = '.$_GET['id'].' and category_name !="" order by category_id asc'); ?>
					<th colspan="2"><select class="w3-select" name="category_id">
					<option value="0" selected>เลือกหมวดวิชา</option>
					<?php while($row = mysqli_fetch_array($result3,MYSQLI_NUM)){
						echo '<option value="'.$row[0].'">'.$row[1].'</option>';
					} ?>
					</select></th></tr>

					<tr><th class="w3-left-align">เลือกกลุ่มวิชา</th>
					<?php $result3 = $connect->query('select subject_group.* FROM subject_group JOIN match_credit ON match_credit.code = subject_group.group_code where match_credit.cur_id = '.$_GET['id'].' and group_name !="" order by group_id asc'); ?>
					<th colspan="2"><select class="w3-select" name="group_id">
					<option value="0" selected>เลือกกลุ่มวิชา</option>
					<?php while($row = mysqli_fetch_array($result3,MYSQLI_NUM)){
						echo '<option value="'.$row[0].'">'.$row[1].'</option>';
					} ?>
					</select></th></tr>

				    <tr><th class="w3-left-align">เลือกกลุ่มวิชาย่อย</th>
					<?php $result3 = $connect->query('select subject_subgroup.* FROM subject_subgroup JOIN match_credit ON match_credit.code = subject_subgroup.subgroup_code where match_credit.cur_id = '.$_GET['id'].' and subgroup_name !="" order by subgroup_id asc'); ?>
					<th colspan="2"><select class="w3-select" name="subgroup_id">
					<option value="0" selected>ไม่มีกลุ่มวิชาย่อย</option>
					<?php while($row = mysqli_fetch_array($result3,MYSQLI_NUM)){
						echo '<option value="'.$row[0].'">'.$row[1].'</option>';
					} ?>
					</select></th></tr>

					<tr><th class="w3-left-align">เลือกวิชา</th>
					<?php $result3 = $connect->query('select match_other_sub.*,subjects.subjects_name_TH FROM match_other_sub join subjects on match_other_sub.subjects_code = subjects.subjects_code where category_id = 0 and cur_id ="'.$_GET['id'].'" and std_id = "'.$_SESSION["ID2"].'" order by subjects.subjects_code asc '); ?>
					<th colspan="2"><select class="w3-select" name="code">
					<option value="0" selected>เลือกวิชา</option>
					<?php while($row = mysqli_fetch_array($result3,MYSQLI_NUM)){
						echo '<option value="'.$row[3].'">'.$row[3].' | '.$row[8].'</option>';
					} ?>
					</select></th></tr>

				</table>

				<div class="w3-panel w3-padding-16"><input type="hidden" name="action" value="movetocur"><input type="hidden" name="id" value="<?php echo $_GET['id']; ?>"><input class="w3-button w3-border" type="submit" value="Confirm"></form> <button onclick="document.getElementById('id01').style.display='none'" type="button" class="w3-button w3-border">Cancel</button></div>
			</div>
		</div></center>
	</div>
	<br><button onclick="location.href='subjects.php'" data-toggle="tooltip" title="เพิ่มวิชา" class="w3-button w3-border"><font color="green"><i class="fa fa-plus"></i> add subjects</font></button>
	&nbsp;<button onclick="document.getElementById('id01').style.display='block'" data-toggle="tooltip" title="ย้ายลงหลักสูตร" class="w3-button w3-border"><font color="green"><i class="fa fa-retweet"></i> subjects transfer</font></button>
	&nbsp;<a href="exportpdf_tran.php" target="_blank" class="w3-button w3-border" data-toggle="tooltip" title="พิมพ์แบบคำร้องขอเทียบโอนรายวิชา" ><font color="green"><i class="fa fa-print" aria-hidden="true"></i>&nbsp;&nbsp;print</font></a>

    <table class="w3-table w3-border w3-margin-top" border="1" style="width:100%;">
    <tr class="w3-light-grey">
      <th style="width:5%;" align="center">#</th>
	  <th style="width:10%;" align="center">code</th>
	  <th style="width:65%;" align="center">name</th>
	  <th style="width:10%;" align="center">credit</th>
	  <th style="width:5%;" align="center">action</th>
    </tr>
<?php
	$result4 = $connect->query('select subjects.*,match_other_sub.* FROM match_other_sub JOIN subjects ON match_other_sub.subjects_code = subjects.subjects_code where match_other_sub.cur_id='.$_GET['id'].' and std_id ='.$_SESSION["ID2"].' order by match_other_sub.subjects_code asc');
	$numrows4 = mysqli_num_rows($result4);

	if($numrows4>0){
		$key=1;
		while($row4 = mysqli_fetch_array($result4,MYSQLI_NUM)){

			$status=0;
			echo '<tr>';
			echo '<td class="w3-center">'.$key.'</td>';
			echo '<td>'.$row4[1].'</td>';
			echo '<td>'.$row4[2].'&nbsp;|&nbsp;'.$row4[3].'</td>';
			echo '<td class="w3-center">'.$row4[4].'</td>';
?>
			<?php if($row4[12]==0) { ?><td align="center"><a href="javascript:location.href='edit.php?action=removeOS&id=<?=$row4[6];?>&code=<?=$row4[1];?>'" class="w3-button" data-toggle="tooltip" title="remove"><font color="red"><i class="fa fa-trash-o"></i></font></a></td></tr>
			<?php }else { ?><td align="center"><a href="javascript:location.href='edit.php?action=resetOS&id=<?=$row4[6];?>&code=<?=$row4[1];?>'" class="w3-button" data-toggle="tooltip" title="reset"><font color="red"><i class="fa fa-refresh"></i></font></a></td></tr>
<?php
			}
		$status=$row4[13];
		$key++;
		}
	}
	else echo '<tr><td colspan="5" class="w3-center"> - ไม่พบข้อมูล - </td></tr>';

 ?>

  </table>
  </div>

  </div>
</div>

<?php	}  ?>

<script>

function openCity(evt, cityName) {
  var i, x, tablinks;
  x = document.getElementsByClassName("city");
  for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < x.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" w3-light-grey", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " w3-light-grey";
}

$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
});

</script>
</div>

<!-- End page content -->
<br><br><br></div>

<!-- Footer -->
<?php include("../inc.footer.php"); ?>
</body>
</html>
