<?php 
session_start();
if ($_SESSION["position"]!="Student") header("location:../index.php");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.6/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.sidebar-std.php"); ?>

<!-- Header  -->
<?php include("../inc.header_main.php"); ?>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<?php include("inc.middle-menu-std.php"); ?>

<center><div class="w3-container" style="max-width:80%">
	<div class="w3-container w3-padding-16" >
		<br/><h3 class="w3-center"><span class="w3-wide"><b>เพิ่มรายวิชา</b></span></h3>
		<h5 class="w3-center"><span class="w3-tag w3-wide">Add Subjects</span></h5>
	</div>
	
	<br/>ค้นหารายชื่อ หรือรหัสวิชา ที่ผลการเรียนผ่านเกณฑ์แล้ว
	<div class="w3-container w3-padding-16" ><br/>
		<form name="subject_search" action="subject_search.php" method="post">
		<table width="100%">
		<tr>
			<td style="width:95%;"><input class="w3-input w3-border w3-left-align" type="text" name="search" value="<?php echo $_POST['search'] ?>"></td>
			<td >&nbsp;</td>
			<td style="width:10%;"><button type="submit" class="w3-button w3-teal">ค้นหา</button></td>
			</form>
			<td >&nbsp;</td>
			<td style="width:10%;"><a href="subjects.php" class="w3-button w3-light-grey">กลับ</a></td>
		</tr>
		</table>
		
	</div>

	<div class="w3-container">
		<form name="subject_add" action="#" method="post">
		<table class="w3-table w3-border w3-hoverable w3-responsive w3-margin-top" border="1" style="width:100%;">
		<tr class="w3-light-grey">
		<th style="width:5%;" align="center">ลำดับ</th>
		<th style="width:10%;" align="center">รหัสวิชา</th>
		<th style="width:70%;" align="center">ชื่อวิชา</th>
		<th style="width:10%;" align="center">หน่วยกิจ</th>
		<th style="width:10%;" align="center">เลือก</th>
		</tr>
		<tr>
		  <td align="center">1</td>
		  <td>975-150*</td>
		  <td>ภาษาอังกฤษเตรียมความพร้อม&nbsp;|&nbsp;Preparatory English</td>
		  <td align="center">3(1-4-4)</td>
		  <td><button class="w3-button w3-light-grey">เพิ่ม</button></td>
		</tr>
		</table>
		</form>
	</div></center>


<!-- End page content -->
<br><br><br></div>
<!-- Footer -->
<?php include("../inc.footer.php"); ?>

</body>
</html>
