<?php
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
include("../connect/connect.php");
$connect->query("set names utf8");

	if ($_GET["action"]=="tocomplete"){
		$sql=('INSERT INTO match_subjects (match_sub_id, std_id, subjects_code, subjects_status, update_date, cur_id) VALUES ("","'.$_SESSION["ID2"].'","'.$_GET["id"].'","1","'.date("Y-m-d H:i:s").'","'.$_GET["cur_id"].'")');
		$result = mysqli_query($connect,$sql);
	}

	else if ($_GET["action"]=="towaitting"){
		$sql=('INSERT INTO match_subjects (match_sub_id, std_id, subjects_code, subjects_status, update_date, cur_id) VALUES ("","'.$_SESSION["ID2"].'","'.$_GET["id"].'","2","'.date("Y-m-d H:i:s").'","'.$_GET["cur_id"].'")');
		$result = mysqli_query($connect,$sql);
	}

	else if ($_GET["action"]=="toincomplete"){
		$sql=('INSERT INTO match_subjects (match_sub_id, std_id, subjects_code, subjects_status, update_date, cur_id) VALUES ("","'.$_SESSION["ID2"].'","'.$_GET["id"].'","3","'.date("Y-m-d H:i:s").'","'.$_GET["cur_id"].'")');
		$result = mysqli_query($connect,$sql);
	}

	else if ($_GET["action"]=="complete"){
		$sql=('UPDATE match_subjects SET subjects_status="1", update_date = "'.date("Y-m-d H:i:s").'" WHERE std_id="'.$_SESSION["ID2"].'" and subjects_code="'.$_GET["id"].'"');
		$result = mysqli_query($connect,$sql);
	}

	else if ($_GET["action"]=="waitting"){
		$sql=('UPDATE match_subjects SET subjects_status="2", update_date = "'.date("Y-m-d H:i:s").'" WHERE std_id="'.$_SESSION["ID2"].'" and subjects_code="'.$_GET["id"].'"');
		$result = mysqli_query($connect,$sql);
	}

	else if ($_GET["action"]=="incomplete"){
		$sql=('UPDATE match_subjects SET subjects_status="3", update_date = "'.date("Y-m-d H:i:s").'" WHERE std_id="'.$_SESSION["ID2"].'" and subjects_code="'.$_GET["id"].'"');
		$result = mysqli_query($connect,$sql);
	}

	else if ($_GET["action"]=="null"){
		$sql=('DELETE FROM match_subjects WHERE std_id="'.$_SESSION["ID2"].'" and subjects_code="'.$_GET["id"].'"');
		$result = mysqli_query($connect,$sql);
	}




	header("location:curriculum.php");
?>