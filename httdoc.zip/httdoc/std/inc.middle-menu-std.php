<div class="w3-container w3-metro-dark-blue">
<center><table align="center"  data-role="table"  id="movie-table" data-mode="reflow" class="w3-responsive">
			<thead>
				<tr><th></th></tr>
			</thead>
			<tbody>
				<tr>
					<td><a href="../std" class="w3-button"><i class="fa fa-home" aria-hidden="true"></i>&nbsp;&nbsp;Home</a></td>
					<td><a href="personal-info.php" class="w3-button"><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Personal Information</a></td>
					<td><a href="subjects.php" class="w3-button"><i class="fa fa-file-text" aria-hidden="true"></i>&nbsp;&nbsp;Add Subjects</a></td>
					<td><a href="curriculum.php" class="w3-button"><i class="fa fa-database" aria-hidden="true"></i>&nbsp;&nbsp;My Curriculum</a></td>
					<td><a href="print_tran.php" class="w3-button"><i class="fa fa-exchange" aria-hidden="true"></i>&nbsp;&nbsp;Subjects Transference</a></td>					
				</tr>
				</tbody>
</table></center></div>

