<?php 
session_start();
if ($_SESSION["position"]!="Student") header("location:../index.php");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.6/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.sidebar-std.php"); ?>

<!-- Header  -->
<?php include("../inc.header_main.php"); ?>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<?php include("inc.middle-menu-std.php"); ?>

<center><div class="w3-container" style="max-width:80%">
	<div class="w3-container w3-padding-16" >
		<br/><h3 class="w3-center"><span class="w3-wide"><b>เพิ่มรายวิชาที่ลงทะเบียนเรียน ภายนอกหลักสูตร</b></span></h3>
		<h5 class="w3-center"><span class="w3-tag w3-wide">Add Subjects</span></h5><br/>
	</div>
<?php
	// status
	if($_SESSION['status']==1){
		echo '<div class="w3-panel w3-pale-green w3-card-4"><p><center> Success !!</center></p></div>';
	}
	else if($_SESSION['status']==2){
		echo '<div class="w3-panel w3-pale-red w3-card-4"><p><center> Fail !!  This Subjects has alraedy added</center></p></div>';	
	}
	else if($_SESSION['status']==3){
		echo '<div class="w3-panel w3-pale-red w3-card-4"><p><center> Fail !!  This Subjects has alraedy in your curriculum </center></p></div>';	
	}
	else if($_SESSION['status']==4){
		echo '<div class="w3-panel w3-pale-red w3-card-4"><p><center> Fail !! </center></p></div>';	
	}
	else if($_SESSION['status']==5){
		echo '<div class="w3-panel w3-pale-red w3-card-4"><p><center> Fail !!  This Subjects has alraedy added </center></p></div>';	
	}
	$_SESSION["status"]=0;
?>

	<table><tr><td style="width:100%;"><form method="GET" action="subjects.php"><input class="w3-input w3-border" type="text" name="search" value="<?php echo $_GET['search']; ?>"></td><td>&nbsp;</td><td style="width:5%;"><input class="w3-button w3-round-large w3-green" type="submit" value="search"></form></td><td>&nbsp;</td><td><input type="submit" value="add new" class="w3-button w3-round-large w3-green" onClick="javascript:location.href='add-new-subjects.php'"></td></tr></table>
	
	<table class="w3-table w3-border w3-hoverable w3-responsive w3-margin-top" border="1" style="width:100%;" id="myTable1">
    <tr class="w3-light-grey">
      <th style="width:5%;" align="center">#</th>
	  <th style="width:10%;" align="center">code </th>
	  <th style="width:36%;" align="center">name in Thai</th>
	  <th style="width:36%;" align="center">name in English</th>
	  <th style="width:10%;" align="center">credit</th>
	  <th style="width:10%;" align="center">add</th>
    </tr>
	
<?php 
	include("../connect/connect.php");
	$connect->query("set names utf8");
	$result0 = $connect->query('select cur_id FROM match_students where students_gcode='.$_SESSION["students_gcode"]);
	while($row0 = mysqli_fetch_array($result0,MYSQLI_NUM)){
		$_GET['id']=$row0[0];
	}

	$result = $connect->query('select * FROM subjects where subjects_code like "%'.$_GET['search'].'%" or subjects_name_TH like "%'.$_GET['search'].'%" or subjects_name_EN like "%'.$_GET['search'].'%" or subjects_credit like "%'.$_GET['search'].'%" order by subjects_code asc');
	$numrows = mysqli_num_rows($result);
	
	if($numrows>0){
		
		if(!isset($_GET['page']))$_GET['page']=1;
		$page=$_GET['page'];
		$rows="20";
		$total_data = mysqli_num_rows($result);
		$total_page = ceil($total_data/$rows);
		$start=($page-1)*$rows;
		$Connum=(($page*20)-20)+1;
		$order=$Connum;

		$result1 = $connect->query('select * FROM subjects where subjects_code like "%'.$_GET['search'].'%" or subjects_name_TH like "%'.$_GET['search'].'%" or subjects_name_EN like "%'.$_GET['search'].'%" or subjects_credit like "%'.$_GET['search'].'%" order by subjects_code asc Limit '.$start.',20');
		
		while($row = mysqli_fetch_array($result1,MYSQLI_NUM)){ 
			echo '<tr><td>'.$order.'</td>';
			echo '<td>'.$row[1].'</td>';
			echo '<td>'.$row[2].'</td>';
			echo '<td>'.$row[3].'</td>';
			echo '<td>'.$row[4].'</td>';
?>
			<td><center><a href="javascript:location.href='add.php?action=os&code=<?=$row[1];?>&id=<?=$_GET['id'];?>'" class="w3-button" data-toggle="tooltip" title="เพิ่ม"><font color="green"><i class="fa fa-plus"></i></font></a></center></td></tr>
<?php
			$order++;
		}

	}
	else echo '<tr><td colspan="6" class="w3-center"> - ไม่พบข้อมูล - </td></tr>';

	echo '</table>';

	$Connum=-19;
	$Nextpage=$page+1;
	$Prepage=$page-1;
?>	
	<br><center><table style="width:40%;"><tr>
	<td style="width:5%;"><input type="submit" value="<<" class="w3-button w3-teal" onClick="javascript:location.href='subjects.php?page=1&search=<?php echo $_GET['search']; ?>'" <?php if($page<=1) echo 'disabled'; ?>></td>
	<td style="width:5%;"><input type="submit" value="<" class="w3-button w3-teal" onClick="javascript:location.href='subjects.php?page=<?php echo $Prepage; ?>&search=<?php echo $_GET['search']; ?>'" <?php if($page<=1) echo 'disabled'; ?>></td>

	<td style="width:10%;"><form method="GET" action="subjects.php"><input class="w3-input w3-border w3-center" type="number" name="page" value="<?php echo $_GET['page']; ?>"></td><td style="width:10%;" align="center"><?php echo ' / '.$total_page; ?></td><td style="width:5%;"><input type="hidden" value="search"><input class="w3-button" type="submit" value="go page"></form></td>

	<td style="width:5%;"><input type="submit" value=">" class="w3-button w3-teal" onClick="javascript:location.href='subjects.php?page=<?php echo $Nextpage; ?>&search=<?php echo $_GET['search']; ?>'" <?php if($page>=$total_page) echo 'disabled'; ?>></td>
	<td style="width:5%;"><input type="submit" value=">>" class="w3-button w3-teal" onClick="javascript:location.href='subjects.php?page=<?php echo $total_page; ?>&search=<?php echo $_GET['search']; ?>'" <?php if($page>=$total_page) echo 'disabled'; ?>></td>
	</tr></table>
	
	</div>


<!-- End page content -->
<br><br><br></div>
<!-- Footer -->
<?php include("../inc.footer.php"); ?>

</body>
</html>
