<?php 
session_start();
if ($_SESSION["position"]!="Student") header("location:../index.php");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.6/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.sidebar-std.php"); ?>

<!-- Header  -->
<?php include("../inc.header_main.php"); ?>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<?php include("inc.middle-menu-std.php"); ?>

<center><div class="w3-container" style="max-width:80%">
	<div class="w3-container w3-padding-16" >
		<br/><h3 class="w3-center"><span class="w3-wide"><b>ข้อมูลหลักสูตร</b></span></h3>
		<h5 class="w3-center"><span class="w3-tag w3-wide">Curriculum</span></h5>
	</div>

<div class="w3-container w3-animate-top w3-padding-16">
  <h3><b>หลักสูตรxxxxxxxxxxxxxxxxxxxxx</b></h3>
  <p>..จำนวนหน่วยกิจ รวมตลอดหลักสูตร 130 หน่วยกิจ..</p>
  
  <!-- เลือกหมวด  -->
  <div class="w3-container">
    <div class="w3-bar w3-left-align ">
	<table ><tr><th>เลือกดูจากสถานะ : </th>
	<td>&nbsp;</td><td><form role="form" name="filter_1" action="curStatus.php" method="post"><input type="hidden" name="status" value="completed"><button type="submit" class="w3-bar-item w3-button" data-toggle="tooltip" title="Completed"><font color="#00cc33"><i class="fa fa-circle" aria-hidden="true"></i></font></button></td>
	<td>&nbsp;</td><td><form role="form" name="filter_2" action="curStatus.php" method="post"><input type="hidden" name="status" value="waitting"><button type="submit" class="w3-bar-item w3-button" data-toggle="tooltip" title="Waitting"><font color="#ff9933"><i class="fa fa-circle" aria-hidden="true"></i></font></button></td>
	<td>&nbsp;</td><td><form role="form" name="filter_3" action="curStatus.php" method="post"><input type="hidden" name="status" value="incomplete"><button type="submit" class="w3-bar-item w3-button" data-toggle="tooltip" title="Incomplete"><font color="#ff3333"><i class="fa fa-circle" aria-hidden="true"></i></font></button></td>
	</tr></form></table>
	</div>

	<div class="w3-bar w3-left-align ">
		<table class="w3-responsive"><tr><th>เลือกหมวดวิชา : </th>
		<td><button class="w3-bar-item w3-button tablink w3-teal" onclick="openCity(event,'A')">หมวด วิชาศึกษาทั่วไป </button></td>
		<td><button class="w3-bar-item w3-button tablink" onclick="openCity(event,'B')">หมวด วิชาเฉพาะ</button></td>
		<td><button class="w3-bar-item w3-button tablink" onclick="openCity(event,'C')">หมวด วิชาเลือกเสรี</button></td>
		<td><button class="w3-bar-item w3-button tablink" onclick="openCity(event,'D')">วิชาที่ต้องเทียบโอน</button></td>
		</tr></table>
	</div>
  </div>

  <!-- หมวด วิชาศึกษาทั่วไป  -->
  <div id="A" class="w3-container city">
  <table class="w3-table w3-border w3-hoverable w3-responsive w3-margin-top" border="1" style="width:100%;">
    <tr class="w3-light-grey">
      <th style="width:5%;" align="center">ลำดับ</th>
	  <th style="width:10%;" align="center">รหัสวิชา</th>
	  <th style="width:70%;" align="center">ชื่อวิชา</th>
	  <th style="width:10%;" align="center">หน่วยกิจ</th>
	  <th style="width:15%;" align="center">สถานะ</th>
    </tr>
	<tr>
		<td colspan="3">กลุ่มวิชาภาษา</td>
		<td>12</td>
		<td>X</td>
	</tr>
	<tr>
      <td align="center">1</td>
      <td>975-150*</td>
	  <td>ภาษาอังกฤษเตรียมความพร้อม&nbsp;|&nbsp;Preparatory English</td>
      <td align="center">3(1-4-4)</td>
	  <td align="center">X</td>
    </tr>
    <tr>
      <td align="center">2</td>
      <td>975-150*</td>
	  <td>ภาษาอังกฤษเตรียมความพร้อม&nbsp;|&nbsp;Preparatory English</td>
      <td align="center">3(1-4-4)</td>
	  <td align="center">X</td>
    </tr>
  </table>
  </div>

 <!-- หมวด วิชาเฉพาะ  -->
 <div id="B" class="w3-container city" style="display:none">
   <table class="w3-table w3-border w3-hoverable w3-responsive w3-margin-top" border="1" style="width:100%;">
    <tr class="w3-light-grey">
      <th style="width:5%;" align="center">ลำดับ</th>
	  <th style="width:10%;" align="center">รหัสวิชา</th>
	  <th style="width:70%;" align="center">ชื่อวิชา</th>
	  <th style="width:10%;" align="center">หน่วยกิจ</th>
	  <th style="width:15%;" align="center">สถานะ</th>
    </tr>
	<tr>
		<td colspan="3">กลุ่มวิชาแกน</td>
		<td>30</td>
		<td>X</td>
	</tr>
	<tr>
      <td align="center">1</td>
      <td>976-120</td>
	  <td>คณิตศาสตร์&nbsp;|&nbsp;Mathematics</td>
      <td align="center">3(3-0-6)</td>
	  <td align="center">X</td>
    </tr>
    <tr>
      <td align="center">2</td>
      <td>976-120</td>
	  <td>คณิตศาสตร์&nbsp;|&nbsp;Mathematics</td>
      <td align="center">3(3-0-6)</td>
	  <td align="center">X</td>
    </tr>
  </table>
  </div>

  <!-- หมวด วิชาเลือกเสรี  -->
 <div id="C" class="w3-container city" style="display:none">
   <table class="w3-table w3-border w3-hoverable w3-responsive w3-margin-top" border="1" style="width:100%;">
    <tr class="w3-light-grey">
      <th style="width:5%;" align="center">ลำดับ</th>
	  <th style="width:10%;" align="center">รหัสวิชา</th>
	  <th style="width:70%;" align="center">ชื่อวิชา</th>
	  <th style="width:10%;" align="center">หน่วยกิจ</th>
	  <th style="width:15%;" align="center">สถานะ</th>
    </tr>
	<tr>
		<td colspan="3">นักศึกษาสามารถเลือกเรียนวิชาใด ๆ ที่เปิดสอนในมหาวิทยาลัยสงขลานครินทร์ หรือมหาวิทยาลัย อื่น ๆ ทั้งในและต่างประเทศ ซึ่งมีเนื้อหาไม่ซ้ําซ้อนกัน หรือใกล้เคียงกับเนื้อหาวิชา ในหมวดศึกษาทั่วไป วิชาเฉพาะ หรือรายวิชาที่เรียนมาแล้ว</td>
		<td>6</td>
		<td>X</td>
	</tr>
	<tr>
      <td align="center">1</td>
      <td>XXX-XXX</td>
	  <td>XXXXXXXXXXXXXXX&nbsp;|&nbsp;XXXXXXXXXXXXXXX</td>
      <td align="center">X(X-X-X)</td>
	  <td align="center">X</td>
    </tr>
    <tr>
      <td align="center">2</td>
      <td>XXX-XXX</td>
	  <td>XXXXXXXXXXXXXXX&nbsp;|&nbsp;XXXXXXXXXXXXXXX</td>
      <td align="center">X(X-X-X)</td>
	  <td align="center">X</td>
    </tr>
  </table>
  </div>

  <!-- หมวด วิชาที่ต้องเทียบโอน  -->
  <div id="D" class="w3-container city" style="display:none">
  <table class="w3-table w3-border w3-hoverable w3-responsive w3-margin-top" border="1" style="width:100%;">
    <tr class="w3-light-grey">
      <th style="width:5%;" align="center">ลำดับ</th>
	  <th style="width:10%;" align="center">รหัสวิชา</th>
	  <th style="width:70%;" align="center">ชื่อวิชา</th>
	  <th style="width:10%;" align="center">หน่วยกิจ</th>
    </tr>
	<tr>
      <td align="center">1</td>
      <td>975-150*</td>
	  <td>ภาษาอังกฤษเตรียมความพร้อม&nbsp;|&nbsp;Preparatory English</td>
      <td align="center">3(1-4-4)</td>
    </tr>
    <tr>
      <td align="center">2</td>
      <td>975-150*</td>
	  <td>ภาษาอังกฤษเตรียมความพร้อม&nbsp;|&nbsp;Preparatory English</td>
      <td align="center">3(1-4-4)</td>
    </tr>
  </table>
  <br/><a href="exportpdf_tran.php" target="_blank" class="w3-button w3-gray w3-center"><i class="fa fa-print" aria-hidden="true"></i>&nbsp;&nbsp;พิมพ์แบบคำร้องขอเทียบโอนรายวิชา</a>
  </div>

<br/><br/>
</div>


<button onclick="myFunction2('Demo2')" class="w3-button w3-block w3-teal w3-left-align ">Download&nbsp;&nbsp;<i class="fa fa-download" aria-hidden="true"></i></button>



</div></center>


<script>

function openCity(evt, cityName) {
  var i, x, tablinks;
  x = document.getElementsByClassName("city");
  for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < x.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" w3-teal", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " w3-teal";
}

$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});

</script>

<!-- End page content -->
<br><br><br></div>
<!-- Footer -->
<?php include("../inc.footer.php"); ?>

</body>
</html>
