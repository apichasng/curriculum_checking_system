<?php 
session_start();
if ($_SESSION["position"]!="Student") header("location:../index.php");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.6/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.sidebar-std.php"); ?>

<!-- Header  -->
<?php include("../inc.header_main.php"); ?>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<?php include("inc.middle-menu-std.php"); ?>

<center><div class="w3-container" style="max-width:80%">
	<div class="w3-container w3-padding-16" >
		<br/><h3 class="w3-center"><span class="w3-wide"><b>เพิ่มรายวิชาที่ลงทะเบียนเรียน ภายนอกหลักสูตร</b></span></h3>
		<h5 class="w3-center"><span class="w3-tag w3-wide">Add Subjects</span></h5><br/>
	</div>
<?php
	// status
	if($_SESSION['status']==1){
		echo '<div class="w3-panel w3-pale-green w3-card-4"><p><center> Success !!</center></p></div>';
	}
	else if($_SESSION['status']==2){
		echo '<div class="w3-panel w3-pale-red w3-card-4"><p><center> Fail !!  This Subjects has alraedy added</center></p></div>';	
	}
	else if($_SESSION['status']==3){
		echo '<div class="w3-panel w3-pale-red w3-card-4"><p><center> Fail !!  This Subjects has alraedy in your curriculum </center></p></div>';	
	}
	$_SESSION["status"]=0;

	echo '<br><form action="add.php" method="get">';
	echo '<center><table class="w3-table w3-margin-top " border="0" style="width:75%;" id="myTable1">';
	echo '<tr><th style="width:25%;"><h5><strong>รหัสวิชา :</h5></strong></th>';
    echo '<th style="width:80%;"><input class="w3-input w3-border-1" type="text" name="subjects_code" style="width:100%" required></tr>';
	echo '<tr><th><h5><strong>ชื่อวิชาภาษาไทย :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1" type="text" name="subjects_name_TH" style="width:100%" required></tr>';
	echo '<tr><th><h5><strong>ชื่อวิชาภาษาอังกฤษ :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1 type="text" name="subjects_name_EN" style="width:100%" required></tr>';
	echo '<tr><th><h5><strong>หน่วยกิจ :</h5></strong></th>';
    echo '<th><input class="w3-input w3-border-1" type="text" name="subjects_credit" style="width:100%" required></tr>';
    echo '</table></center>';

	echo '<br><center><table><tr><td><input type="hidden" name="action" value="add_subjects">';
    echo '<input type="submit" class="w3-button w3-block w3-border" value="Confirm"></form></td><td><input type="button" class="w3-button w3-border" value="Cancel" onclick="javascript:history.back()" /></td></tr></table>';
?>


<!-- End page content -->
<br><br><br></div>
<!-- Footer -->
<?php include("../inc.footer.php"); ?>

</body>
</html>
