<?php 
session_start();
if ($_SESSION["position"]!="Student") header("location:../index.php");
include("../connect/connect.php");
$connect->query("set names utf8");
$result0 = $connect->query('select cur_id FROM match_students where students_gcode='.$_SESSION["students_gcode"]);
	$numrows0 = mysqli_num_rows($result0);
	while($row0 = mysqli_fetch_array($result0,MYSQLI_NUM)){
		$_GET['id']=$row0[0];
	}
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.6/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.sidebar-std.php"); ?>

<!-- Header  -->
<?php include("../inc.header_main.php"); ?>

<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">

<!-- content -->
<?php include("inc.middle-menu-std.php"); ?>

<center><div class="w3-container" style="max-width:80%">
<div class="w3-container w3-padding-16 w3-right">
	<div class="w3-container w3-padding-16" >
		<br/><h3 class="w3-center"><span class="w3-wide"><b>พิมพ์คำร้องขอเทียบโอน/รับโอน/เทียบเท่ารายวิชา</b></span></h3>
		<h5 class="w3-center"><span class="w3-tag w3-wide">Subjects Transference</span></h5>
	</div>
<?php 
// status
	if($_SESSION['status']==1){
		echo '<div class="w3-panel w3-pale-green w3-card-4"><p><center> Success !!</center></p></div>';
	}
	else if($_SESSION['status']==2){
		echo '<div class="w3-panel w3-pale-red w3-card-4"><p><center> Fail !!</center></p></div>';
	}
	$_SESSION["status"]=0;
?>
	<div id="id01" class="w3-modal"><center>
		<div class="w3-modal-content w3-animate-top">
			<header class="w3-container w3-teal">
				<span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-display-topright">&times;</span>
				 <h2>เลือกหมวดหมู่ เพื่อเพิ่มวิชา</h2>
			</header>

			<div class="w3-container w3-padding-24">
				<span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-display-topright">&times;</span>
				<form action="add.php" method="GET"><table>

					<tr><th class="w3-left-align" style="width:30%;">เลือกหมวดวิชา</th>
					<?php $result3 = $connect->query('select subject_category.* FROM subject_category JOIN match_credit ON match_credit.code = subject_category.category_code where match_credit.cur_id = '.$_GET['id'].' and category_name !="" order by category_id asc'); ?>
					<th colspan="2"><select class="w3-select" name="category_id">
					<option value="0" selected>เลือกหมวดวิชา</option>
					<?php while($row = mysqli_fetch_array($result3,MYSQLI_NUM)){
						echo '<option value="'.$row[0].'">'.$row[1].'</option>';
					} ?>
					</select></th></tr>

					<tr><th class="w3-left-align">เลือกกลุ่มวิชา</th>
					<?php $result3 = $connect->query('select subject_group.* FROM subject_group JOIN match_credit ON match_credit.code = subject_group.group_code where match_credit.cur_id = '.$_GET['id'].' and group_name !="" order by group_id asc'); ?>
					<th colspan="2"><select class="w3-select" name="group_id">
					<option value="0" selected>เลือกกลุ่มวิชา</option>
					<?php while($row = mysqli_fetch_array($result3,MYSQLI_NUM)){
						echo '<option value="'.$row[0].'">'.$row[1].'</option>';
					} ?>
					</select></th></tr>

				    <tr><th class="w3-left-align">เลือกกลุ่มวิชาย่อย</th>
					<?php $result3 = $connect->query('select subject_subgroup.* FROM subject_subgroup JOIN match_credit ON match_credit.code = subject_subgroup.subgroup_code where match_credit.cur_id = '.$_GET['id'].' and subgroup_name !="" order by subgroup_id asc'); ?>
					<th colspan="2"><select class="w3-select" name="subgroup_id">
					<option value="0" selected>ไม่มีกลุ่มวิชาย่อย</option>
					<?php while($row = mysqli_fetch_array($result3,MYSQLI_NUM)){
						echo '<option value="'.$row[0].'">'.$row[1].'</option>';
					} ?>
					</select></th></tr>

					<tr><th class="w3-left-align">เลือกวิชา</th>
					<?php $result3 = $connect->query('select match_other_sub.*,subjects.subjects_name_TH FROM match_other_sub join subjects on match_other_sub.subjects_code = subjects.subjects_code where category_id = 0 and cur_id ="'.$_GET['id'].'" and std_id = "'.$_SESSION["ID2"].'" order by subjects.subjects_code asc '); ?>
					<th colspan="2"><select class="w3-select" name="code">
					<option value="0" selected>เลือกวิชา</option>
					<?php while($row = mysqli_fetch_array($result3,MYSQLI_NUM)){
						echo '<option value="'.$row[3].'">'.$row[3].' | '.$row[8].'</option>';
					} ?>
					</select></th></tr>

				</table>

				<div class="w3-panel w3-padding-16"><input type="hidden" name="action" value="movetocur_x"><input type="hidden" name="id" value="<?php echo $_GET['id']; ?>"><input class="w3-button w3-border" type="submit" value="Confirm"></form> <button onclick="document.getElementById('id01').style.display='none'" type="button" class="w3-button w3-border">Cancel</button></div>
			</div>
		</div></center>
	</div>

	<table align="left"><tr><td><button onclick="location.href='subjects.php'" data-toggle="tooltip" title="เพิ่มวิชา" class="w3-button w3-border"><font color="green"><i class="fa fa-plus"></i> add subjects</font></button>
	&nbsp;<button onclick="document.getElementById('id01').style.display='block'" data-toggle="tooltip" title="ย้ายลงหลักสูตร" class="w3-button w3-border"><font color="green"><i class="fa fa-retweet"></i> subjects transfer</font></button>
	&nbsp;<a href="exportpdf_tran.php" target="_blank" class="w3-button w3-border" data-toggle="tooltip" title="พิมพ์แบบคำร้องขอเทียบโอนรายวิชา" ><font color="green"><i class="fa fa-print" aria-hidden="true"></i>&nbsp;&nbsp;print</font></a></td></tr></table>

	<p>&nbsp;</p>
    <table class="w3-table w3-border w3-margin-top" border="1" style="width:100%;">
    <tr class="w3-light-grey">
      <th style="width:5%;" align="center">#</th>
	  <th style="width:10%;" align="center">code</th>
	  <th style="width:65%;" align="center">name</th>
	  <th style="width:10%;" align="center">credit</th>
	  <th style="width:5%;" align="center">action</th>
    </tr>
<?php
	$result4 = $connect->query('select subjects.*,match_other_sub.* FROM match_other_sub JOIN subjects ON match_other_sub.subjects_code = subjects.subjects_code where match_other_sub.cur_id='.$_GET['id'].' and std_id ='.$_SESSION["ID2"].' and category_id !=0 order by match_other_sub.subjects_code asc');
	$numrows4 = mysqli_num_rows($result4);

	if($numrows4>0){
		$key=1;
		while($row4 = mysqli_fetch_array($result4,MYSQLI_NUM)){

			$status=0;
			echo '<tr>';
			echo '<td class="w3-center">'.$key.'</td>';
			echo '<td>'.$row4[1].'</td>';
			echo '<td>'.$row4[2].'&nbsp;|&nbsp;'.$row4[3].'</td>';
			echo '<td class="w3-center">'.$row4[4].'</td>';
?>
			<?php if($row4[12]==0) { ?><td align="center"><a href="javascript:location.href='edit.php?action=removeOS&id=<?=$row4[6];?>&code=<?=$row4[1];?>'" class="w3-button" data-toggle="tooltip" title="remove"><font color="red"><i class="fa fa-trash-o"></i></font></a></td></tr>
			<?php }else { ?><td align="center"><a href="javascript:location.href='edit.php?action=resetOS_X&id=<?=$row4[6];?>&code=<?=$row4[1];?>'" class="w3-button" data-toggle="tooltip" title="reset"><font color="red"><i class="fa fa-refresh"></i></font></a></td></tr>
<?php
			}
		$status=$row4[13];
		$key++;
		}
	}
	else echo '<tr><td colspan="5" class="w3-center"> - ไม่พบข้อมูล - </td></tr>';

 ?>

  </table>
  </div>

  </div>

</div>


</div></center>


<!-- End page content -->
<br><br><br></div>
<!-- Footer -->
<?php include("../inc.footer.php"); ?>

</body>
</html>
