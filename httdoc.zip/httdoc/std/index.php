<?php 
session_start();
if ($_SESSION["position"]!="Student") header("location:../index.php");
include("../connect/connect.php");
$connect->query("set names utf8");
$_SESSION["students_gcode"]=substr($_SESSION["ID2"], 0, 7);
$result0 = $connect->query('select cur_id FROM match_students where students_gcode='.$_SESSION["students_gcode"]);
	$numrows0 = mysqli_num_rows($result0);
	while($row0 = mysqli_fetch_array($result0,MYSQLI_NUM)){
		$_GET['id']=$row0[0];
	}
if($numrows0==0) header("location:../visitor.php");
?>
<!DOCTYPE html>
<html>
<title>Curriculum checking system</title>
<?php include("../inc.includeCss.php"); ?>
<body>
<!-- topbar -->
<?php include("inc.sidebar-std.php"); ?>

<!-- Header  -->
<?php include("../inc.header_mainx.php"); ?>


<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-white w3-large">
<?php include("inc.middle-menu-std.php"); ?>

<!-- content -->

	<br/>
	<div class="w3-container" id="program">
		<div class="w3-content" style="max-width:90%">
			<div class="w3-row-padding w3-content" style="max-width:1400px">
				<!-- left content -->
				<div class="w3-twothird">
					<?php include("inc.main_content_slide.php"); ?> 
					<?php include("../inc.main_content_program.php"); ?>
				</div> 
				
				<!-- right content -->
				<div class="w3-third">
					<!-- STD & TCR picture --> 
					<?php include("inc.direct_user.php"); ?>
					<!-- right bae --> 
					<?php include("../inc.main_content_right.php"); ?>
				</div>
			</div>
		</div>
	</div>
<!-- End page content -->
<br><br><br></div>

<!-- Footer -->
<?php include("../inc.footer.php"); ?>
</body>
</html>
