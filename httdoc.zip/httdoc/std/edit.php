<?php 
session_start();
if ($_SESSION["permistion"]!="admin") header("location:../administrator");
include("../connect/connect.php");
$connect->query("set names utf8");

if($_GET['action']=="resetOS") {

	$sql=('UPDATE match_other_sub SET subgroup_id="0",group_id="0",category_id="0" where cur_id = "'.$_GET['id'].'" and std_id =  "'.$_SESSION["ID2"].'" and subjects_code = "'.$_GET['code'].'"');
	$result = mysqli_query($connect,$sql);

	$sql1=('DELETE FROM match_subjects where std_id =  "'.$_SESSION["ID2"].'" and subjects_code = "'.$_GET['code'].'"');
	$result1 = mysqli_query($connect,$sql1);

	$_SESSION['status']=1;
	header("location:curriculum.php");
}

else if($_GET['action']=="resetOS_X") {

	$sql=('UPDATE match_other_sub SET subgroup_id="0",group_id="0",category_id="0" where cur_id = "'.$_GET['id'].'" and std_id =  "'.$_SESSION["ID2"].'" and subjects_code = "'.$_GET['code'].'"');
	$result = mysqli_query($connect,$sql);

	$sql1=('DELETE FROM match_subjects where std_id =  "'.$_SESSION["ID2"].'" and subjects_code = "'.$_GET['code'].'"');
	$result1 = mysqli_query($connect,$sql1);

	$_SESSION['status']=1;
	header("location:print_tran.php");
}

else if($_GET['action']=="removeOS") {

	$sql=('DELETE FROM match_other_sub where cur_id = "'.$_GET['id'].'" and std_id =  "'.$_SESSION["ID2"].'" and subjects_code = "'.$_GET['code'].'"');
	$result = mysqli_query($connect,$sql);
	$_SESSION['status']=1;
	header("location:curriculum.php");
}

?>
