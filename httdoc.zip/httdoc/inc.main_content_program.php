<!-- major info -->
	<h3 class="w3-center"><span class="w3-wide"><b>หลักสูตร ปริญญาตรี | PROGRAM (BACHELOR DEGREE)</b></span></h3>
    <!-- major menu -->
	<br/><div class="w3-row w3-center w3-card w3-padding">
      <a href="javascript:void(0)" onclick="openMenu(event, 'it');" id="myLink"><div class="w3-col s3 tablink">สาขาวิชาเทคโนโลยีสารสนเทศ</div></a>
	  <a href="javascript:void(0)" onclick="openMenu(event, 'eb');"><div class="w3-col s3 tablink">สาขาวิชาธุรกิจอิเล็กทรอนิกส์</div></a>
      <a href="javascript:void(0)" onclick="openMenu(event, 'se');"><div class="w3-col s3 tablink">สาขาวิชาวิศวกรรมซอฟต์แวร์</div></a>
      <a href="javascript:void(0)" onclick="openMenu(event, 'coe');"><div class="w3-col s3 tablink">สาขาวิศวกรรมคอมพิวเตอร์</div></a>
    </div>

	<!-- it -->
    <div id="it" class="w3-container menu w3-padding-24 w3-card">
      <table class="w3-table-all" width="100%" border="0">
	  <tr><td colspan="2"><h4><center><b>สาขาวิชาเทคโนโลยีสารสนเทศ</b></center></h4></td></tr>
	  <tr><td width="100"><b>ชื่อเต็ม:</b></td><td>&nbsp;วิทยาศาสตรบัณฑิต (เทคโนโลยีสารสนเทศ) Bachelor of Science (Information Technology)</td></tr>
	  <tr><td width="100"><b>ชื่อย่อ:</b></td><td>&nbsp;วท.บ.(เทคโนโลยีสารสนเทศ) B.Sc. (Information Technology)</td></tr>
	  <tr><td width="100"><b>ปรัชญา Philosophy:</b></td><td>&nbsp;เพื่อผลิตบัณฑิตที่มีความรู้และทักษะด้านเทคโนโลยีสารสนเทศ ที่มีคุณธรรม สอดคล้องกับความต้องการของอุตสาหกรรมซอฟต์แวร์</td></tr>
	  <tr><td width="100"><b>วัตถุประสงค์ Goals:</b></td><td>&nbsp;1) ผลิตบัณฑิตที่มีความรู้และทักษะด้านเทคโนโลยีสารสนเทศ <br>&nbsp;2) ผลิตบัณฑิตที่มีทักษะ สามารถนำความรู้ไปประกอบวิชาชีพได้ โดยเน้นทักษะในด้านการประยุกต์ใช้เทคโนโลยีสารสนเทศร่วมกับองค์กร ในด้านการวิเคราะห์และออกแบบระบบ การวางระบบเครือข่าย การออกแบบแอนิเมชันและเทคโนโลยีมัลติมีเดีย<br>&nbsp;3) สร้างบัณฑิตที่มีคุณธรรม จริยธรรม และเจตคติที่ดีต่อวิชาชีพ</td></tr>

	  <tr><td colspan="2"><center><a href="https://www.computing.psu.ac.th/th/b-sc-information-technology/" target="_blank" class="w3-button w3-border w3-white">&nbsp;&nbsp;- view more -</a></td>  </center></td></tr>
	  </table>
    </div>

	<!-- se -->
    <div id="se" class="w3-container menu w3-padding-24 w3-card">
      <table class="w3-table-all" width="100%" border="0">
	  <tr><td colspan="2"><h4><center><b>สาขาวิชาวิศวกรรมซอฟต์แวร์</b></center></h4></td></tr>
	  <tr><td width="100"><b>ชื่อเต็ม:</b></td><td>&nbsp;วิทยาศาสตรบัณฑิต (วิศวกรรมซอฟต์แวร์) Bachelor of Science (Software Engineering)</td></tr>
	  <tr><td width="100"><b>ชื่อย่อ:</b></td><td>&nbsp;วท.บ. (วิศวกรรมซอฟต์แวร์) B.Sc. (Software Engineering)</td></tr>
	  <tr><td width="100"><b>ปรัชญา Philosophy:</b></td><td>&nbsp;เพื่อผลิตบัณฑิต สาขาวิชาวิศวกรรมซอฟต์แวร์ ที่มีความรู้ ความสามารถ และทักษะในการนำหลักการทางวิศวกรรมซอฟต์แวร์ซึ่งเป็นศาสตร์ที่ให้ความสำคัญเกี่ยวกับกระบวนการพัฒนาซอฟต์แวร์ และการจัดการโครงการซอฟต์แวร์มาประยุกต์ใช้ในการพัฒนาซอฟต์แวร์ได้อย่างมีประสิทธิภาพ</td></tr>
	  <tr><td width="100"><b>วัตถุประสงค์ Goals:</b></td><td><br>&nbsp;1) มีความรู้ความสามารถและทักษะ ในการนำหลักการทางวิศวกรรมซอฟต์แวร์ไปประยุกต์ใช้ในการพัฒนาซอฟต์แวร์ได้อย่างมีประสิทธิภาพ<br>&nbsp;2) มีคุณธรรมจริยธรรมมีจิตสำนึกในความรับผิดชอบต่อส่วนรวมและมีความสามารถในการปรับตัวให้เข้ากับสังคมและสิ่งแวดล้อม<br>&nbsp;3) มีความรู้พื้นฐานเพียงพอสำหรับนำไปใช้ในการศึกษาและการวิจัยในขั้นสูงได้</td></tr>

	  <tr><td colspan="2"><center><a href="https://www.computing.psu.ac.th/th/b-sc-software-engineering/" target="_blank" class="w3-button w3-border w3-white">&nbsp;&nbsp;- view more -</a></td>  </center></td></tr>
	  </table>
    </div> 

	<!-- eb -->
	<div id="eb" class="w3-container menu w3-padding-24 w3-card">
      <table class="w3-table-all" width="100%" border="0">
	  <tr><td colspan="2"><h4><center><b>สาขาวิชาธุรกิจอิเล็กทรอนิกส์</b></center></h4></td></tr>
	  <tr><td width="100"><b>ชื่อเต็ม:</b></td><td>&nbsp;วิทยาศาสตรบัณฑิต (ธุรกิจอิเล็กทรอนิกส์) Bachelor of Science (Electronic Business)</td></tr>
	  <tr><td width="100"><b>ชื่อย่อ:</b></td><td>&nbsp;วท.บ.(ธุรกิจอิเล็กทรอนิกส์) B.Sc. (Electronic Business)</td></tr>
	  <tr><td width="100"><b>ปรัชญา Philosophy:</b></td><td>&nbsp;เพื่อผลิตบัณฑิต สาขาวิชาธุรกิจอิเล็กทรอนิกส์ ที่มีความรู้ ความชำนาญในการนำเทคโนโลยีคอมพิวเตอร์และการสื่อสารไปประยุกต์ใช้ในการพัฒนาศักยภาพในการดำเนินภาคธุรกิจและภาครัฐโดยเน้นอิเล็กทรอนิกส์ในรูปแบบต่างๆ</td></tr>
	  <tr><td width="100"><b>วัตถุประสงค์ Goals:</b></td><td><br>&nbsp;1) ผลิตบัณฑิตที่มีความรู้เทคโนโลยีอิเล็กทรอนิกส์และการบริหารจัดการ<br>&nbsp;2) ผลิตบัณฑิตที่มีความรู้ด้านการบริหารจัดการมาประยุกต์ใช้ในการดำเนินงานขององค์กร โดยเน้นเทคโนโลยีอิเล็กทรอนิกส์ในรูปแบบต่าง ๆ<br>&nbsp;3) ผลิตบัณฑิตที่มีความรู้และความสามารถในการวิจัยและพัฒนาทางด้านธุรกิจอิเล็กทรอนิกส์ ที่นำไปสู่การศึกษาและการพัฒนาความรู้ที่สูงขึ้น<br>&nbsp;4) สร้างบัณฑิตที่มีคุณธรรม จริยธรรม และเจตคติที่ดีต่อวิชาชีพ</td></tr>

	  <tr><td colspan="2"><center><a href="https://www.computing.psu.ac.th/th/b-sc-electronic-business/" target="_blank" class="w3-button w3-border w3-white">&nbsp;&nbsp;- view more -</a></td>  </center></td></tr>
	  </table>
    </div>

	<!-- coe -->
	<div id="coe" class="w3-container menu w3-padding-24 w3-card">
     <table class="w3-table-all" width="100%" border="0">
	  <tr><td colspan="2"><h4><center><b>สาขาวิศวกรรมคอมพิวเตอร์</b></center></h4></td></tr>
	  <tr><td width="100"><b>ชื่อเต็ม:</b></td><td>&nbsp;วิศวกรรมศาสตรบัณฑิต (วิศวกรรมคอมพิวเตอร์)  Bachelor of Engineering (Computer Engineering)  ** (จบภายใต้คณะวิศวกรรมศาสตร์)</td></tr>
	  <tr><td width="100"><b>ชื่อย่อ:</b></td><td>&nbsp;วศ.บ (วิศวกรรมคอมพิวเตอร์) B.Eng (Computer Engineering)</td></tr>

	  <tr><td colspan="2"><b>แนวทางการประกอบอาชีพ</b><br>&nbsp;&nbsp;&nbsp;- วิศวกร<br>&nbsp;&nbsp;&nbsp;- นักพัฒนาโปรแกรม<br>&nbsp;&nbsp;&nbsp;- นักวิเคราะห์ระบบ<br>&nbsp;&nbsp;&nbsp;- นักพัฒนาระบบปัญญาประดิษฐ์<br>&nbsp;&nbsp;&nbsp;- นักพัฒนาหุ่นยนต์<br>&nbsp;&nbsp;&nbsp;- วิศวกรระบบควบคุม</td></tr>

	  <tr><td colspan="2"><center><a href="https://www.computing.psu.ac.th/th/b-eng%C2%A0computer-engineering/" target="_blank" class="w3-button w3-border w3-white">&nbsp;&nbsp;- view more -</a></td>  </center></td></tr>
	  </table>
    </div>

	<br></div>

	<script>
	// Tabbed Menu
	function openMenu(evt, menuName) {
	var i, x, tablinks;
	x = document.getElementsByClassName("menu");
	for (i = 0; i < x.length; i++) {
		 x[i].style.display = "none";
	}
	tablinks = document.getElementsByClassName("tablink");
	for (i = 0; i < x.length; i++) {
		tablinks[i].className = tablinks[i].className.replace(" w3-dark-grey", "");
	}
	document.getElementById(menuName).style.display = "block";
	evt.currentTarget.firstElementChild.className += " w3-dark-grey";
	}
	document.getElementById("myLink").click();
	</script>