<?php 
session_start(); 
session_destroy();
?>
<!DOCTYPE html>
<html>
  <meta charset="UTF-8">
  <meta name="Generator" content="EditPlus®">
  <meta name="Author" content="">
  <meta name="Keywords" content="">
  <meta name="Description" content="">
<title>Curriculum checking system</title>
<style>
.bgimg {
    background-position: center;
    background-size: cover;
    background-image: url("img/picHead1.jpg");
    min-height: 90%;
}
</style>
<?php include("inc.includeCss.php"); ?>
<body bgcolor="#cccccc">
<!-- topbar -->

<!-- Header  -->
<header class="bgimg w3-display-container" id="admin">
  <center><div class="w3-padding-large w3-display-middle w3-light-grey w3-border w3-left-align ">
  <br>
	<div><center><h5 style="text-shadow:1px 1px 0 #444">วิทยาลัยการคอมพิวเตอร์ มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต</h5></center>

	<br>
	<center><h2 style="text-shadow:1px 1px 0 #444">ระบบตรวจสอบหลักสูตร</h2></center>
	<center><h5 style="text-shadow:1px 1px 0 #444">[ Curriculum checking system ]</h5></center>
	
	</br>
	<center><table width="100%"><tr><td align="center"><h3> ขออภัย ไม่พบข้อมูลหลักสูตรของท่าน</h3></td></tr></table></center>
	<center><table width="100%"><tr><td align="center"><h6> - โปรดติดต่อเจ้าหน้าที่ - </h6></td></tr></table></center>
    </div>
	<br>
	<center><div><a href="index.php" class="w3-button w3-border w3-center"><i class="fa fa-close" aria-hidden="true"></i></a></div></center><br>
  </div></center>
</header>

<!-- Footer -->
</body>
</html>