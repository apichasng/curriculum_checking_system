<style>
.bgimg {
    background-position: center;
    background-size: cover;
    background-image: url("../img/picHead2.jpg");
    min-height: 40%;
}
</style>

<header class="bgimg w3-display-container" id="home">
  <div class="w3-display-bottomleft w3-padding-large">
	<h3 class="w3-animate-left" style="text-shadow:1px 1px 0 #444">ระบบตรวจสอบหลักสูตร วิทยาลัยการคอมพิวเตอร์ มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตภูเก็ต</h3>
	<h5 class="w3-animate-bottom" style="text-shadow:1px 1px 0 #444">Curriculum checking system</h5>
  </div>
  <div class="w3-display-middle w3-center">
    &nbsp;
  </div>
  <div class="w3-display-bottomright w3-center w3-padding-large">
    &nbsp;
  </div>
</header>
