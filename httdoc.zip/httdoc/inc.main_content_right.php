<!-- Links ประเมินระบบ -->
    <br>
    <div class="w3-container w3-light-grey w3-justify">
      <h3>ประเมินระบบ</h3>
      <a href="https://docs.google.com/forms/d/e/1FAIpQLSc_lvkyJpH03d_eDYasKZ3frBkXdDdptThYWpm0jIUReoAsYQ/viewform?usp=sf_link" target="_blank" style="text-decoration:none;" class="w3-hover-opacity">&nbsp;&nbsp;<i class="fa fa-pencil-square-o" aria-hidden="true"></i>&nbsp;&nbsp;แบบประเมิน ระบบตรวจสอบหลักสูตร</a><br>&nbsp;
    </div>

	<!-- Links คู่มือ -->
    <br>
    <div class="w3-container w3-light-grey w3-justify">
      <h3>คู่มือการใช้งานระบบ</h3>
      <a href="doc/user_manual_teacher.pdf" target="_blank" style="text-decoration:none;" class="w3-hover-opacity">&nbsp;&nbsp;<i class="fa fa-file-text" aria-hidden="true"></i>&nbsp;&nbsp;คู่มือการใช้งานสำหรับอาจารย์</a>
	  <br><a href="doc/user_manual_student.pdf" target="_blank" style="text-decoration:none;" class="w3-hover-opacity">&nbsp;&nbsp;<i class="fa fa-file-text" aria-hidden="true"></i>&nbsp;&nbsp;คู่มือการใช้งานนักศึกษา</a><br>&nbsp;
    </div>
	
	<!-- Links ที่เกี่ยวข้อง -->
    <br>
    <div class="w3-container w3-light-grey w3-justify">
      <h3>Links ที่เกี่ยวข้อง</h3>
      <a href="http://www.computing.psu.ac.th" target="_blank" style="text-decoration:none;" class="w3-hover-opacity">&nbsp;&nbsp;<i class="fa fa-globe" aria-hidden="true"></i>&nbsp;&nbsp;วิทยาลัยการคอมพิวเตอร์</a>
	  <br><a href="http://sis-phuket1.psu.ac.th" target="_blank" style="text-decoration:none;" class="w3-hover-opacity">&nbsp;&nbsp;<i class="fa fa-globe" aria-hidden="true"></i>&nbsp;&nbsp;ระบบสารสนเทศนักศึกษา (sis)</a>
	  <br><a href="http://lms2.psu.ac.th" target="_blank" style="text-decoration:none;" class="w3-hover-opacity">&nbsp;&nbsp;<i class="fa fa-globe" aria-hidden="true"></i>&nbsp;&nbsp;ระบบ LMS2@PSU</a><br>&nbsp;
    </div>


	<!-- xxxxxxxxxx -->
    <!-- <br>
    <div class="w3-container w3-light-grey w3-justify">
      <h2>Very New News!</h2>
      <p class="w3-justify">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
    </div> -->