    <div class="w3-container w3-light-grey">
      <center><h3><b>..welcome..</b></h3>
      <table border="0" class="w3-responsive">
		<tr><td><div class="w3-card"><a href="login/check_fail.php"><img src="img/tcrIcon.jpg" class="w3-hover-opacity" width="120" height="120" border="0" alt="Teacher"></a></div></td>
		<td valign="top"><b>&nbsp;Teacher</b><br>&nbsp;&nbsp;- ดูข้อมูลนักศึกษา<br>&nbsp;&nbsp;- รายงานข้อมูลนักศึกษา</td></tr>
		<tr><td><div class="w3-card"><a href="login/check_fail.php"><img src="img/stdIcon.jpg" class="w3-hover-opacity" width="120" height="120" border="0" alt="Student"></a></div></td>
		<td valign="top"><b>&nbsp;Student</b><br>&nbsp;&nbsp;- ตรวจสอบหลักสูตร<br>&nbsp;&nbsp;- วิชาเทียบโอน</td></tr>
	  </table></center>
	<br/>
	</div>