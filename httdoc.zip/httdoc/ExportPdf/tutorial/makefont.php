<?php
// Generation of font definition file for tutorial 7
require('../makefont/makefont.php');

MakeFont('calligra.ttf','cp1252');
?>
