<?php
$type='Type1';
$name='IrisUPC';
$desc=array('Ascent'=>479,'Descent'=>-139,'CapHeight'=>437,'Flags'=>32,'FontBBox'=>'[-389 -230 875 838]','ItalicAngle'=>0,'StemV'=>70);
$up=-32;
$ut=5;
$cw=array(
	chr(0)=>600,chr(1)=>600,chr(2)=>600,chr(3)=>600,chr(4)=>600,chr(5)=>600,chr(6)=>600,chr(7)=>600,chr(8)=>600,chr(9)=>600,chr(10)=>600,chr(11)=>600,chr(12)=>600,chr(13)=>600,chr(14)=>600,chr(15)=>600,chr(16)=>600,chr(17)=>600,chr(18)=>600,chr(19)=>600,chr(20)=>600,chr(21)=>600,
	chr(22)=>600,chr(23)=>600,chr(24)=>600,chr(25)=>600,chr(26)=>600,chr(27)=>600,chr(28)=>600,chr(29)=>600,chr(30)=>600,chr(31)=>600,' '=>219,'!'=>213,'"'=>213,'#'=>356,'$'=>356,'%'=>569,'&'=>462,'\''=>178,'('=>178,')'=>178,'*'=>284,'+'=>388,
	','=>178,'-'=>213,'.'=>178,'/'=>178,'0'=>372,'1'=>372,'2'=>372,'3'=>372,'4'=>393,'5'=>372,'6'=>372,'7'=>373,'8'=>372,'9'=>372,':'=>169,';'=>169,'<'=>388,'='=>388,'>'=>388,'?'=>329,'@'=>512,'A'=>427,
	'B'=>391,'C'=>427,'D'=>498,'E'=>320,'F'=>320,'G'=>498,'H'=>498,'I'=>178,'J'=>178,'K'=>391,'L'=>320,'M'=>569,'N'=>498,'O'=>533,'P'=>356,'Q'=>533,'R'=>391,'S'=>320,'T'=>356,'U'=>498,'V'=>427,'W'=>640,
	'X'=>391,'Y'=>391,'Z'=>391,'['=>213,'\\'=>320,']'=>213,'^'=>388,'_'=>320,'`'=>213,'a'=>320,'b'=>356,'c'=>320,'d'=>356,'e'=>320,'f'=>178,'g'=>320,'h'=>356,'i'=>178,'j'=>178,'k'=>320,'l'=>178,'m'=>533,
	'n'=>356,'o'=>356,'p'=>356,'q'=>356,'r'=>213,'s'=>249,'t'=>178,'u'=>356,'v'=>320,'w'=>498,'x'=>320,'y'=>320,'z'=>320,'{'=>213,'|'=>213,'}'=>213,'~'=>388,chr(127)=>600,chr(128)=>600,chr(129)=>600,chr(130)=>600,chr(131)=>600,
	chr(132)=>600,chr(133)=>600,chr(134)=>600,chr(135)=>600,chr(136)=>600,chr(137)=>600,chr(138)=>600,chr(139)=>600,chr(140)=>600,chr(141)=>600,chr(142)=>600,chr(143)=>600,chr(144)=>600,chr(145)=>600,chr(146)=>600,chr(147)=>600,chr(148)=>600,chr(149)=>600,chr(150)=>600,chr(151)=>600,chr(152)=>600,chr(153)=>600,
	chr(154)=>600,chr(155)=>600,chr(156)=>600,chr(157)=>600,chr(158)=>600,chr(159)=>600,chr(160)=>219,chr(161)=>381,chr(162)=>389,chr(163)=>406,chr(164)=>366,chr(165)=>366,chr(166)=>416,chr(167)=>282,chr(168)=>380,chr(169)=>430,chr(170)=>395,chr(171)=>410,chr(172)=>591,chr(173)=>554,chr(174)=>402,chr(175)=>402,
	chr(176)=>374,chr(177)=>446,chr(178)=>515,chr(179)=>574,chr(180)=>361,chr(181)=>392,chr(182)=>407,chr(183)=>366,chr(184)=>336,chr(185)=>420,chr(186)=>397,chr(187)=>398,chr(188)=>357,chr(189)=>349,chr(190)=>396,chr(191)=>378,chr(192)=>387,chr(193)=>390,chr(194)=>361,chr(195)=>314,chr(196)=>407,chr(197)=>387,
	chr(198)=>383,chr(199)=>306,chr(200)=>366,chr(201)=>442,chr(202)=>410,chr(203)=>411,chr(204)=>425,chr(205)=>380,chr(206)=>372,chr(207)=>305,chr(208)=>322,chr(209)=>0,chr(210)=>313,chr(211)=>304,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>0,chr(219)=>600,
	chr(220)=>600,chr(221)=>600,chr(222)=>600,chr(223)=>391,chr(224)=>186,chr(225)=>346,chr(226)=>259,chr(227)=>209,chr(228)=>271,chr(229)=>313,chr(230)=>346,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>0,chr(238)=>0,chr(239)=>429,chr(240)=>420,chr(241)=>380,
	chr(242)=>459,chr(243)=>378,chr(244)=>476,chr(245)=>476,chr(246)=>440,chr(247)=>498,chr(248)=>498,chr(249)=>494,chr(250)=>378,chr(251)=>896,chr(252)=>600,chr(253)=>600,chr(254)=>600,chr(255)=>600);
$enc='iso-8859-11';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='iris.z';
$size1=5625;
$size2=32878;
?>
