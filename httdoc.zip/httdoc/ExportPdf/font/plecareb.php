<?php
$type='Type1';
$name='PLECareBold';
$desc=array('Ascent'=>471,'Descent'=>-129,'CapHeight'=>-22,'Flags'=>32,'FontBBox'=>'[-415 -292 712 883]','ItalicAngle'=>0,'StemV'=>70,'MissingWidth'=>500);
$up=-32;
$ut=5;
$cw=array(
	chr(0)=>500,chr(1)=>500,chr(2)=>500,chr(3)=>500,chr(4)=>500,chr(5)=>500,chr(6)=>500,chr(7)=>500,chr(8)=>500,chr(9)=>500,chr(10)=>500,chr(11)=>500,chr(12)=>500,chr(13)=>500,chr(14)=>500,chr(15)=>500,chr(16)=>500,chr(17)=>500,chr(18)=>500,chr(19)=>500,chr(20)=>500,chr(21)=>500,
	chr(22)=>500,chr(23)=>500,chr(24)=>500,chr(25)=>500,chr(26)=>500,chr(27)=>500,chr(28)=>500,chr(29)=>500,chr(30)=>500,chr(31)=>500,' '=>119,'!'=>172,'"'=>197,'#'=>468,'$'=>413,'%'=>434,'&'=>365,'\''=>142,'('=>171,')'=>289,'*'=>297,'+'=>260,
	','=>245,'-'=>333,'.'=>192,'/'=>300,'0'=>322,'1'=>244,'2'=>404,'3'=>359,'4'=>353,'5'=>438,'6'=>271,'7'=>311,'8'=>308,'9'=>312,':'=>219,';'=>214,'<'=>119,'='=>323,'>'=>119,'?'=>119,'@'=>420,'A'=>119,
	'B'=>317,'C'=>350,'D'=>355,'E'=>286,'F'=>119,'G'=>119,'H'=>119,'I'=>119,'J'=>119,'K'=>119,'L'=>318,'M'=>119,'N'=>119,'O'=>500,'P'=>290,'Q'=>119,'R'=>119,'S'=>119,'T'=>119,'U'=>119,'V'=>119,'W'=>1000,
	'X'=>119,'Y'=>119,'Z'=>119,'['=>119,'\\'=>119,']'=>119,'^'=>119,'_'=>274,'`'=>119,'a'=>298,'b'=>1000,'c'=>319,'d'=>272,'e'=>304,'f'=>119,'g'=>119,'h'=>119,'i'=>390,'j'=>119,'k'=>415,'l'=>124,'m'=>119,
	'n'=>1000,'o'=>276,'p'=>119,'q'=>290,'r'=>277,'s'=>1000,'t'=>119,'u'=>471,'v'=>119,'w'=>1000,'x'=>119,'y'=>319,'z'=>119,'{'=>119,'|'=>119,'}'=>119,'~'=>119,chr(127)=>500,chr(128)=>500,chr(129)=>500,chr(130)=>500,chr(131)=>500,
	chr(132)=>500,chr(133)=>500,chr(134)=>500,chr(135)=>500,chr(136)=>500,chr(137)=>500,chr(138)=>500,chr(139)=>500,chr(140)=>500,chr(141)=>500,chr(142)=>500,chr(143)=>500,chr(144)=>500,chr(145)=>500,chr(146)=>500,chr(147)=>500,chr(148)=>500,chr(149)=>500,chr(150)=>500,chr(151)=>500,chr(152)=>500,chr(153)=>500,
	chr(154)=>500,chr(155)=>500,chr(156)=>500,chr(157)=>500,chr(158)=>500,chr(159)=>500,chr(160)=>119,chr(161)=>437,chr(162)=>357,chr(163)=>454,chr(164)=>396,chr(165)=>418,chr(166)=>502,chr(167)=>272,chr(168)=>326,chr(169)=>535,chr(170)=>363,chr(171)=>435,chr(172)=>656,chr(173)=>625,chr(174)=>427,chr(175)=>422,
	chr(176)=>372,chr(177)=>525,chr(178)=>582,chr(179)=>583,chr(180)=>391,chr(181)=>430,chr(182)=>453,chr(183)=>481,chr(184)=>290,chr(185)=>506,chr(186)=>508,chr(187)=>454,chr(188)=>448,chr(189)=>420,chr(190)=>495,chr(191)=>510,chr(192)=>408,chr(193)=>476,chr(194)=>404,chr(195)=>319,chr(196)=>405,chr(197)=>359,
	chr(198)=>399,chr(199)=>305,chr(200)=>439,chr(201)=>557,chr(202)=>395,chr(203)=>504,chr(204)=>484,chr(205)=>323,chr(206)=>343,chr(207)=>427,chr(208)=>326,chr(209)=>0,chr(210)=>313,chr(211)=>293,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>0,chr(219)=>500,
	chr(220)=>500,chr(221)=>500,chr(222)=>500,chr(223)=>119,chr(224)=>253,chr(225)=>441,chr(226)=>249,chr(227)=>300,chr(228)=>284,chr(229)=>282,chr(230)=>430,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>0,chr(238)=>0,chr(239)=>295,chr(240)=>334,chr(241)=>415,
	chr(242)=>523,chr(243)=>421,chr(244)=>519,chr(245)=>505,chr(246)=>489,chr(247)=>528,chr(248)=>598,chr(249)=>451,chr(250)=>532,chr(251)=>753,chr(252)=>500,chr(253)=>500,chr(254)=>500,chr(255)=>500);
$enc='iso-8859-11';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='plecareb.z';
$size1=6120;
$size2=26435;
?>
