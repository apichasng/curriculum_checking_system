<?php
$type='Type1';
$name='EucrosiaUPC';
$desc=array('Ascent'=>465,'Descent'=>-153,'CapHeight'=>451,'Flags'=>32,'FontBBox'=>'[-365 -233 791 839]','ItalicAngle'=>0,'StemV'=>70);
$up=-32;
$ut=5;
$cw=array(
	chr(0)=>600,chr(1)=>600,chr(2)=>600,chr(3)=>600,chr(4)=>600,chr(5)=>600,chr(6)=>600,chr(7)=>600,chr(8)=>600,chr(9)=>600,chr(10)=>600,chr(11)=>600,chr(12)=>600,chr(13)=>600,chr(14)=>600,chr(15)=>600,chr(16)=>600,chr(17)=>600,chr(18)=>600,chr(19)=>600,chr(20)=>600,chr(21)=>600,
	chr(22)=>600,chr(23)=>600,chr(24)=>600,chr(25)=>600,chr(26)=>600,chr(27)=>600,chr(28)=>600,chr(29)=>600,chr(30)=>600,chr(31)=>600,' '=>220,'!'=>266,'"'=>248,'#'=>431,'$'=>440,'%'=>565,'&'=>513,'\''=>190,'('=>323,')'=>323,'*'=>327,'+'=>401,
	','=>222,'-'=>401,'.'=>199,'/'=>360,'0'=>406,'1'=>406,'2'=>406,'3'=>406,'4'=>406,'5'=>406,'6'=>406,'7'=>406,'8'=>406,'9'=>406,':'=>221,';'=>218,'<'=>308,'='=>401,'>'=>308,'?'=>435,'@'=>629,'A'=>492,
	'B'=>456,'C'=>456,'D'=>492,'E'=>417,'F'=>379,'G'=>492,'H'=>492,'I'=>227,'J'=>266,'K'=>492,'L'=>417,'M'=>607,'N'=>492,'O'=>492,'P'=>379,'Q'=>492,'R'=>456,'S'=>379,'T'=>417,'U'=>492,'V'=>492,'W'=>645,
	'X'=>492,'Y'=>492,'Z'=>417,'['=>227,'\\'=>190,']'=>227,'^'=>320,'_'=>341,'`'=>227,'a'=>303,'b'=>341,'c'=>303,'d'=>341,'e'=>303,'f'=>227,'g'=>341,'h'=>341,'i'=>190,'j'=>190,'k'=>341,'l'=>190,'m'=>531,
	'n'=>341,'o'=>341,'p'=>341,'q'=>341,'r'=>227,'s'=>266,'t'=>190,'u'=>341,'v'=>341,'w'=>492,'x'=>341,'y'=>341,'z'=>303,'{'=>328,'|'=>136,'}'=>328,'~'=>370,chr(127)=>600,chr(128)=>600,chr(129)=>600,chr(130)=>600,chr(131)=>600,
	chr(132)=>600,chr(133)=>600,chr(134)=>600,chr(135)=>600,chr(136)=>600,chr(137)=>600,chr(138)=>600,chr(139)=>600,chr(140)=>600,chr(141)=>600,chr(142)=>600,chr(143)=>600,chr(144)=>600,chr(145)=>600,chr(146)=>600,chr(147)=>600,chr(148)=>600,chr(149)=>600,chr(150)=>600,chr(151)=>600,chr(152)=>600,chr(153)=>600,
	chr(154)=>600,chr(155)=>600,chr(156)=>600,chr(157)=>600,chr(158)=>600,chr(159)=>600,chr(160)=>220,chr(161)=>405,chr(162)=>369,chr(163)=>371,chr(164)=>430,chr(165)=>423,chr(166)=>429,chr(167)=>312,chr(168)=>367,chr(169)=>416,chr(170)=>376,chr(171)=>393,chr(172)=>536,chr(173)=>546,chr(174)=>447,chr(175)=>447,
	chr(176)=>369,chr(177)=>457,chr(178)=>579,chr(179)=>547,chr(180)=>429,chr(181)=>429,chr(182)=>405,chr(183)=>439,chr(184)=>362,chr(185)=>441,chr(186)=>448,chr(187)=>449,chr(188)=>430,chr(189)=>425,chr(190)=>495,chr(191)=>495,chr(192)=>444,chr(193)=>439,chr(194)=>387,chr(195)=>335,chr(196)=>405,chr(197)=>394,
	chr(198)=>451,chr(199)=>338,chr(200)=>433,chr(201)=>452,chr(202)=>394,chr(203)=>454,chr(204)=>498,chr(205)=>405,chr(206)=>403,chr(207)=>407,chr(208)=>329,chr(209)=>0,chr(210)=>298,chr(211)=>298,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>0,chr(219)=>600,
	chr(220)=>600,chr(221)=>600,chr(222)=>600,chr(223)=>419,chr(224)=>218,chr(225)=>404,chr(226)=>257,chr(227)=>287,chr(228)=>279,chr(229)=>295,chr(230)=>510,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>0,chr(238)=>0,chr(239)=>510,chr(240)=>438,chr(241)=>453,
	chr(242)=>492,chr(243)=>499,chr(244)=>440,chr(245)=>440,chr(246)=>429,chr(247)=>567,chr(248)=>467,chr(249)=>497,chr(250)=>472,chr(251)=>799,chr(252)=>600,chr(253)=>600,chr(254)=>600,chr(255)=>600);
$enc='iso-8859-11';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='eucro.z';
$size1=5661;
$size2=33790;
?>
