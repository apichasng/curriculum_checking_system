<?php
$type='Type1';
$name='JasmineUPC-Bold';
$desc=array('Ascent'=>462,'Descent'=>-124,'CapHeight'=>447,'Flags'=>32,'FontBBox'=>'[-437 -184 875 802]','ItalicAngle'=>0,'StemV'=>120);
$up=-32;
$ut=5;
$cw=array(
	chr(0)=>600,chr(1)=>600,chr(2)=>600,chr(3)=>600,chr(4)=>600,chr(5)=>600,chr(6)=>600,chr(7)=>600,chr(8)=>600,chr(9)=>600,chr(10)=>600,chr(11)=>600,chr(12)=>600,chr(13)=>600,chr(14)=>600,chr(15)=>600,chr(16)=>600,chr(17)=>600,chr(18)=>600,chr(19)=>600,chr(20)=>600,chr(21)=>600,
	chr(22)=>600,chr(23)=>600,chr(24)=>600,chr(25)=>600,chr(26)=>600,chr(27)=>600,chr(28)=>600,chr(29)=>600,chr(30)=>600,chr(31)=>600,' '=>222,'!'=>220,'"'=>354,'#'=>415,'$'=>415,'%'=>573,'&'=>512,'\''=>159,'('=>207,')'=>207,'*'=>244,'+'=>403,
	','=>219,'-'=>411,'.'=>207,'/'=>437,'0'=>485,'1'=>485,'2'=>485,'3'=>485,'4'=>485,'5'=>485,'6'=>485,'7'=>485,'8'=>485,'9'=>485,':'=>248,';'=>248,'<'=>383,'='=>431,'>'=>383,'?'=>418,'@'=>525,'A'=>451,
	'B'=>451,'C'=>464,'D'=>500,'E'=>403,'F'=>378,'G'=>476,'H'=>500,'I'=>207,'J'=>342,'K'=>476,'L'=>366,'M'=>561,'N'=>464,'O'=>525,'P'=>415,'Q'=>525,'R'=>451,'S'=>415,'T'=>415,'U'=>464,'V'=>451,'W'=>610,
	'X'=>451,'Y'=>451,'Z'=>378,'['=>195,'\\'=>390,']'=>195,'^'=>403,'_'=>305,'`'=>232,'a'=>354,'b'=>378,'c'=>317,'d'=>378,'e'=>342,'f'=>220,'g'=>366,'h'=>378,'i'=>183,'j'=>183,'k'=>366,'l'=>183,'m'=>561,
	'n'=>378,'o'=>378,'p'=>390,'q'=>378,'r'=>268,'s'=>305,'t'=>232,'u'=>378,'v'=>329,'w'=>488,'x'=>342,'y'=>329,'z'=>305,'{'=>207,'|'=>403,'}'=>207,'~'=>403,chr(127)=>600,chr(128)=>600,chr(129)=>600,chr(130)=>600,chr(131)=>600,
	chr(132)=>600,chr(133)=>600,chr(134)=>600,chr(135)=>600,chr(136)=>600,chr(137)=>600,chr(138)=>600,chr(139)=>600,chr(140)=>600,chr(141)=>600,chr(142)=>600,chr(143)=>600,chr(144)=>600,chr(145)=>600,chr(146)=>600,chr(147)=>600,chr(148)=>600,chr(149)=>600,chr(150)=>600,chr(151)=>600,chr(152)=>600,chr(153)=>600,
	chr(154)=>600,chr(155)=>600,chr(156)=>600,chr(157)=>600,chr(158)=>600,chr(159)=>600,chr(160)=>222,chr(161)=>470,chr(162)=>455,chr(163)=>491,chr(164)=>508,chr(165)=>508,chr(166)=>528,chr(167)=>413,chr(168)=>448,chr(169)=>468,chr(170)=>451,chr(171)=>486,chr(172)=>710,chr(173)=>711,chr(174)=>495,chr(175)=>496,
	chr(176)=>454,chr(177)=>532,chr(178)=>739,chr(179)=>707,chr(180)=>507,chr(181)=>505,chr(182)=>484,chr(183)=>505,chr(184)=>461,chr(185)=>486,chr(186)=>488,chr(187)=>492,chr(188)=>527,chr(189)=>528,chr(190)=>589,chr(191)=>586,chr(192)=>488,chr(193)=>505,chr(194)=>461,chr(195)=>420,chr(196)=>484,chr(197)=>460,
	chr(198)=>493,chr(199)=>421,chr(200)=>501,chr(201)=>482,chr(202)=>465,chr(203)=>497,chr(204)=>577,chr(205)=>450,chr(206)=>450,chr(207)=>457,chr(208)=>332,chr(209)=>0,chr(210)=>395,chr(211)=>409,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>0,chr(219)=>600,
	chr(220)=>600,chr(221)=>600,chr(222)=>600,chr(223)=>525,chr(224)=>238,chr(225)=>427,chr(226)=>256,chr(227)=>288,chr(228)=>283,chr(229)=>406,chr(230)=>667,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>0,chr(238)=>0,chr(239)=>510,chr(240)=>459,chr(241)=>485,
	chr(242)=>546,chr(243)=>480,chr(244)=>446,chr(245)=>454,chr(246)=>439,chr(247)=>586,chr(248)=>467,chr(249)=>464,chr(250)=>615,chr(251)=>896,chr(252)=>600,chr(253)=>600,chr(254)=>600,chr(255)=>600);
$enc='iso-8859-11';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='jasmb.z';
$size1=5669;
$size2=36789;
?>
